<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo form_open('Main/test2'); ?>
	<input type="datetime-local" name="date">
	<input type="submit" name="">
	<?php echo form_close(); ?>
</body>
</html>