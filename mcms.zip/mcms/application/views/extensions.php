<html>
<head>
	<title>MCMS</title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="<?php echo base_url();?>public/js/jscookmenu.min.js"></script>
		<script src="<?php echo base_url();?>public/js/jquery-1.12.4.min.js"></script>
		<script src="<?php echo base_url();?>public/js/wb.carousel.min.js"></script>
		<script src="<?php echo base_url();?>public/js/bootstrap.js"></script>
		<link href="<?php echo base_url();?>public/css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>public/css/bootstrap.css" rel="stylesheet">
		<script src="<?php echo base_url();?>public/js/bootstrap.min.js"></script>
		<link rel="shortcut icon" type="image/png" href="<?php echo base_url();?>/Public/images/icon.png"/>
	    <link rel="stylesheet" href="<?php echo base_url();?>/Public/font-awesome/css/font-awesome.min.css">
	    <link rel="stylesheet" href="<?php echo base_url();?>/Public/css/morris.css">
	    <script src="<?php echo base_url();?>/Public/js/raphael-min.js"></script>
 		<script src="<?php echo base_url();?>/Public/js/morris.min.js"></script>

</head>