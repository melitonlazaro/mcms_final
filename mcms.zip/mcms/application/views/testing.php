<?php 

	$foo = new stdClass();

	$quux = (object) ["boo" => "MEL"];
	echo $quux->boo;

 ?>