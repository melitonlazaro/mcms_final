<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-02 15:04:59 --> Config Class Initialized
INFO - 2018-05-02 15:04:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:05:00 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:05:00 --> Utf8 Class Initialized
INFO - 2018-05-02 15:05:00 --> URI Class Initialized
DEBUG - 2018-05-02 15:05:00 --> No URI present. Default controller set.
INFO - 2018-05-02 15:05:00 --> Router Class Initialized
INFO - 2018-05-02 15:05:00 --> Output Class Initialized
INFO - 2018-05-02 15:05:00 --> Security Class Initialized
DEBUG - 2018-05-02 15:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:05:00 --> Input Class Initialized
INFO - 2018-05-02 15:05:00 --> Language Class Initialized
INFO - 2018-05-02 15:05:00 --> Loader Class Initialized
INFO - 2018-05-02 15:05:00 --> Helper loaded: url_helper
INFO - 2018-05-02 15:05:01 --> Helper loaded: form_helper
INFO - 2018-05-02 15:05:01 --> Helper loaded: date_helper
INFO - 2018-05-02 15:05:01 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:05:02 --> Form Validation Class Initialized
INFO - 2018-05-02 15:05:02 --> Model Class Initialized
INFO - 2018-05-02 15:05:02 --> Controller Class Initialized
INFO - 2018-05-02 15:05:03 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-02 15:05:03 --> Final output sent to browser
DEBUG - 2018-05-02 15:05:03 --> Total execution time: 3.7418
INFO - 2018-05-02 15:08:13 --> Config Class Initialized
INFO - 2018-05-02 15:08:13 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:08:13 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:08:13 --> Utf8 Class Initialized
INFO - 2018-05-02 15:08:13 --> URI Class Initialized
INFO - 2018-05-02 15:08:13 --> Router Class Initialized
INFO - 2018-05-02 15:08:13 --> Output Class Initialized
INFO - 2018-05-02 15:08:13 --> Security Class Initialized
DEBUG - 2018-05-02 15:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:08:13 --> Input Class Initialized
INFO - 2018-05-02 15:08:13 --> Language Class Initialized
INFO - 2018-05-02 15:08:13 --> Loader Class Initialized
INFO - 2018-05-02 15:08:13 --> Helper loaded: url_helper
INFO - 2018-05-02 15:08:13 --> Helper loaded: form_helper
INFO - 2018-05-02 15:08:13 --> Helper loaded: date_helper
INFO - 2018-05-02 15:08:13 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:08:13 --> Form Validation Class Initialized
INFO - 2018-05-02 15:08:13 --> Model Class Initialized
INFO - 2018-05-02 15:08:13 --> Controller Class Initialized
INFO - 2018-05-02 15:08:13 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-02 15:08:13 --> Final output sent to browser
DEBUG - 2018-05-02 15:08:13 --> Total execution time: 0.6842
INFO - 2018-05-02 15:08:22 --> Config Class Initialized
INFO - 2018-05-02 15:08:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:08:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:08:22 --> Utf8 Class Initialized
INFO - 2018-05-02 15:08:22 --> URI Class Initialized
INFO - 2018-05-02 15:08:22 --> Router Class Initialized
INFO - 2018-05-02 15:08:22 --> Output Class Initialized
INFO - 2018-05-02 15:08:22 --> Security Class Initialized
DEBUG - 2018-05-02 15:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:08:23 --> Input Class Initialized
INFO - 2018-05-02 15:08:23 --> Language Class Initialized
INFO - 2018-05-02 15:08:23 --> Loader Class Initialized
INFO - 2018-05-02 15:08:23 --> Helper loaded: url_helper
INFO - 2018-05-02 15:08:23 --> Helper loaded: form_helper
INFO - 2018-05-02 15:08:23 --> Helper loaded: date_helper
INFO - 2018-05-02 15:08:23 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:08:23 --> Form Validation Class Initialized
INFO - 2018-05-02 15:08:23 --> Model Class Initialized
INFO - 2018-05-02 15:08:23 --> Controller Class Initialized
INFO - 2018-05-02 15:08:23 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-02 15:08:23 --> Final output sent to browser
DEBUG - 2018-05-02 15:08:23 --> Total execution time: 0.6630
INFO - 2018-05-02 15:08:27 --> Config Class Initialized
INFO - 2018-05-02 15:08:27 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:08:27 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:08:27 --> Utf8 Class Initialized
INFO - 2018-05-02 15:08:27 --> URI Class Initialized
INFO - 2018-05-02 15:08:27 --> Router Class Initialized
INFO - 2018-05-02 15:08:27 --> Output Class Initialized
INFO - 2018-05-02 15:08:27 --> Security Class Initialized
DEBUG - 2018-05-02 15:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:08:27 --> Input Class Initialized
INFO - 2018-05-02 15:08:27 --> Language Class Initialized
INFO - 2018-05-02 15:08:27 --> Loader Class Initialized
INFO - 2018-05-02 15:08:27 --> Helper loaded: url_helper
INFO - 2018-05-02 15:08:27 --> Helper loaded: form_helper
INFO - 2018-05-02 15:08:27 --> Helper loaded: date_helper
INFO - 2018-05-02 15:08:27 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:08:27 --> Form Validation Class Initialized
INFO - 2018-05-02 15:08:27 --> Model Class Initialized
INFO - 2018-05-02 15:08:27 --> Controller Class Initialized
INFO - 2018-05-02 15:08:27 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-02 15:08:27 --> Final output sent to browser
DEBUG - 2018-05-02 15:08:27 --> Total execution time: 0.4009
INFO - 2018-05-02 15:08:32 --> Config Class Initialized
INFO - 2018-05-02 15:08:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:08:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:08:32 --> Utf8 Class Initialized
INFO - 2018-05-02 15:08:32 --> URI Class Initialized
INFO - 2018-05-02 15:08:32 --> Router Class Initialized
INFO - 2018-05-02 15:08:32 --> Output Class Initialized
INFO - 2018-05-02 15:08:32 --> Security Class Initialized
DEBUG - 2018-05-02 15:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:08:32 --> Input Class Initialized
INFO - 2018-05-02 15:08:32 --> Language Class Initialized
INFO - 2018-05-02 15:08:32 --> Loader Class Initialized
INFO - 2018-05-02 15:08:33 --> Helper loaded: url_helper
INFO - 2018-05-02 15:08:33 --> Helper loaded: form_helper
INFO - 2018-05-02 15:08:33 --> Helper loaded: date_helper
INFO - 2018-05-02 15:08:33 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:08:33 --> Form Validation Class Initialized
INFO - 2018-05-02 15:08:33 --> Model Class Initialized
INFO - 2018-05-02 15:08:33 --> Controller Class Initialized
INFO - 2018-05-02 15:08:33 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-02 15:08:33 --> Final output sent to browser
DEBUG - 2018-05-02 15:08:33 --> Total execution time: 0.4923
INFO - 2018-05-02 15:08:41 --> Config Class Initialized
INFO - 2018-05-02 15:08:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:08:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:08:41 --> Utf8 Class Initialized
INFO - 2018-05-02 15:08:41 --> URI Class Initialized
INFO - 2018-05-02 15:08:41 --> Router Class Initialized
INFO - 2018-05-02 15:08:41 --> Output Class Initialized
INFO - 2018-05-02 15:08:41 --> Security Class Initialized
DEBUG - 2018-05-02 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:08:41 --> Input Class Initialized
INFO - 2018-05-02 15:08:41 --> Language Class Initialized
INFO - 2018-05-02 15:08:41 --> Loader Class Initialized
INFO - 2018-05-02 15:08:41 --> Helper loaded: url_helper
INFO - 2018-05-02 15:08:41 --> Helper loaded: form_helper
INFO - 2018-05-02 15:08:41 --> Helper loaded: date_helper
INFO - 2018-05-02 15:08:41 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:08:41 --> Form Validation Class Initialized
INFO - 2018-05-02 15:08:41 --> Model Class Initialized
INFO - 2018-05-02 15:08:41 --> Controller Class Initialized
INFO - 2018-05-02 15:08:41 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-02 15:08:41 --> Final output sent to browser
DEBUG - 2018-05-02 15:08:41 --> Total execution time: 0.3964
INFO - 2018-05-02 15:10:45 --> Config Class Initialized
INFO - 2018-05-02 15:10:45 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:10:45 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:10:45 --> Utf8 Class Initialized
INFO - 2018-05-02 15:10:45 --> URI Class Initialized
INFO - 2018-05-02 15:10:45 --> Router Class Initialized
INFO - 2018-05-02 15:10:45 --> Output Class Initialized
INFO - 2018-05-02 15:10:45 --> Security Class Initialized
DEBUG - 2018-05-02 15:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:10:45 --> Input Class Initialized
INFO - 2018-05-02 15:10:45 --> Language Class Initialized
INFO - 2018-05-02 15:10:45 --> Loader Class Initialized
INFO - 2018-05-02 15:10:45 --> Helper loaded: url_helper
INFO - 2018-05-02 15:10:45 --> Helper loaded: form_helper
INFO - 2018-05-02 15:10:45 --> Helper loaded: date_helper
INFO - 2018-05-02 15:10:45 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:10:45 --> Form Validation Class Initialized
INFO - 2018-05-02 15:10:45 --> Model Class Initialized
INFO - 2018-05-02 15:10:45 --> Controller Class Initialized
INFO - 2018-05-02 15:10:45 --> Config Class Initialized
INFO - 2018-05-02 15:10:45 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:10:45 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:10:45 --> Utf8 Class Initialized
INFO - 2018-05-02 15:10:45 --> URI Class Initialized
INFO - 2018-05-02 15:10:45 --> Router Class Initialized
INFO - 2018-05-02 15:10:45 --> Output Class Initialized
INFO - 2018-05-02 15:10:45 --> Security Class Initialized
DEBUG - 2018-05-02 15:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:10:45 --> Input Class Initialized
INFO - 2018-05-02 15:10:45 --> Language Class Initialized
INFO - 2018-05-02 15:10:45 --> Loader Class Initialized
INFO - 2018-05-02 15:10:45 --> Helper loaded: url_helper
INFO - 2018-05-02 15:10:45 --> Helper loaded: form_helper
INFO - 2018-05-02 15:10:45 --> Helper loaded: date_helper
INFO - 2018-05-02 15:10:45 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:10:45 --> Form Validation Class Initialized
INFO - 2018-05-02 15:10:45 --> Model Class Initialized
INFO - 2018-05-02 15:10:45 --> Controller Class Initialized
INFO - 2018-05-02 15:10:46 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-02 15:10:46 --> Final output sent to browser
DEBUG - 2018-05-02 15:10:46 --> Total execution time: 0.7195
INFO - 2018-05-02 15:10:46 --> Config Class Initialized
INFO - 2018-05-02 15:10:46 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:10:46 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:10:46 --> Utf8 Class Initialized
INFO - 2018-05-02 15:10:46 --> URI Class Initialized
INFO - 2018-05-02 15:10:46 --> Router Class Initialized
INFO - 2018-05-02 15:10:46 --> Output Class Initialized
INFO - 2018-05-02 15:10:46 --> Security Class Initialized
DEBUG - 2018-05-02 15:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:10:46 --> Input Class Initialized
INFO - 2018-05-02 15:10:46 --> Language Class Initialized
ERROR - 2018-05-02 15:10:46 --> 404 Page Not Found: Main/css
INFO - 2018-05-02 15:10:48 --> Config Class Initialized
INFO - 2018-05-02 15:10:48 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:10:48 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:10:48 --> Utf8 Class Initialized
INFO - 2018-05-02 15:10:48 --> URI Class Initialized
INFO - 2018-05-02 15:10:48 --> Router Class Initialized
INFO - 2018-05-02 15:10:48 --> Output Class Initialized
INFO - 2018-05-02 15:10:48 --> Security Class Initialized
DEBUG - 2018-05-02 15:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:10:48 --> Input Class Initialized
INFO - 2018-05-02 15:10:48 --> Language Class Initialized
ERROR - 2018-05-02 15:10:48 --> 404 Page Not Found: Main/img
INFO - 2018-05-02 15:11:38 --> Config Class Initialized
INFO - 2018-05-02 15:11:38 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:38 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:38 --> URI Class Initialized
INFO - 2018-05-02 15:11:38 --> Router Class Initialized
INFO - 2018-05-02 15:11:38 --> Output Class Initialized
INFO - 2018-05-02 15:11:38 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:38 --> Input Class Initialized
INFO - 2018-05-02 15:11:38 --> Language Class Initialized
INFO - 2018-05-02 15:11:38 --> Loader Class Initialized
INFO - 2018-05-02 15:11:38 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:38 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:38 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:38 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:38 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:38 --> Model Class Initialized
INFO - 2018-05-02 15:11:38 --> Controller Class Initialized
INFO - 2018-05-02 15:11:38 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-02 15:11:38 --> Final output sent to browser
DEBUG - 2018-05-02 15:11:38 --> Total execution time: 0.6449
INFO - 2018-05-02 15:11:38 --> Config Class Initialized
INFO - 2018-05-02 15:11:38 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:38 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:38 --> URI Class Initialized
INFO - 2018-05-02 15:11:38 --> Router Class Initialized
INFO - 2018-05-02 15:11:38 --> Output Class Initialized
INFO - 2018-05-02 15:11:38 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:38 --> Input Class Initialized
INFO - 2018-05-02 15:11:38 --> Language Class Initialized
ERROR - 2018-05-02 15:11:39 --> 404 Page Not Found: Main/css
INFO - 2018-05-02 15:11:39 --> Config Class Initialized
INFO - 2018-05-02 15:11:39 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:39 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:39 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:39 --> URI Class Initialized
INFO - 2018-05-02 15:11:39 --> Router Class Initialized
INFO - 2018-05-02 15:11:39 --> Output Class Initialized
INFO - 2018-05-02 15:11:39 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:39 --> Input Class Initialized
INFO - 2018-05-02 15:11:39 --> Language Class Initialized
INFO - 2018-05-02 15:11:39 --> Loader Class Initialized
INFO - 2018-05-02 15:11:39 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:39 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:39 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:39 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:39 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:39 --> Model Class Initialized
INFO - 2018-05-02 15:11:40 --> Controller Class Initialized
INFO - 2018-05-02 15:11:41 --> Config Class Initialized
INFO - 2018-05-02 15:11:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:41 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:41 --> URI Class Initialized
INFO - 2018-05-02 15:11:41 --> Router Class Initialized
INFO - 2018-05-02 15:11:42 --> Output Class Initialized
INFO - 2018-05-02 15:11:42 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:42 --> Input Class Initialized
INFO - 2018-05-02 15:11:42 --> Language Class Initialized
INFO - 2018-05-02 15:11:42 --> Loader Class Initialized
INFO - 2018-05-02 15:11:42 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:42 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:42 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:42 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:42 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:42 --> Model Class Initialized
INFO - 2018-05-02 15:11:42 --> Controller Class Initialized
INFO - 2018-05-02 15:11:42 --> Config Class Initialized
INFO - 2018-05-02 15:11:42 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:42 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:42 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:42 --> URI Class Initialized
INFO - 2018-05-02 15:11:42 --> Router Class Initialized
INFO - 2018-05-02 15:11:42 --> Output Class Initialized
INFO - 2018-05-02 15:11:42 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:42 --> Input Class Initialized
INFO - 2018-05-02 15:11:42 --> Language Class Initialized
INFO - 2018-05-02 15:11:42 --> Loader Class Initialized
INFO - 2018-05-02 15:11:42 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:42 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:42 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:42 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:42 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:42 --> Model Class Initialized
INFO - 2018-05-02 15:11:42 --> Controller Class Initialized
INFO - 2018-05-02 15:11:42 --> Config Class Initialized
INFO - 2018-05-02 15:11:42 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:42 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:42 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:42 --> URI Class Initialized
INFO - 2018-05-02 15:11:42 --> Router Class Initialized
INFO - 2018-05-02 15:11:43 --> Output Class Initialized
INFO - 2018-05-02 15:11:43 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:43 --> Input Class Initialized
INFO - 2018-05-02 15:11:43 --> Language Class Initialized
INFO - 2018-05-02 15:11:43 --> Loader Class Initialized
INFO - 2018-05-02 15:11:43 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:43 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:43 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:43 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:43 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:43 --> Model Class Initialized
INFO - 2018-05-02 15:11:43 --> Controller Class Initialized
INFO - 2018-05-02 15:11:43 --> Config Class Initialized
INFO - 2018-05-02 15:11:43 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:43 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:43 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:43 --> URI Class Initialized
INFO - 2018-05-02 15:11:43 --> Router Class Initialized
INFO - 2018-05-02 15:11:43 --> Output Class Initialized
INFO - 2018-05-02 15:11:43 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:43 --> Input Class Initialized
INFO - 2018-05-02 15:11:43 --> Language Class Initialized
INFO - 2018-05-02 15:11:43 --> Loader Class Initialized
INFO - 2018-05-02 15:11:43 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:43 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:43 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:43 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:43 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:43 --> Model Class Initialized
INFO - 2018-05-02 15:11:43 --> Controller Class Initialized
INFO - 2018-05-02 15:11:43 --> Config Class Initialized
INFO - 2018-05-02 15:11:43 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:43 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:43 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:43 --> URI Class Initialized
INFO - 2018-05-02 15:11:43 --> Router Class Initialized
INFO - 2018-05-02 15:11:44 --> Output Class Initialized
INFO - 2018-05-02 15:11:44 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:44 --> Input Class Initialized
INFO - 2018-05-02 15:11:44 --> Language Class Initialized
INFO - 2018-05-02 15:11:44 --> Loader Class Initialized
INFO - 2018-05-02 15:11:44 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:44 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:44 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:44 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:44 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:44 --> Model Class Initialized
INFO - 2018-05-02 15:11:44 --> Controller Class Initialized
INFO - 2018-05-02 15:11:44 --> Config Class Initialized
INFO - 2018-05-02 15:11:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:44 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:44 --> URI Class Initialized
INFO - 2018-05-02 15:11:45 --> Router Class Initialized
INFO - 2018-05-02 15:11:45 --> Output Class Initialized
INFO - 2018-05-02 15:11:45 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:45 --> Input Class Initialized
INFO - 2018-05-02 15:11:45 --> Language Class Initialized
INFO - 2018-05-02 15:11:45 --> Loader Class Initialized
INFO - 2018-05-02 15:11:45 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:45 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:45 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:45 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:45 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:45 --> Model Class Initialized
INFO - 2018-05-02 15:11:45 --> Controller Class Initialized
INFO - 2018-05-02 15:11:46 --> Config Class Initialized
INFO - 2018-05-02 15:11:46 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:46 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:46 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:46 --> URI Class Initialized
INFO - 2018-05-02 15:11:46 --> Router Class Initialized
INFO - 2018-05-02 15:11:46 --> Output Class Initialized
INFO - 2018-05-02 15:11:46 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:46 --> Input Class Initialized
INFO - 2018-05-02 15:11:46 --> Language Class Initialized
INFO - 2018-05-02 15:11:46 --> Loader Class Initialized
INFO - 2018-05-02 15:11:46 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:46 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:46 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:46 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:46 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:46 --> Model Class Initialized
INFO - 2018-05-02 15:11:46 --> Controller Class Initialized
INFO - 2018-05-02 15:11:47 --> Config Class Initialized
INFO - 2018-05-02 15:11:47 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:47 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:47 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:47 --> URI Class Initialized
INFO - 2018-05-02 15:11:47 --> Router Class Initialized
INFO - 2018-05-02 15:11:47 --> Output Class Initialized
INFO - 2018-05-02 15:11:47 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:47 --> Input Class Initialized
INFO - 2018-05-02 15:11:47 --> Language Class Initialized
INFO - 2018-05-02 15:11:47 --> Loader Class Initialized
INFO - 2018-05-02 15:11:47 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:47 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:47 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:47 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:47 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:47 --> Model Class Initialized
INFO - 2018-05-02 15:11:47 --> Controller Class Initialized
INFO - 2018-05-02 15:11:48 --> Config Class Initialized
INFO - 2018-05-02 15:11:48 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:48 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:48 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:48 --> URI Class Initialized
INFO - 2018-05-02 15:11:48 --> Router Class Initialized
INFO - 2018-05-02 15:11:48 --> Output Class Initialized
INFO - 2018-05-02 15:11:48 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:48 --> Input Class Initialized
INFO - 2018-05-02 15:11:48 --> Language Class Initialized
INFO - 2018-05-02 15:11:49 --> Loader Class Initialized
INFO - 2018-05-02 15:11:49 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:49 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:49 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:49 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:49 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:49 --> Model Class Initialized
INFO - 2018-05-02 15:11:49 --> Controller Class Initialized
INFO - 2018-05-02 15:11:49 --> Config Class Initialized
INFO - 2018-05-02 15:11:49 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:49 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:49 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:49 --> URI Class Initialized
INFO - 2018-05-02 15:11:49 --> Router Class Initialized
INFO - 2018-05-02 15:11:49 --> Output Class Initialized
INFO - 2018-05-02 15:11:49 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:49 --> Input Class Initialized
INFO - 2018-05-02 15:11:49 --> Language Class Initialized
INFO - 2018-05-02 15:11:49 --> Loader Class Initialized
INFO - 2018-05-02 15:11:49 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:49 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:49 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:49 --> Database Driver Class Initialized
INFO - 2018-05-02 15:11:49 --> Config Class Initialized
INFO - 2018-05-02 15:11:49 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:49 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:49 --> Utf8 Class Initialized
DEBUG - 2018-05-02 15:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:49 --> URI Class Initialized
INFO - 2018-05-02 15:11:49 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:49 --> Router Class Initialized
INFO - 2018-05-02 15:11:49 --> Model Class Initialized
INFO - 2018-05-02 15:11:49 --> Output Class Initialized
INFO - 2018-05-02 15:11:49 --> Controller Class Initialized
INFO - 2018-05-02 15:11:49 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:49 --> Input Class Initialized
INFO - 2018-05-02 15:11:50 --> Language Class Initialized
INFO - 2018-05-02 15:11:50 --> Loader Class Initialized
INFO - 2018-05-02 15:11:50 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:50 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:50 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:50 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:50 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:50 --> Model Class Initialized
INFO - 2018-05-02 15:11:50 --> Controller Class Initialized
INFO - 2018-05-02 15:11:51 --> Config Class Initialized
INFO - 2018-05-02 15:11:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:51 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:51 --> URI Class Initialized
INFO - 2018-05-02 15:11:51 --> Router Class Initialized
INFO - 2018-05-02 15:11:51 --> Output Class Initialized
INFO - 2018-05-02 15:11:51 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:51 --> Input Class Initialized
INFO - 2018-05-02 15:11:51 --> Language Class Initialized
INFO - 2018-05-02 15:11:51 --> Loader Class Initialized
INFO - 2018-05-02 15:11:51 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:51 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:51 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:51 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:51 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:51 --> Config Class Initialized
INFO - 2018-05-02 15:11:51 --> Model Class Initialized
INFO - 2018-05-02 15:11:51 --> Hooks Class Initialized
INFO - 2018-05-02 15:11:51 --> Controller Class Initialized
DEBUG - 2018-05-02 15:11:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:51 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:51 --> URI Class Initialized
INFO - 2018-05-02 15:11:51 --> Router Class Initialized
INFO - 2018-05-02 15:11:51 --> Output Class Initialized
INFO - 2018-05-02 15:11:51 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:51 --> Input Class Initialized
INFO - 2018-05-02 15:11:51 --> Language Class Initialized
INFO - 2018-05-02 15:11:51 --> Loader Class Initialized
INFO - 2018-05-02 15:11:51 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:51 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:51 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:51 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:51 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:51 --> Model Class Initialized
INFO - 2018-05-02 15:11:51 --> Controller Class Initialized
INFO - 2018-05-02 15:11:51 --> Config Class Initialized
INFO - 2018-05-02 15:11:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:51 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:51 --> URI Class Initialized
INFO - 2018-05-02 15:11:51 --> Router Class Initialized
INFO - 2018-05-02 15:11:51 --> Output Class Initialized
INFO - 2018-05-02 15:11:51 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:51 --> Input Class Initialized
INFO - 2018-05-02 15:11:52 --> Language Class Initialized
INFO - 2018-05-02 15:11:52 --> Loader Class Initialized
INFO - 2018-05-02 15:11:52 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:52 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:52 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:52 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:52 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:52 --> Model Class Initialized
INFO - 2018-05-02 15:11:52 --> Config Class Initialized
INFO - 2018-05-02 15:11:52 --> Controller Class Initialized
INFO - 2018-05-02 15:11:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:52 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:52 --> URI Class Initialized
INFO - 2018-05-02 15:11:52 --> Router Class Initialized
INFO - 2018-05-02 15:11:52 --> Output Class Initialized
INFO - 2018-05-02 15:11:52 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:52 --> Input Class Initialized
INFO - 2018-05-02 15:11:52 --> Language Class Initialized
INFO - 2018-05-02 15:11:52 --> Loader Class Initialized
INFO - 2018-05-02 15:11:52 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:52 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:52 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:52 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:52 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:52 --> Model Class Initialized
INFO - 2018-05-02 15:11:52 --> Controller Class Initialized
INFO - 2018-05-02 15:11:52 --> Config Class Initialized
INFO - 2018-05-02 15:11:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:52 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:52 --> URI Class Initialized
INFO - 2018-05-02 15:11:52 --> Router Class Initialized
INFO - 2018-05-02 15:11:52 --> Output Class Initialized
INFO - 2018-05-02 15:11:52 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:52 --> Input Class Initialized
INFO - 2018-05-02 15:11:52 --> Language Class Initialized
INFO - 2018-05-02 15:11:52 --> Loader Class Initialized
INFO - 2018-05-02 15:11:52 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:52 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:52 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:53 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:53 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:53 --> Model Class Initialized
INFO - 2018-05-02 15:11:53 --> Controller Class Initialized
INFO - 2018-05-02 15:11:53 --> Config Class Initialized
INFO - 2018-05-02 15:11:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:53 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:53 --> URI Class Initialized
INFO - 2018-05-02 15:11:53 --> Router Class Initialized
INFO - 2018-05-02 15:11:53 --> Output Class Initialized
INFO - 2018-05-02 15:11:53 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:53 --> Input Class Initialized
INFO - 2018-05-02 15:11:53 --> Language Class Initialized
INFO - 2018-05-02 15:11:53 --> Loader Class Initialized
INFO - 2018-05-02 15:11:53 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:53 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:53 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:53 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:53 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:53 --> Model Class Initialized
INFO - 2018-05-02 15:11:53 --> Controller Class Initialized
INFO - 2018-05-02 15:11:56 --> Config Class Initialized
INFO - 2018-05-02 15:11:56 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:11:56 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:56 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:56 --> URI Class Initialized
INFO - 2018-05-02 15:11:56 --> Router Class Initialized
INFO - 2018-05-02 15:11:56 --> Output Class Initialized
INFO - 2018-05-02 15:11:56 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:56 --> Input Class Initialized
INFO - 2018-05-02 15:11:56 --> Language Class Initialized
INFO - 2018-05-02 15:11:56 --> Loader Class Initialized
INFO - 2018-05-02 15:11:56 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:56 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:56 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:56 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:56 --> Config Class Initialized
INFO - 2018-05-02 15:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:56 --> Hooks Class Initialized
INFO - 2018-05-02 15:11:56 --> Form Validation Class Initialized
DEBUG - 2018-05-02 15:11:56 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:56 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:56 --> Model Class Initialized
INFO - 2018-05-02 15:11:56 --> Controller Class Initialized
INFO - 2018-05-02 15:11:56 --> URI Class Initialized
INFO - 2018-05-02 15:11:56 --> Router Class Initialized
INFO - 2018-05-02 15:11:56 --> Output Class Initialized
INFO - 2018-05-02 15:11:57 --> Security Class Initialized
DEBUG - 2018-05-02 15:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:57 --> Config Class Initialized
INFO - 2018-05-02 15:11:57 --> Input Class Initialized
INFO - 2018-05-02 15:11:57 --> Hooks Class Initialized
INFO - 2018-05-02 15:11:57 --> Language Class Initialized
DEBUG - 2018-05-02 15:11:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:11:57 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:57 --> Loader Class Initialized
INFO - 2018-05-02 15:11:57 --> URI Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:57 --> Router Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:57 --> Output Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:57 --> Config Class Initialized
INFO - 2018-05-02 15:11:57 --> Security Class Initialized
INFO - 2018-05-02 15:11:57 --> Hooks Class Initialized
INFO - 2018-05-02 15:11:57 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-02 15:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-02 15:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:57 --> Utf8 Class Initialized
INFO - 2018-05-02 15:11:57 --> Input Class Initialized
INFO - 2018-05-02 15:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:57 --> Language Class Initialized
INFO - 2018-05-02 15:11:57 --> URI Class Initialized
INFO - 2018-05-02 15:11:57 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:57 --> Router Class Initialized
INFO - 2018-05-02 15:11:57 --> Loader Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:57 --> Output Class Initialized
INFO - 2018-05-02 15:11:57 --> Model Class Initialized
INFO - 2018-05-02 15:11:57 --> Controller Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:57 --> Security Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: date_helper
DEBUG - 2018-05-02 15:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:11:57 --> Database Driver Class Initialized
INFO - 2018-05-02 15:11:57 --> Input Class Initialized
INFO - 2018-05-02 15:11:57 --> Language Class Initialized
DEBUG - 2018-05-02 15:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:57 --> Loader Class Initialized
INFO - 2018-05-02 15:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:57 --> Helper loaded: url_helper
INFO - 2018-05-02 15:11:57 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: form_helper
INFO - 2018-05-02 15:11:57 --> Model Class Initialized
INFO - 2018-05-02 15:11:57 --> Helper loaded: date_helper
INFO - 2018-05-02 15:11:57 --> Controller Class Initialized
INFO - 2018-05-02 15:11:57 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:11:57 --> Form Validation Class Initialized
INFO - 2018-05-02 15:11:57 --> Model Class Initialized
INFO - 2018-05-02 15:11:57 --> Controller Class Initialized
INFO - 2018-05-02 15:14:02 --> Config Class Initialized
INFO - 2018-05-02 15:14:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:14:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:14:02 --> Utf8 Class Initialized
INFO - 2018-05-02 15:14:02 --> URI Class Initialized
DEBUG - 2018-05-02 15:14:02 --> No URI present. Default controller set.
INFO - 2018-05-02 15:14:02 --> Router Class Initialized
INFO - 2018-05-02 15:14:02 --> Output Class Initialized
INFO - 2018-05-02 15:14:02 --> Security Class Initialized
DEBUG - 2018-05-02 15:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:14:02 --> Input Class Initialized
INFO - 2018-05-02 15:14:02 --> Language Class Initialized
INFO - 2018-05-02 15:14:02 --> Loader Class Initialized
INFO - 2018-05-02 15:14:02 --> Helper loaded: url_helper
INFO - 2018-05-02 15:14:02 --> Helper loaded: form_helper
INFO - 2018-05-02 15:14:02 --> Helper loaded: date_helper
INFO - 2018-05-02 15:14:02 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:14:02 --> Form Validation Class Initialized
INFO - 2018-05-02 15:14:02 --> Model Class Initialized
INFO - 2018-05-02 15:14:02 --> Controller Class Initialized
INFO - 2018-05-02 15:14:02 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-02 15:14:02 --> Final output sent to browser
DEBUG - 2018-05-02 15:14:02 --> Total execution time: 0.4081
INFO - 2018-05-02 15:17:52 --> Config Class Initialized
INFO - 2018-05-02 15:17:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:17:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:17:52 --> Utf8 Class Initialized
INFO - 2018-05-02 15:17:52 --> URI Class Initialized
INFO - 2018-05-02 15:17:52 --> Router Class Initialized
INFO - 2018-05-02 15:17:52 --> Output Class Initialized
INFO - 2018-05-02 15:17:52 --> Security Class Initialized
DEBUG - 2018-05-02 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:17:52 --> Input Class Initialized
INFO - 2018-05-02 15:17:52 --> Language Class Initialized
INFO - 2018-05-02 15:17:52 --> Loader Class Initialized
INFO - 2018-05-02 15:17:52 --> Helper loaded: url_helper
INFO - 2018-05-02 15:17:52 --> Helper loaded: form_helper
INFO - 2018-05-02 15:17:52 --> Helper loaded: date_helper
INFO - 2018-05-02 15:17:52 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:17:52 --> Form Validation Class Initialized
INFO - 2018-05-02 15:17:52 --> Model Class Initialized
INFO - 2018-05-02 15:17:52 --> Controller Class Initialized
INFO - 2018-05-02 15:17:52 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-02 15:17:52 --> Final output sent to browser
DEBUG - 2018-05-02 15:17:52 --> Total execution time: 0.4719
INFO - 2018-05-02 15:17:58 --> Config Class Initialized
INFO - 2018-05-02 15:17:58 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:17:58 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:17:58 --> Utf8 Class Initialized
INFO - 2018-05-02 15:17:58 --> URI Class Initialized
INFO - 2018-05-02 15:17:58 --> Router Class Initialized
INFO - 2018-05-02 15:17:58 --> Output Class Initialized
INFO - 2018-05-02 15:17:58 --> Security Class Initialized
DEBUG - 2018-05-02 15:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:17:58 --> Input Class Initialized
INFO - 2018-05-02 15:17:58 --> Language Class Initialized
INFO - 2018-05-02 15:17:58 --> Loader Class Initialized
INFO - 2018-05-02 15:17:58 --> Helper loaded: url_helper
INFO - 2018-05-02 15:17:58 --> Helper loaded: form_helper
INFO - 2018-05-02 15:17:58 --> Helper loaded: date_helper
INFO - 2018-05-02 15:17:58 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:17:58 --> Form Validation Class Initialized
INFO - 2018-05-02 15:17:58 --> Model Class Initialized
INFO - 2018-05-02 15:17:58 --> Controller Class Initialized
INFO - 2018-05-02 15:17:58 --> Config Class Initialized
INFO - 2018-05-02 15:17:58 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:17:58 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:17:58 --> Utf8 Class Initialized
INFO - 2018-05-02 15:17:58 --> URI Class Initialized
INFO - 2018-05-02 15:17:59 --> Router Class Initialized
INFO - 2018-05-02 15:17:59 --> Output Class Initialized
INFO - 2018-05-02 15:17:59 --> Security Class Initialized
DEBUG - 2018-05-02 15:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:17:59 --> Input Class Initialized
INFO - 2018-05-02 15:17:59 --> Language Class Initialized
INFO - 2018-05-02 15:17:59 --> Loader Class Initialized
INFO - 2018-05-02 15:17:59 --> Helper loaded: url_helper
INFO - 2018-05-02 15:17:59 --> Helper loaded: form_helper
INFO - 2018-05-02 15:17:59 --> Helper loaded: date_helper
INFO - 2018-05-02 15:17:59 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:17:59 --> Form Validation Class Initialized
INFO - 2018-05-02 15:17:59 --> Model Class Initialized
INFO - 2018-05-02 15:17:59 --> Controller Class Initialized
INFO - 2018-05-02 15:17:59 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-02 15:17:59 --> Final output sent to browser
DEBUG - 2018-05-02 15:17:59 --> Total execution time: 0.6266
INFO - 2018-05-02 15:17:59 --> Config Class Initialized
INFO - 2018-05-02 15:17:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:17:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:17:59 --> Utf8 Class Initialized
INFO - 2018-05-02 15:17:59 --> URI Class Initialized
INFO - 2018-05-02 15:17:59 --> Router Class Initialized
INFO - 2018-05-02 15:17:59 --> Output Class Initialized
INFO - 2018-05-02 15:17:59 --> Security Class Initialized
DEBUG - 2018-05-02 15:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:17:59 --> Input Class Initialized
INFO - 2018-05-02 15:17:59 --> Language Class Initialized
ERROR - 2018-05-02 15:17:59 --> 404 Page Not Found: Main/css
INFO - 2018-05-02 15:18:02 --> Config Class Initialized
INFO - 2018-05-02 15:18:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:18:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:18:02 --> Utf8 Class Initialized
INFO - 2018-05-02 15:18:02 --> URI Class Initialized
INFO - 2018-05-02 15:18:02 --> Router Class Initialized
INFO - 2018-05-02 15:18:02 --> Output Class Initialized
INFO - 2018-05-02 15:18:02 --> Security Class Initialized
DEBUG - 2018-05-02 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:18:02 --> Input Class Initialized
INFO - 2018-05-02 15:18:02 --> Language Class Initialized
INFO - 2018-05-02 15:18:02 --> Loader Class Initialized
INFO - 2018-05-02 15:18:02 --> Helper loaded: url_helper
INFO - 2018-05-02 15:18:02 --> Helper loaded: form_helper
INFO - 2018-05-02 15:18:02 --> Helper loaded: date_helper
INFO - 2018-05-02 15:18:02 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:18:02 --> Form Validation Class Initialized
INFO - 2018-05-02 15:18:02 --> Model Class Initialized
INFO - 2018-05-02 15:18:02 --> Controller Class Initialized
INFO - 2018-05-02 15:18:02 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-02 15:18:02 --> Final output sent to browser
DEBUG - 2018-05-02 15:18:02 --> Total execution time: 0.6548
INFO - 2018-05-02 15:18:02 --> Config Class Initialized
INFO - 2018-05-02 15:18:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:18:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:18:02 --> Utf8 Class Initialized
INFO - 2018-05-02 15:18:03 --> URI Class Initialized
INFO - 2018-05-02 15:18:03 --> Router Class Initialized
INFO - 2018-05-02 15:18:03 --> Output Class Initialized
INFO - 2018-05-02 15:18:03 --> Security Class Initialized
DEBUG - 2018-05-02 15:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:18:03 --> Input Class Initialized
INFO - 2018-05-02 15:18:03 --> Language Class Initialized
ERROR - 2018-05-02 15:18:03 --> 404 Page Not Found: Main/css
INFO - 2018-05-02 15:18:03 --> Config Class Initialized
INFO - 2018-05-02 15:18:03 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:18:03 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:18:03 --> Utf8 Class Initialized
INFO - 2018-05-02 15:18:03 --> URI Class Initialized
INFO - 2018-05-02 15:18:03 --> Router Class Initialized
INFO - 2018-05-02 15:18:03 --> Output Class Initialized
INFO - 2018-05-02 15:18:03 --> Security Class Initialized
DEBUG - 2018-05-02 15:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:18:03 --> Input Class Initialized
INFO - 2018-05-02 15:18:03 --> Language Class Initialized
INFO - 2018-05-02 15:18:03 --> Loader Class Initialized
INFO - 2018-05-02 15:18:03 --> Helper loaded: url_helper
INFO - 2018-05-02 15:18:03 --> Helper loaded: form_helper
INFO - 2018-05-02 15:18:03 --> Helper loaded: date_helper
INFO - 2018-05-02 15:18:03 --> Database Driver Class Initialized
DEBUG - 2018-05-02 15:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:18:03 --> Form Validation Class Initialized
INFO - 2018-05-02 15:18:03 --> Model Class Initialized
INFO - 2018-05-02 15:18:04 --> Controller Class Initialized
