<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-03 03:37:39 --> Config Class Initialized
INFO - 2018-05-03 03:37:39 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:37:39 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:37:39 --> Utf8 Class Initialized
INFO - 2018-05-03 03:37:39 --> URI Class Initialized
DEBUG - 2018-05-03 03:37:39 --> No URI present. Default controller set.
INFO - 2018-05-03 03:37:39 --> Router Class Initialized
INFO - 2018-05-03 03:37:40 --> Output Class Initialized
INFO - 2018-05-03 03:37:40 --> Security Class Initialized
DEBUG - 2018-05-03 03:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:37:40 --> Input Class Initialized
INFO - 2018-05-03 03:37:40 --> Language Class Initialized
INFO - 2018-05-03 03:37:40 --> Loader Class Initialized
INFO - 2018-05-03 03:37:40 --> Helper loaded: url_helper
INFO - 2018-05-03 03:37:40 --> Helper loaded: form_helper
INFO - 2018-05-03 03:37:40 --> Helper loaded: date_helper
INFO - 2018-05-03 03:37:41 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:37:41 --> Form Validation Class Initialized
INFO - 2018-05-03 03:37:41 --> Model Class Initialized
INFO - 2018-05-03 03:37:41 --> Controller Class Initialized
INFO - 2018-05-03 03:37:41 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-03 03:37:41 --> Final output sent to browser
DEBUG - 2018-05-03 03:37:41 --> Total execution time: 2.4259
INFO - 2018-05-03 03:37:56 --> Config Class Initialized
INFO - 2018-05-03 03:37:56 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:37:56 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:37:56 --> Utf8 Class Initialized
INFO - 2018-05-03 03:37:56 --> URI Class Initialized
INFO - 2018-05-03 03:37:56 --> Router Class Initialized
INFO - 2018-05-03 03:37:56 --> Output Class Initialized
INFO - 2018-05-03 03:37:56 --> Security Class Initialized
DEBUG - 2018-05-03 03:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:37:56 --> Input Class Initialized
INFO - 2018-05-03 03:37:56 --> Language Class Initialized
INFO - 2018-05-03 03:37:56 --> Loader Class Initialized
INFO - 2018-05-03 03:37:56 --> Helper loaded: url_helper
INFO - 2018-05-03 03:37:56 --> Helper loaded: form_helper
INFO - 2018-05-03 03:37:56 --> Helper loaded: date_helper
INFO - 2018-05-03 03:37:56 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:37:56 --> Form Validation Class Initialized
INFO - 2018-05-03 03:37:56 --> Model Class Initialized
INFO - 2018-05-03 03:37:56 --> Controller Class Initialized
INFO - 2018-05-03 03:37:56 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-03 03:37:56 --> Final output sent to browser
DEBUG - 2018-05-03 03:37:56 --> Total execution time: 0.4745
INFO - 2018-05-03 03:38:42 --> Config Class Initialized
INFO - 2018-05-03 03:38:42 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:42 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:42 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:42 --> URI Class Initialized
INFO - 2018-05-03 03:38:42 --> Router Class Initialized
INFO - 2018-05-03 03:38:42 --> Output Class Initialized
INFO - 2018-05-03 03:38:42 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:42 --> Input Class Initialized
INFO - 2018-05-03 03:38:42 --> Language Class Initialized
INFO - 2018-05-03 03:38:42 --> Loader Class Initialized
INFO - 2018-05-03 03:38:42 --> Helper loaded: url_helper
INFO - 2018-05-03 03:38:42 --> Helper loaded: form_helper
INFO - 2018-05-03 03:38:42 --> Helper loaded: date_helper
INFO - 2018-05-03 03:38:42 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:38:42 --> Form Validation Class Initialized
INFO - 2018-05-03 03:38:42 --> Model Class Initialized
INFO - 2018-05-03 03:38:42 --> Controller Class Initialized
INFO - 2018-05-03 03:38:42 --> Config Class Initialized
INFO - 2018-05-03 03:38:42 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:43 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:43 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:43 --> URI Class Initialized
INFO - 2018-05-03 03:38:43 --> Router Class Initialized
INFO - 2018-05-03 03:38:43 --> Output Class Initialized
INFO - 2018-05-03 03:38:43 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:43 --> Input Class Initialized
INFO - 2018-05-03 03:38:43 --> Language Class Initialized
INFO - 2018-05-03 03:38:43 --> Loader Class Initialized
INFO - 2018-05-03 03:38:43 --> Helper loaded: url_helper
INFO - 2018-05-03 03:38:43 --> Helper loaded: form_helper
INFO - 2018-05-03 03:38:43 --> Helper loaded: date_helper
INFO - 2018-05-03 03:38:43 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:38:43 --> Form Validation Class Initialized
INFO - 2018-05-03 03:38:43 --> Model Class Initialized
INFO - 2018-05-03 03:38:43 --> Controller Class Initialized
INFO - 2018-05-03 03:38:43 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-03 03:38:43 --> Final output sent to browser
DEBUG - 2018-05-03 03:38:43 --> Total execution time: 0.7731
INFO - 2018-05-03 03:38:43 --> Config Class Initialized
INFO - 2018-05-03 03:38:43 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:44 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:44 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:44 --> URI Class Initialized
INFO - 2018-05-03 03:38:44 --> Router Class Initialized
INFO - 2018-05-03 03:38:44 --> Output Class Initialized
INFO - 2018-05-03 03:38:44 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:44 --> Input Class Initialized
INFO - 2018-05-03 03:38:44 --> Language Class Initialized
ERROR - 2018-05-03 03:38:44 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:38:44 --> Config Class Initialized
INFO - 2018-05-03 03:38:44 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:44 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:44 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:44 --> URI Class Initialized
INFO - 2018-05-03 03:38:44 --> Router Class Initialized
INFO - 2018-05-03 03:38:44 --> Output Class Initialized
INFO - 2018-05-03 03:38:44 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:45 --> Input Class Initialized
INFO - 2018-05-03 03:38:45 --> Language Class Initialized
ERROR - 2018-05-03 03:38:45 --> 404 Page Not Found: Main/img
INFO - 2018-05-03 03:38:56 --> Config Class Initialized
INFO - 2018-05-03 03:38:56 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:56 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:56 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:56 --> URI Class Initialized
INFO - 2018-05-03 03:38:56 --> Router Class Initialized
INFO - 2018-05-03 03:38:56 --> Output Class Initialized
INFO - 2018-05-03 03:38:56 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:56 --> Input Class Initialized
INFO - 2018-05-03 03:38:56 --> Language Class Initialized
INFO - 2018-05-03 03:38:56 --> Loader Class Initialized
INFO - 2018-05-03 03:38:56 --> Helper loaded: url_helper
INFO - 2018-05-03 03:38:56 --> Helper loaded: form_helper
INFO - 2018-05-03 03:38:56 --> Helper loaded: date_helper
INFO - 2018-05-03 03:38:56 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:38:56 --> Form Validation Class Initialized
INFO - 2018-05-03 03:38:56 --> Model Class Initialized
INFO - 2018-05-03 03:38:56 --> Controller Class Initialized
INFO - 2018-05-03 03:38:56 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:38:56 --> Final output sent to browser
DEBUG - 2018-05-03 03:38:56 --> Total execution time: 0.5282
INFO - 2018-05-03 03:38:56 --> Config Class Initialized
INFO - 2018-05-03 03:38:56 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:56 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:56 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:56 --> URI Class Initialized
INFO - 2018-05-03 03:38:56 --> Router Class Initialized
INFO - 2018-05-03 03:38:56 --> Output Class Initialized
INFO - 2018-05-03 03:38:56 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:57 --> Input Class Initialized
INFO - 2018-05-03 03:38:57 --> Language Class Initialized
ERROR - 2018-05-03 03:38:57 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:38:57 --> Config Class Initialized
INFO - 2018-05-03 03:38:57 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:38:57 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:38:57 --> Utf8 Class Initialized
INFO - 2018-05-03 03:38:57 --> URI Class Initialized
INFO - 2018-05-03 03:38:57 --> Router Class Initialized
INFO - 2018-05-03 03:38:57 --> Output Class Initialized
INFO - 2018-05-03 03:38:57 --> Security Class Initialized
DEBUG - 2018-05-03 03:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:38:57 --> Input Class Initialized
INFO - 2018-05-03 03:38:57 --> Language Class Initialized
INFO - 2018-05-03 03:38:57 --> Loader Class Initialized
INFO - 2018-05-03 03:38:57 --> Helper loaded: url_helper
INFO - 2018-05-03 03:38:57 --> Helper loaded: form_helper
INFO - 2018-05-03 03:38:57 --> Helper loaded: date_helper
INFO - 2018-05-03 03:38:57 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:38:57 --> Form Validation Class Initialized
INFO - 2018-05-03 03:38:57 --> Model Class Initialized
INFO - 2018-05-03 03:38:57 --> Controller Class Initialized
INFO - 2018-05-03 03:39:06 --> Config Class Initialized
INFO - 2018-05-03 03:39:06 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:39:06 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:39:06 --> Utf8 Class Initialized
INFO - 2018-05-03 03:39:06 --> URI Class Initialized
INFO - 2018-05-03 03:39:06 --> Router Class Initialized
INFO - 2018-05-03 03:39:06 --> Output Class Initialized
INFO - 2018-05-03 03:39:06 --> Security Class Initialized
DEBUG - 2018-05-03 03:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:39:06 --> Input Class Initialized
INFO - 2018-05-03 03:39:07 --> Language Class Initialized
INFO - 2018-05-03 03:39:07 --> Loader Class Initialized
INFO - 2018-05-03 03:39:07 --> Helper loaded: url_helper
INFO - 2018-05-03 03:39:07 --> Helper loaded: form_helper
INFO - 2018-05-03 03:39:07 --> Helper loaded: date_helper
INFO - 2018-05-03 03:39:07 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:39:07 --> Form Validation Class Initialized
INFO - 2018-05-03 03:39:07 --> Model Class Initialized
INFO - 2018-05-03 03:39:07 --> Controller Class Initialized
ERROR - 2018-05-03 03:39:07 --> Query error: Unknown column 'patient_ID' in 'field list' - Invalid query: INSERT INTO `pending_appointment` (`appointment_id`, `patient_ID`, `contact_number`, `date`, `time`, `clinic_procedure`) VALUES (NULL, '102', '09234644144', '2018-05-03', '10:00', 'Prenatal Checkup')
INFO - 2018-05-03 03:39:07 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-03 03:48:46 --> Config Class Initialized
INFO - 2018-05-03 03:48:46 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:46 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:46 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:46 --> URI Class Initialized
INFO - 2018-05-03 03:48:46 --> Router Class Initialized
INFO - 2018-05-03 03:48:46 --> Output Class Initialized
INFO - 2018-05-03 03:48:46 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:46 --> Input Class Initialized
INFO - 2018-05-03 03:48:46 --> Language Class Initialized
INFO - 2018-05-03 03:48:46 --> Loader Class Initialized
INFO - 2018-05-03 03:48:46 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:46 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:46 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:46 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:46 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:46 --> Model Class Initialized
INFO - 2018-05-03 03:48:46 --> Controller Class Initialized
INFO - 2018-05-03 03:48:46 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:48:46 --> Final output sent to browser
DEBUG - 2018-05-03 03:48:46 --> Total execution time: 0.4570
INFO - 2018-05-03 03:48:46 --> Config Class Initialized
INFO - 2018-05-03 03:48:47 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:47 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:47 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:47 --> URI Class Initialized
INFO - 2018-05-03 03:48:47 --> Router Class Initialized
INFO - 2018-05-03 03:48:47 --> Output Class Initialized
INFO - 2018-05-03 03:48:47 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:47 --> Input Class Initialized
INFO - 2018-05-03 03:48:47 --> Language Class Initialized
ERROR - 2018-05-03 03:48:47 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:48:47 --> Config Class Initialized
INFO - 2018-05-03 03:48:47 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:47 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:47 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:47 --> URI Class Initialized
INFO - 2018-05-03 03:48:47 --> Router Class Initialized
INFO - 2018-05-03 03:48:47 --> Output Class Initialized
INFO - 2018-05-03 03:48:47 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:47 --> Input Class Initialized
INFO - 2018-05-03 03:48:47 --> Language Class Initialized
INFO - 2018-05-03 03:48:47 --> Loader Class Initialized
INFO - 2018-05-03 03:48:47 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:47 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:47 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:47 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:47 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:47 --> Model Class Initialized
INFO - 2018-05-03 03:48:47 --> Controller Class Initialized
INFO - 2018-05-03 03:48:47 --> Config Class Initialized
INFO - 2018-05-03 03:48:47 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:48 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:48 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:48 --> URI Class Initialized
INFO - 2018-05-03 03:48:48 --> Router Class Initialized
INFO - 2018-05-03 03:48:48 --> Output Class Initialized
INFO - 2018-05-03 03:48:48 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:48 --> Input Class Initialized
INFO - 2018-05-03 03:48:48 --> Language Class Initialized
INFO - 2018-05-03 03:48:48 --> Loader Class Initialized
INFO - 2018-05-03 03:48:48 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:48 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:48 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:48 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:48 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:48 --> Model Class Initialized
INFO - 2018-05-03 03:48:48 --> Controller Class Initialized
INFO - 2018-05-03 03:48:48 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:48:48 --> Final output sent to browser
DEBUG - 2018-05-03 03:48:48 --> Total execution time: 0.5212
INFO - 2018-05-03 03:48:48 --> Config Class Initialized
INFO - 2018-05-03 03:48:48 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:48 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:48 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:48 --> URI Class Initialized
INFO - 2018-05-03 03:48:48 --> Router Class Initialized
INFO - 2018-05-03 03:48:48 --> Output Class Initialized
INFO - 2018-05-03 03:48:48 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:48 --> Input Class Initialized
INFO - 2018-05-03 03:48:48 --> Language Class Initialized
ERROR - 2018-05-03 03:48:48 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:48:48 --> Config Class Initialized
INFO - 2018-05-03 03:48:48 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:48 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:48 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:49 --> URI Class Initialized
INFO - 2018-05-03 03:48:49 --> Router Class Initialized
INFO - 2018-05-03 03:48:49 --> Output Class Initialized
INFO - 2018-05-03 03:48:49 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:49 --> Input Class Initialized
INFO - 2018-05-03 03:48:49 --> Language Class Initialized
INFO - 2018-05-03 03:48:49 --> Loader Class Initialized
INFO - 2018-05-03 03:48:49 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:49 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:49 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:49 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:49 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:49 --> Model Class Initialized
INFO - 2018-05-03 03:48:49 --> Controller Class Initialized
INFO - 2018-05-03 03:48:55 --> Config Class Initialized
INFO - 2018-05-03 03:48:55 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:55 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:55 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:55 --> URI Class Initialized
INFO - 2018-05-03 03:48:55 --> Router Class Initialized
INFO - 2018-05-03 03:48:55 --> Output Class Initialized
INFO - 2018-05-03 03:48:55 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:56 --> Input Class Initialized
INFO - 2018-05-03 03:48:56 --> Language Class Initialized
INFO - 2018-05-03 03:48:56 --> Loader Class Initialized
INFO - 2018-05-03 03:48:56 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:56 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:56 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:56 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:56 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:56 --> Model Class Initialized
INFO - 2018-05-03 03:48:56 --> Controller Class Initialized
INFO - 2018-05-03 03:48:56 --> Config Class Initialized
INFO - 2018-05-03 03:48:56 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:56 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:56 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:56 --> URI Class Initialized
INFO - 2018-05-03 03:48:56 --> Router Class Initialized
INFO - 2018-05-03 03:48:56 --> Output Class Initialized
INFO - 2018-05-03 03:48:56 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:56 --> Input Class Initialized
INFO - 2018-05-03 03:48:56 --> Language Class Initialized
INFO - 2018-05-03 03:48:56 --> Loader Class Initialized
INFO - 2018-05-03 03:48:56 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:56 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:56 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:56 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:56 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:56 --> Model Class Initialized
INFO - 2018-05-03 03:48:56 --> Controller Class Initialized
INFO - 2018-05-03 03:48:56 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:48:56 --> Final output sent to browser
DEBUG - 2018-05-03 03:48:56 --> Total execution time: 0.5221
INFO - 2018-05-03 03:48:56 --> Config Class Initialized
INFO - 2018-05-03 03:48:56 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:56 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:56 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:56 --> URI Class Initialized
INFO - 2018-05-03 03:48:56 --> Router Class Initialized
INFO - 2018-05-03 03:48:57 --> Output Class Initialized
INFO - 2018-05-03 03:48:57 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:57 --> Input Class Initialized
INFO - 2018-05-03 03:48:57 --> Language Class Initialized
ERROR - 2018-05-03 03:48:57 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:48:57 --> Config Class Initialized
INFO - 2018-05-03 03:48:57 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:48:57 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:48:57 --> Utf8 Class Initialized
INFO - 2018-05-03 03:48:57 --> URI Class Initialized
INFO - 2018-05-03 03:48:57 --> Router Class Initialized
INFO - 2018-05-03 03:48:57 --> Output Class Initialized
INFO - 2018-05-03 03:48:57 --> Security Class Initialized
DEBUG - 2018-05-03 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:48:57 --> Input Class Initialized
INFO - 2018-05-03 03:48:57 --> Language Class Initialized
INFO - 2018-05-03 03:48:57 --> Loader Class Initialized
INFO - 2018-05-03 03:48:57 --> Helper loaded: url_helper
INFO - 2018-05-03 03:48:57 --> Helper loaded: form_helper
INFO - 2018-05-03 03:48:57 --> Helper loaded: date_helper
INFO - 2018-05-03 03:48:57 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:48:57 --> Form Validation Class Initialized
INFO - 2018-05-03 03:48:57 --> Model Class Initialized
INFO - 2018-05-03 03:48:57 --> Controller Class Initialized
INFO - 2018-05-03 03:49:09 --> Config Class Initialized
INFO - 2018-05-03 03:49:09 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:49:09 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:49:09 --> Utf8 Class Initialized
INFO - 2018-05-03 03:49:09 --> URI Class Initialized
INFO - 2018-05-03 03:49:09 --> Router Class Initialized
INFO - 2018-05-03 03:49:09 --> Output Class Initialized
INFO - 2018-05-03 03:49:09 --> Security Class Initialized
DEBUG - 2018-05-03 03:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:49:09 --> Input Class Initialized
INFO - 2018-05-03 03:49:09 --> Language Class Initialized
INFO - 2018-05-03 03:49:09 --> Loader Class Initialized
INFO - 2018-05-03 03:49:09 --> Helper loaded: url_helper
INFO - 2018-05-03 03:49:09 --> Helper loaded: form_helper
INFO - 2018-05-03 03:49:09 --> Helper loaded: date_helper
INFO - 2018-05-03 03:49:09 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:49:09 --> Form Validation Class Initialized
INFO - 2018-05-03 03:49:09 --> Model Class Initialized
INFO - 2018-05-03 03:49:09 --> Controller Class Initialized
INFO - 2018-05-03 03:49:09 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:49:09 --> Final output sent to browser
DEBUG - 2018-05-03 03:49:09 --> Total execution time: 0.4415
INFO - 2018-05-03 03:49:09 --> Config Class Initialized
INFO - 2018-05-03 03:49:09 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:49:09 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:49:09 --> Utf8 Class Initialized
INFO - 2018-05-03 03:49:10 --> URI Class Initialized
INFO - 2018-05-03 03:49:10 --> Router Class Initialized
INFO - 2018-05-03 03:49:10 --> Output Class Initialized
INFO - 2018-05-03 03:49:10 --> Security Class Initialized
DEBUG - 2018-05-03 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:49:10 --> Input Class Initialized
INFO - 2018-05-03 03:49:10 --> Language Class Initialized
ERROR - 2018-05-03 03:49:10 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:49:10 --> Config Class Initialized
INFO - 2018-05-03 03:49:10 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:49:10 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:49:10 --> Utf8 Class Initialized
INFO - 2018-05-03 03:49:10 --> URI Class Initialized
INFO - 2018-05-03 03:49:10 --> Router Class Initialized
INFO - 2018-05-03 03:49:10 --> Output Class Initialized
INFO - 2018-05-03 03:49:10 --> Security Class Initialized
DEBUG - 2018-05-03 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:49:10 --> Input Class Initialized
INFO - 2018-05-03 03:49:10 --> Language Class Initialized
INFO - 2018-05-03 03:49:10 --> Loader Class Initialized
INFO - 2018-05-03 03:49:10 --> Helper loaded: url_helper
INFO - 2018-05-03 03:49:10 --> Helper loaded: form_helper
INFO - 2018-05-03 03:49:10 --> Helper loaded: date_helper
INFO - 2018-05-03 03:49:10 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:49:10 --> Form Validation Class Initialized
INFO - 2018-05-03 03:49:10 --> Model Class Initialized
INFO - 2018-05-03 03:49:10 --> Controller Class Initialized
INFO - 2018-05-03 03:50:46 --> Config Class Initialized
INFO - 2018-05-03 03:50:46 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:50:46 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:46 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:46 --> URI Class Initialized
INFO - 2018-05-03 03:50:46 --> Router Class Initialized
INFO - 2018-05-03 03:50:46 --> Output Class Initialized
INFO - 2018-05-03 03:50:46 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:46 --> Input Class Initialized
INFO - 2018-05-03 03:50:46 --> Language Class Initialized
INFO - 2018-05-03 03:50:46 --> Loader Class Initialized
INFO - 2018-05-03 03:50:47 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:47 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:47 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:47 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:47 --> Config Class Initialized
INFO - 2018-05-03 03:50:47 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:47 --> Hooks Class Initialized
INFO - 2018-05-03 03:50:47 --> Model Class Initialized
DEBUG - 2018-05-03 03:50:47 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:47 --> Controller Class Initialized
INFO - 2018-05-03 03:50:47 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:47 --> URI Class Initialized
INFO - 2018-05-03 03:50:47 --> Router Class Initialized
INFO - 2018-05-03 03:50:47 --> Output Class Initialized
INFO - 2018-05-03 03:50:47 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:47 --> Input Class Initialized
INFO - 2018-05-03 03:50:47 --> Language Class Initialized
INFO - 2018-05-03 03:50:47 --> Loader Class Initialized
INFO - 2018-05-03 03:50:47 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:47 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:47 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:47 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:47 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:47 --> Model Class Initialized
INFO - 2018-05-03 03:50:47 --> Controller Class Initialized
INFO - 2018-05-03 03:50:47 --> Config Class Initialized
INFO - 2018-05-03 03:50:47 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:50:47 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:47 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:47 --> URI Class Initialized
INFO - 2018-05-03 03:50:47 --> Router Class Initialized
INFO - 2018-05-03 03:50:47 --> Output Class Initialized
INFO - 2018-05-03 03:50:47 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:47 --> Input Class Initialized
INFO - 2018-05-03 03:50:47 --> Language Class Initialized
INFO - 2018-05-03 03:50:47 --> Loader Class Initialized
INFO - 2018-05-03 03:50:47 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:47 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:47 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:47 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:47 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:47 --> Model Class Initialized
INFO - 2018-05-03 03:50:47 --> Controller Class Initialized
INFO - 2018-05-03 03:50:48 --> Config Class Initialized
INFO - 2018-05-03 03:50:48 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:50:48 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:48 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:48 --> URI Class Initialized
INFO - 2018-05-03 03:50:48 --> Router Class Initialized
INFO - 2018-05-03 03:50:49 --> Output Class Initialized
INFO - 2018-05-03 03:50:49 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:49 --> Input Class Initialized
INFO - 2018-05-03 03:50:49 --> Language Class Initialized
INFO - 2018-05-03 03:50:49 --> Loader Class Initialized
INFO - 2018-05-03 03:50:49 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:49 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:49 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:49 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:49 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:49 --> Model Class Initialized
INFO - 2018-05-03 03:50:49 --> Controller Class Initialized
INFO - 2018-05-03 03:50:56 --> Config Class Initialized
INFO - 2018-05-03 03:50:56 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:50:56 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:56 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:56 --> URI Class Initialized
INFO - 2018-05-03 03:50:56 --> Router Class Initialized
INFO - 2018-05-03 03:50:56 --> Output Class Initialized
INFO - 2018-05-03 03:50:56 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:56 --> Input Class Initialized
INFO - 2018-05-03 03:50:56 --> Language Class Initialized
INFO - 2018-05-03 03:50:56 --> Loader Class Initialized
INFO - 2018-05-03 03:50:56 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:56 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:56 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:56 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:56 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:56 --> Model Class Initialized
INFO - 2018-05-03 03:50:56 --> Controller Class Initialized
INFO - 2018-05-03 03:50:58 --> Config Class Initialized
INFO - 2018-05-03 03:50:58 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:58 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:58 --> URI Class Initialized
INFO - 2018-05-03 03:50:58 --> Router Class Initialized
INFO - 2018-05-03 03:50:58 --> Output Class Initialized
INFO - 2018-05-03 03:50:58 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:58 --> Input Class Initialized
INFO - 2018-05-03 03:50:58 --> Language Class Initialized
INFO - 2018-05-03 03:50:59 --> Loader Class Initialized
INFO - 2018-05-03 03:50:59 --> Config Class Initialized
INFO - 2018-05-03 03:50:59 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:59 --> Hooks Class Initialized
INFO - 2018-05-03 03:50:59 --> Helper loaded: form_helper
DEBUG - 2018-05-03 03:50:59 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:59 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:59 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:59 --> URI Class Initialized
INFO - 2018-05-03 03:50:59 --> Database Driver Class Initialized
INFO - 2018-05-03 03:50:59 --> Router Class Initialized
DEBUG - 2018-05-03 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:59 --> Output Class Initialized
INFO - 2018-05-03 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:59 --> Security Class Initialized
INFO - 2018-05-03 03:50:59 --> Form Validation Class Initialized
DEBUG - 2018-05-03 03:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:59 --> Model Class Initialized
INFO - 2018-05-03 03:50:59 --> Input Class Initialized
INFO - 2018-05-03 03:50:59 --> Controller Class Initialized
INFO - 2018-05-03 03:50:59 --> Language Class Initialized
INFO - 2018-05-03 03:50:59 --> Loader Class Initialized
INFO - 2018-05-03 03:50:59 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:59 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:59 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:59 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:59 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:59 --> Model Class Initialized
INFO - 2018-05-03 03:50:59 --> Controller Class Initialized
INFO - 2018-05-03 03:50:59 --> Config Class Initialized
INFO - 2018-05-03 03:50:59 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:50:59 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:50:59 --> Utf8 Class Initialized
INFO - 2018-05-03 03:50:59 --> URI Class Initialized
INFO - 2018-05-03 03:50:59 --> Router Class Initialized
INFO - 2018-05-03 03:50:59 --> Output Class Initialized
INFO - 2018-05-03 03:50:59 --> Security Class Initialized
DEBUG - 2018-05-03 03:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:50:59 --> Input Class Initialized
INFO - 2018-05-03 03:50:59 --> Language Class Initialized
INFO - 2018-05-03 03:50:59 --> Loader Class Initialized
INFO - 2018-05-03 03:50:59 --> Helper loaded: url_helper
INFO - 2018-05-03 03:50:59 --> Helper loaded: form_helper
INFO - 2018-05-03 03:50:59 --> Helper loaded: date_helper
INFO - 2018-05-03 03:50:59 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:50:59 --> Form Validation Class Initialized
INFO - 2018-05-03 03:50:59 --> Model Class Initialized
INFO - 2018-05-03 03:50:59 --> Controller Class Initialized
INFO - 2018-05-03 03:57:53 --> Config Class Initialized
INFO - 2018-05-03 03:57:53 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:57:53 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:57:53 --> Utf8 Class Initialized
INFO - 2018-05-03 03:57:53 --> URI Class Initialized
INFO - 2018-05-03 03:57:53 --> Router Class Initialized
INFO - 2018-05-03 03:57:53 --> Output Class Initialized
INFO - 2018-05-03 03:57:53 --> Security Class Initialized
DEBUG - 2018-05-03 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:57:53 --> Input Class Initialized
INFO - 2018-05-03 03:57:53 --> Language Class Initialized
INFO - 2018-05-03 03:57:53 --> Loader Class Initialized
INFO - 2018-05-03 03:57:53 --> Helper loaded: url_helper
INFO - 2018-05-03 03:57:53 --> Helper loaded: form_helper
INFO - 2018-05-03 03:57:53 --> Helper loaded: date_helper
INFO - 2018-05-03 03:57:53 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:57:53 --> Form Validation Class Initialized
INFO - 2018-05-03 03:57:53 --> Model Class Initialized
INFO - 2018-05-03 03:57:53 --> Controller Class Initialized
INFO - 2018-05-03 03:57:53 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:57:53 --> Final output sent to browser
DEBUG - 2018-05-03 03:57:54 --> Total execution time: 0.6270
INFO - 2018-05-03 03:57:54 --> Config Class Initialized
INFO - 2018-05-03 03:57:54 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:57:54 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:57:54 --> Utf8 Class Initialized
INFO - 2018-05-03 03:57:54 --> URI Class Initialized
INFO - 2018-05-03 03:57:54 --> Router Class Initialized
INFO - 2018-05-03 03:57:54 --> Output Class Initialized
INFO - 2018-05-03 03:57:54 --> Security Class Initialized
DEBUG - 2018-05-03 03:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:57:54 --> Input Class Initialized
INFO - 2018-05-03 03:57:54 --> Language Class Initialized
ERROR - 2018-05-03 03:57:54 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:57:54 --> Config Class Initialized
INFO - 2018-05-03 03:57:54 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:57:54 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:57:54 --> Utf8 Class Initialized
INFO - 2018-05-03 03:57:54 --> URI Class Initialized
INFO - 2018-05-03 03:57:54 --> Router Class Initialized
INFO - 2018-05-03 03:57:54 --> Output Class Initialized
INFO - 2018-05-03 03:57:54 --> Security Class Initialized
DEBUG - 2018-05-03 03:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:57:54 --> Input Class Initialized
INFO - 2018-05-03 03:57:54 --> Language Class Initialized
INFO - 2018-05-03 03:57:54 --> Loader Class Initialized
INFO - 2018-05-03 03:57:54 --> Helper loaded: url_helper
INFO - 2018-05-03 03:57:54 --> Helper loaded: form_helper
INFO - 2018-05-03 03:57:54 --> Helper loaded: date_helper
INFO - 2018-05-03 03:57:54 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:57:55 --> Form Validation Class Initialized
INFO - 2018-05-03 03:57:55 --> Model Class Initialized
INFO - 2018-05-03 03:57:55 --> Controller Class Initialized
INFO - 2018-05-03 03:58:11 --> Config Class Initialized
INFO - 2018-05-03 03:58:11 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:11 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:11 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:11 --> URI Class Initialized
INFO - 2018-05-03 03:58:11 --> Router Class Initialized
INFO - 2018-05-03 03:58:11 --> Output Class Initialized
INFO - 2018-05-03 03:58:11 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:11 --> Input Class Initialized
INFO - 2018-05-03 03:58:11 --> Language Class Initialized
INFO - 2018-05-03 03:58:11 --> Loader Class Initialized
INFO - 2018-05-03 03:58:11 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:11 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:11 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:11 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:11 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:11 --> Model Class Initialized
INFO - 2018-05-03 03:58:11 --> Controller Class Initialized
INFO - 2018-05-03 03:58:11 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:58:11 --> Final output sent to browser
DEBUG - 2018-05-03 03:58:12 --> Total execution time: 0.5125
INFO - 2018-05-03 03:58:12 --> Config Class Initialized
INFO - 2018-05-03 03:58:12 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:12 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:12 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:12 --> URI Class Initialized
INFO - 2018-05-03 03:58:12 --> Router Class Initialized
INFO - 2018-05-03 03:58:12 --> Output Class Initialized
INFO - 2018-05-03 03:58:12 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:12 --> Input Class Initialized
INFO - 2018-05-03 03:58:12 --> Language Class Initialized
ERROR - 2018-05-03 03:58:12 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:58:12 --> Config Class Initialized
INFO - 2018-05-03 03:58:12 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:12 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:12 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:12 --> URI Class Initialized
INFO - 2018-05-03 03:58:12 --> Router Class Initialized
INFO - 2018-05-03 03:58:12 --> Output Class Initialized
INFO - 2018-05-03 03:58:12 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:12 --> Input Class Initialized
INFO - 2018-05-03 03:58:12 --> Language Class Initialized
INFO - 2018-05-03 03:58:12 --> Loader Class Initialized
INFO - 2018-05-03 03:58:12 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:12 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:12 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:12 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:12 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:12 --> Model Class Initialized
INFO - 2018-05-03 03:58:12 --> Controller Class Initialized
INFO - 2018-05-03 03:58:25 --> Config Class Initialized
INFO - 2018-05-03 03:58:25 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:25 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:25 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:25 --> URI Class Initialized
INFO - 2018-05-03 03:58:26 --> Router Class Initialized
INFO - 2018-05-03 03:58:26 --> Output Class Initialized
INFO - 2018-05-03 03:58:26 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:26 --> Input Class Initialized
INFO - 2018-05-03 03:58:26 --> Language Class Initialized
INFO - 2018-05-03 03:58:26 --> Loader Class Initialized
INFO - 2018-05-03 03:58:26 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:26 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:26 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:26 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:26 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:26 --> Model Class Initialized
INFO - 2018-05-03 03:58:26 --> Controller Class Initialized
ERROR - 2018-05-03 09:58:26 --> Query error: Unknown column 'appointment_id' in 'field list' - Invalid query: INSERT INTO `calendar_events` (`appointment_id`, `patient_ID`, `contact_number`, `start`, `end`, `clinic_procedure`) VALUES (NULL, '102', '09234644144', '2018-05-03 10:00', '2018-05-03 11:00', 'Prenatal Checkup')
INFO - 2018-05-03 09:58:26 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-03 03:58:42 --> Config Class Initialized
INFO - 2018-05-03 03:58:42 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:42 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:42 --> URI Class Initialized
INFO - 2018-05-03 03:58:42 --> Router Class Initialized
INFO - 2018-05-03 03:58:42 --> Output Class Initialized
INFO - 2018-05-03 03:58:42 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:42 --> Input Class Initialized
INFO - 2018-05-03 03:58:42 --> Language Class Initialized
INFO - 2018-05-03 03:58:42 --> Loader Class Initialized
INFO - 2018-05-03 03:58:42 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:42 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:42 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:42 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:42 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:42 --> Model Class Initialized
INFO - 2018-05-03 03:58:42 --> Controller Class Initialized
INFO - 2018-05-03 03:58:42 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:58:42 --> Final output sent to browser
DEBUG - 2018-05-03 03:58:42 --> Total execution time: 0.4638
INFO - 2018-05-03 03:58:42 --> Config Class Initialized
INFO - 2018-05-03 03:58:42 --> Hooks Class Initialized
INFO - 2018-05-03 03:58:42 --> Config Class Initialized
DEBUG - 2018-05-03 03:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:42 --> Hooks Class Initialized
INFO - 2018-05-03 03:58:42 --> Utf8 Class Initialized
DEBUG - 2018-05-03 03:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:42 --> URI Class Initialized
INFO - 2018-05-03 03:58:42 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:42 --> URI Class Initialized
INFO - 2018-05-03 03:58:42 --> Router Class Initialized
INFO - 2018-05-03 03:58:42 --> Router Class Initialized
INFO - 2018-05-03 03:58:42 --> Output Class Initialized
INFO - 2018-05-03 03:58:42 --> Output Class Initialized
INFO - 2018-05-03 03:58:42 --> Security Class Initialized
INFO - 2018-05-03 03:58:42 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-03 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:42 --> Input Class Initialized
INFO - 2018-05-03 03:58:42 --> Input Class Initialized
INFO - 2018-05-03 03:58:42 --> Language Class Initialized
INFO - 2018-05-03 03:58:42 --> Language Class Initialized
ERROR - 2018-05-03 03:58:42 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:58:42 --> Loader Class Initialized
INFO - 2018-05-03 03:58:43 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:43 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:43 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:43 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:43 --> Config Class Initialized
INFO - 2018-05-03 03:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:43 --> Hooks Class Initialized
INFO - 2018-05-03 03:58:43 --> Form Validation Class Initialized
DEBUG - 2018-05-03 03:58:43 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:43 --> Model Class Initialized
INFO - 2018-05-03 03:58:43 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:43 --> Controller Class Initialized
INFO - 2018-05-03 03:58:43 --> URI Class Initialized
INFO - 2018-05-03 03:58:43 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:58:43 --> Router Class Initialized
INFO - 2018-05-03 03:58:43 --> Final output sent to browser
INFO - 2018-05-03 03:58:43 --> Config Class Initialized
DEBUG - 2018-05-03 03:58:43 --> Total execution time: 0.6931
INFO - 2018-05-03 03:58:43 --> Output Class Initialized
INFO - 2018-05-03 03:58:43 --> Hooks Class Initialized
INFO - 2018-05-03 03:58:43 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:43 --> UTF-8 Support Enabled
DEBUG - 2018-05-03 03:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:43 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:43 --> Input Class Initialized
INFO - 2018-05-03 03:58:43 --> URI Class Initialized
INFO - 2018-05-03 03:58:43 --> Language Class Initialized
INFO - 2018-05-03 03:58:43 --> Router Class Initialized
INFO - 2018-05-03 03:58:43 --> Loader Class Initialized
INFO - 2018-05-03 03:58:43 --> Output Class Initialized
INFO - 2018-05-03 03:58:43 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:43 --> Security Class Initialized
INFO - 2018-05-03 03:58:43 --> Helper loaded: form_helper
DEBUG - 2018-05-03 03:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:43 --> Input Class Initialized
INFO - 2018-05-03 03:58:43 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:43 --> Language Class Initialized
INFO - 2018-05-03 03:58:43 --> Database Driver Class Initialized
ERROR - 2018-05-03 03:58:43 --> 404 Page Not Found: Main/css
DEBUG - 2018-05-03 03:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:43 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:43 --> Model Class Initialized
INFO - 2018-05-03 03:58:43 --> Controller Class Initialized
INFO - 2018-05-03 03:58:43 --> Config Class Initialized
INFO - 2018-05-03 03:58:43 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:43 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:43 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:43 --> Config Class Initialized
INFO - 2018-05-03 03:58:43 --> URI Class Initialized
INFO - 2018-05-03 03:58:43 --> Hooks Class Initialized
INFO - 2018-05-03 03:58:43 --> Router Class Initialized
DEBUG - 2018-05-03 03:58:43 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:43 --> Output Class Initialized
INFO - 2018-05-03 03:58:43 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:44 --> URI Class Initialized
INFO - 2018-05-03 03:58:44 --> Security Class Initialized
INFO - 2018-05-03 03:58:44 --> Router Class Initialized
DEBUG - 2018-05-03 03:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:44 --> Output Class Initialized
INFO - 2018-05-03 03:58:44 --> Input Class Initialized
INFO - 2018-05-03 03:58:44 --> Language Class Initialized
INFO - 2018-05-03 03:58:44 --> Security Class Initialized
INFO - 2018-05-03 03:58:44 --> Loader Class Initialized
DEBUG - 2018-05-03 03:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:44 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:44 --> Input Class Initialized
INFO - 2018-05-03 03:58:44 --> Language Class Initialized
INFO - 2018-05-03 03:58:44 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:44 --> Loader Class Initialized
INFO - 2018-05-03 03:58:44 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:44 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:44 --> Database Driver Class Initialized
INFO - 2018-05-03 03:58:44 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:44 --> Helper loaded: date_helper
DEBUG - 2018-05-03 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:44 --> Database Driver Class Initialized
INFO - 2018-05-03 03:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-03 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:44 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:44 --> Model Class Initialized
INFO - 2018-05-03 03:58:44 --> Controller Class Initialized
INFO - 2018-05-03 03:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:44 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:44 --> Model Class Initialized
INFO - 2018-05-03 03:58:44 --> Controller Class Initialized
INFO - 2018-05-03 03:58:44 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:58:44 --> Final output sent to browser
DEBUG - 2018-05-03 03:58:44 --> Total execution time: 0.6345
INFO - 2018-05-03 03:58:44 --> Config Class Initialized
INFO - 2018-05-03 03:58:44 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:44 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:44 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:44 --> URI Class Initialized
INFO - 2018-05-03 03:58:44 --> Router Class Initialized
INFO - 2018-05-03 03:58:44 --> Output Class Initialized
INFO - 2018-05-03 03:58:44 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:44 --> Input Class Initialized
INFO - 2018-05-03 03:58:44 --> Language Class Initialized
ERROR - 2018-05-03 03:58:44 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:58:44 --> Config Class Initialized
INFO - 2018-05-03 03:58:44 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:45 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:45 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:45 --> URI Class Initialized
INFO - 2018-05-03 03:58:45 --> Router Class Initialized
INFO - 2018-05-03 03:58:45 --> Output Class Initialized
INFO - 2018-05-03 03:58:45 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:45 --> Input Class Initialized
INFO - 2018-05-03 03:58:45 --> Language Class Initialized
INFO - 2018-05-03 03:58:45 --> Loader Class Initialized
INFO - 2018-05-03 03:58:45 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:45 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:45 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:45 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:45 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:45 --> Model Class Initialized
INFO - 2018-05-03 03:58:45 --> Controller Class Initialized
INFO - 2018-05-03 03:58:51 --> Config Class Initialized
INFO - 2018-05-03 03:58:51 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:51 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:52 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:52 --> URI Class Initialized
INFO - 2018-05-03 03:58:52 --> Router Class Initialized
INFO - 2018-05-03 03:58:52 --> Output Class Initialized
INFO - 2018-05-03 03:58:52 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:52 --> Input Class Initialized
INFO - 2018-05-03 03:58:52 --> Language Class Initialized
INFO - 2018-05-03 03:58:52 --> Loader Class Initialized
INFO - 2018-05-03 03:58:52 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:52 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:52 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:52 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:52 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:52 --> Model Class Initialized
INFO - 2018-05-03 03:58:52 --> Controller Class Initialized
INFO - 2018-05-03 03:58:52 --> Config Class Initialized
INFO - 2018-05-03 03:58:52 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:52 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:52 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:52 --> URI Class Initialized
INFO - 2018-05-03 03:58:52 --> Router Class Initialized
INFO - 2018-05-03 03:58:52 --> Output Class Initialized
INFO - 2018-05-03 03:58:52 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:52 --> Input Class Initialized
INFO - 2018-05-03 03:58:52 --> Language Class Initialized
INFO - 2018-05-03 03:58:52 --> Loader Class Initialized
INFO - 2018-05-03 03:58:52 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:52 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:52 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:52 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:52 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:52 --> Model Class Initialized
INFO - 2018-05-03 03:58:53 --> Controller Class Initialized
INFO - 2018-05-03 03:58:53 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:58:53 --> Final output sent to browser
DEBUG - 2018-05-03 03:58:53 --> Total execution time: 0.4859
INFO - 2018-05-03 03:58:53 --> Config Class Initialized
INFO - 2018-05-03 03:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:53 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:53 --> URI Class Initialized
INFO - 2018-05-03 03:58:53 --> Router Class Initialized
INFO - 2018-05-03 03:58:53 --> Output Class Initialized
INFO - 2018-05-03 03:58:53 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:53 --> Input Class Initialized
INFO - 2018-05-03 03:58:53 --> Language Class Initialized
ERROR - 2018-05-03 03:58:53 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:58:53 --> Config Class Initialized
INFO - 2018-05-03 03:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:53 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:53 --> URI Class Initialized
INFO - 2018-05-03 03:58:53 --> Router Class Initialized
INFO - 2018-05-03 03:58:53 --> Output Class Initialized
INFO - 2018-05-03 03:58:53 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:53 --> Input Class Initialized
INFO - 2018-05-03 03:58:53 --> Language Class Initialized
INFO - 2018-05-03 03:58:53 --> Loader Class Initialized
INFO - 2018-05-03 03:58:53 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:53 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:53 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:53 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:53 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:53 --> Model Class Initialized
INFO - 2018-05-03 03:58:53 --> Controller Class Initialized
INFO - 2018-05-03 03:58:54 --> Config Class Initialized
INFO - 2018-05-03 03:58:54 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:54 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:54 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:54 --> URI Class Initialized
INFO - 2018-05-03 03:58:54 --> Router Class Initialized
INFO - 2018-05-03 03:58:54 --> Output Class Initialized
INFO - 2018-05-03 03:58:54 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:54 --> Input Class Initialized
INFO - 2018-05-03 03:58:54 --> Language Class Initialized
INFO - 2018-05-03 03:58:54 --> Loader Class Initialized
INFO - 2018-05-03 03:58:54 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:54 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:54 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:54 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:54 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:55 --> Model Class Initialized
INFO - 2018-05-03 03:58:55 --> Controller Class Initialized
INFO - 2018-05-03 03:58:55 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:58:55 --> Final output sent to browser
INFO - 2018-05-03 03:58:55 --> Config Class Initialized
DEBUG - 2018-05-03 03:58:55 --> Total execution time: 0.5713
INFO - 2018-05-03 03:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:55 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:55 --> URI Class Initialized
INFO - 2018-05-03 03:58:55 --> Router Class Initialized
INFO - 2018-05-03 03:58:55 --> Output Class Initialized
INFO - 2018-05-03 03:58:55 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:55 --> Input Class Initialized
INFO - 2018-05-03 03:58:55 --> Language Class Initialized
ERROR - 2018-05-03 03:58:55 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:58:55 --> Config Class Initialized
INFO - 2018-05-03 03:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:58:55 --> Utf8 Class Initialized
INFO - 2018-05-03 03:58:55 --> URI Class Initialized
INFO - 2018-05-03 03:58:55 --> Router Class Initialized
INFO - 2018-05-03 03:58:55 --> Output Class Initialized
INFO - 2018-05-03 03:58:55 --> Security Class Initialized
DEBUG - 2018-05-03 03:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:58:55 --> Input Class Initialized
INFO - 2018-05-03 03:58:55 --> Language Class Initialized
INFO - 2018-05-03 03:58:55 --> Loader Class Initialized
INFO - 2018-05-03 03:58:55 --> Helper loaded: url_helper
INFO - 2018-05-03 03:58:55 --> Helper loaded: form_helper
INFO - 2018-05-03 03:58:55 --> Helper loaded: date_helper
INFO - 2018-05-03 03:58:55 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:58:56 --> Form Validation Class Initialized
INFO - 2018-05-03 03:58:56 --> Model Class Initialized
INFO - 2018-05-03 03:58:56 --> Controller Class Initialized
INFO - 2018-05-03 03:59:43 --> Config Class Initialized
INFO - 2018-05-03 03:59:43 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:59:43 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:59:44 --> Utf8 Class Initialized
INFO - 2018-05-03 03:59:44 --> URI Class Initialized
INFO - 2018-05-03 03:59:44 --> Router Class Initialized
INFO - 2018-05-03 03:59:44 --> Output Class Initialized
INFO - 2018-05-03 03:59:44 --> Security Class Initialized
DEBUG - 2018-05-03 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:59:44 --> Input Class Initialized
INFO - 2018-05-03 03:59:44 --> Language Class Initialized
INFO - 2018-05-03 03:59:44 --> Loader Class Initialized
INFO - 2018-05-03 03:59:44 --> Helper loaded: url_helper
INFO - 2018-05-03 03:59:44 --> Helper loaded: form_helper
INFO - 2018-05-03 03:59:44 --> Helper loaded: date_helper
INFO - 2018-05-03 03:59:44 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:59:44 --> Form Validation Class Initialized
INFO - 2018-05-03 03:59:44 --> Model Class Initialized
INFO - 2018-05-03 03:59:44 --> Controller Class Initialized
INFO - 2018-05-03 03:59:44 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 03:59:44 --> Final output sent to browser
DEBUG - 2018-05-03 03:59:44 --> Total execution time: 0.4908
INFO - 2018-05-03 03:59:44 --> Config Class Initialized
INFO - 2018-05-03 03:59:44 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:59:44 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:59:44 --> Utf8 Class Initialized
INFO - 2018-05-03 03:59:44 --> URI Class Initialized
INFO - 2018-05-03 03:59:44 --> Router Class Initialized
INFO - 2018-05-03 03:59:44 --> Output Class Initialized
INFO - 2018-05-03 03:59:44 --> Security Class Initialized
DEBUG - 2018-05-03 03:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:59:44 --> Input Class Initialized
INFO - 2018-05-03 03:59:44 --> Language Class Initialized
ERROR - 2018-05-03 03:59:44 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 03:59:44 --> Config Class Initialized
INFO - 2018-05-03 03:59:44 --> Hooks Class Initialized
DEBUG - 2018-05-03 03:59:45 --> UTF-8 Support Enabled
INFO - 2018-05-03 03:59:45 --> Utf8 Class Initialized
INFO - 2018-05-03 03:59:45 --> URI Class Initialized
INFO - 2018-05-03 03:59:45 --> Router Class Initialized
INFO - 2018-05-03 03:59:45 --> Output Class Initialized
INFO - 2018-05-03 03:59:45 --> Security Class Initialized
DEBUG - 2018-05-03 03:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 03:59:45 --> Input Class Initialized
INFO - 2018-05-03 03:59:45 --> Language Class Initialized
INFO - 2018-05-03 03:59:45 --> Loader Class Initialized
INFO - 2018-05-03 03:59:45 --> Helper loaded: url_helper
INFO - 2018-05-03 03:59:45 --> Helper loaded: form_helper
INFO - 2018-05-03 03:59:45 --> Helper loaded: date_helper
INFO - 2018-05-03 03:59:45 --> Database Driver Class Initialized
DEBUG - 2018-05-03 03:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 03:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 03:59:45 --> Form Validation Class Initialized
INFO - 2018-05-03 03:59:45 --> Model Class Initialized
INFO - 2018-05-03 03:59:45 --> Controller Class Initialized
ERROR - 2018-05-03 03:59:45 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
ERROR - 2018-05-03 03:59:45 --> Severity: Notice --> Undefined property: stdClass::$title C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-03 03:59:45 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-03 03:59:45 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
ERROR - 2018-05-03 03:59:45 --> Severity: Notice --> Undefined property: stdClass::$title C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-03 03:59:45 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-03 04:00:22 --> Config Class Initialized
INFO - 2018-05-03 04:00:22 --> Hooks Class Initialized
DEBUG - 2018-05-03 04:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-03 04:00:22 --> Utf8 Class Initialized
INFO - 2018-05-03 04:00:22 --> URI Class Initialized
INFO - 2018-05-03 04:00:22 --> Router Class Initialized
INFO - 2018-05-03 04:00:22 --> Output Class Initialized
INFO - 2018-05-03 04:00:22 --> Security Class Initialized
DEBUG - 2018-05-03 04:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 04:00:22 --> Input Class Initialized
INFO - 2018-05-03 04:00:22 --> Language Class Initialized
ERROR - 2018-05-03 04:00:22 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 04:02:22 --> Config Class Initialized
INFO - 2018-05-03 04:02:22 --> Hooks Class Initialized
DEBUG - 2018-05-03 04:02:22 --> UTF-8 Support Enabled
INFO - 2018-05-03 04:02:22 --> Utf8 Class Initialized
INFO - 2018-05-03 04:02:22 --> URI Class Initialized
INFO - 2018-05-03 04:02:22 --> Router Class Initialized
INFO - 2018-05-03 04:02:22 --> Output Class Initialized
INFO - 2018-05-03 04:02:22 --> Security Class Initialized
DEBUG - 2018-05-03 04:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 04:02:22 --> Input Class Initialized
INFO - 2018-05-03 04:02:22 --> Language Class Initialized
INFO - 2018-05-03 04:02:22 --> Loader Class Initialized
INFO - 2018-05-03 04:02:22 --> Helper loaded: url_helper
INFO - 2018-05-03 04:02:22 --> Helper loaded: form_helper
INFO - 2018-05-03 04:02:22 --> Helper loaded: date_helper
INFO - 2018-05-03 04:02:22 --> Database Driver Class Initialized
DEBUG - 2018-05-03 04:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 04:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 04:02:22 --> Form Validation Class Initialized
INFO - 2018-05-03 04:02:22 --> Model Class Initialized
INFO - 2018-05-03 04:02:22 --> Controller Class Initialized
INFO - 2018-05-03 04:02:23 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-03 04:02:23 --> Final output sent to browser
DEBUG - 2018-05-03 04:02:23 --> Total execution time: 0.4776
INFO - 2018-05-03 04:02:23 --> Config Class Initialized
INFO - 2018-05-03 04:02:23 --> Hooks Class Initialized
DEBUG - 2018-05-03 04:02:23 --> UTF-8 Support Enabled
INFO - 2018-05-03 04:02:23 --> Utf8 Class Initialized
INFO - 2018-05-03 04:02:23 --> URI Class Initialized
INFO - 2018-05-03 04:02:23 --> Router Class Initialized
INFO - 2018-05-03 04:02:23 --> Output Class Initialized
INFO - 2018-05-03 04:02:23 --> Security Class Initialized
DEBUG - 2018-05-03 04:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 04:02:23 --> Input Class Initialized
INFO - 2018-05-03 04:02:23 --> Language Class Initialized
ERROR - 2018-05-03 04:02:23 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 04:02:23 --> Config Class Initialized
INFO - 2018-05-03 04:02:23 --> Hooks Class Initialized
DEBUG - 2018-05-03 04:02:23 --> UTF-8 Support Enabled
INFO - 2018-05-03 04:02:23 --> Utf8 Class Initialized
INFO - 2018-05-03 04:02:23 --> URI Class Initialized
INFO - 2018-05-03 04:02:23 --> Router Class Initialized
INFO - 2018-05-03 04:02:23 --> Output Class Initialized
INFO - 2018-05-03 04:02:23 --> Security Class Initialized
DEBUG - 2018-05-03 04:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 04:02:23 --> Input Class Initialized
INFO - 2018-05-03 04:02:23 --> Language Class Initialized
INFO - 2018-05-03 04:02:23 --> Loader Class Initialized
INFO - 2018-05-03 04:02:23 --> Helper loaded: url_helper
INFO - 2018-05-03 04:02:24 --> Helper loaded: form_helper
INFO - 2018-05-03 04:02:24 --> Helper loaded: date_helper
INFO - 2018-05-03 04:02:24 --> Database Driver Class Initialized
DEBUG - 2018-05-03 04:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 04:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 04:02:24 --> Form Validation Class Initialized
INFO - 2018-05-03 04:02:24 --> Model Class Initialized
INFO - 2018-05-03 04:02:24 --> Controller Class Initialized
ERROR - 2018-05-03 04:02:24 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
ERROR - 2018-05-03 04:02:24 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
INFO - 2018-05-03 16:06:12 --> Config Class Initialized
INFO - 2018-05-03 16:06:12 --> Hooks Class Initialized
DEBUG - 2018-05-03 16:06:12 --> UTF-8 Support Enabled
INFO - 2018-05-03 16:06:12 --> Utf8 Class Initialized
INFO - 2018-05-03 16:06:12 --> URI Class Initialized
DEBUG - 2018-05-03 16:06:13 --> No URI present. Default controller set.
INFO - 2018-05-03 16:06:13 --> Router Class Initialized
INFO - 2018-05-03 16:06:13 --> Output Class Initialized
INFO - 2018-05-03 16:06:13 --> Security Class Initialized
DEBUG - 2018-05-03 16:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 16:06:13 --> Input Class Initialized
INFO - 2018-05-03 16:06:13 --> Language Class Initialized
INFO - 2018-05-03 16:06:13 --> Loader Class Initialized
INFO - 2018-05-03 16:06:13 --> Helper loaded: url_helper
INFO - 2018-05-03 16:06:14 --> Helper loaded: form_helper
INFO - 2018-05-03 16:06:14 --> Helper loaded: date_helper
INFO - 2018-05-03 16:06:14 --> Database Driver Class Initialized
DEBUG - 2018-05-03 16:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 16:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 16:06:14 --> Form Validation Class Initialized
INFO - 2018-05-03 16:06:14 --> Model Class Initialized
INFO - 2018-05-03 16:06:14 --> Controller Class Initialized
INFO - 2018-05-03 16:06:15 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-03 16:06:15 --> Final output sent to browser
DEBUG - 2018-05-03 16:06:15 --> Total execution time: 2.9064
INFO - 2018-05-03 16:16:10 --> Config Class Initialized
INFO - 2018-05-03 16:16:11 --> Hooks Class Initialized
DEBUG - 2018-05-03 16:16:11 --> UTF-8 Support Enabled
INFO - 2018-05-03 16:16:11 --> Utf8 Class Initialized
INFO - 2018-05-03 16:16:11 --> URI Class Initialized
INFO - 2018-05-03 16:16:11 --> Router Class Initialized
INFO - 2018-05-03 16:16:11 --> Output Class Initialized
INFO - 2018-05-03 16:16:11 --> Security Class Initialized
DEBUG - 2018-05-03 16:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 16:16:11 --> Input Class Initialized
INFO - 2018-05-03 16:16:11 --> Language Class Initialized
INFO - 2018-05-03 16:16:11 --> Loader Class Initialized
INFO - 2018-05-03 16:16:11 --> Helper loaded: url_helper
INFO - 2018-05-03 16:16:11 --> Helper loaded: form_helper
INFO - 2018-05-03 16:16:11 --> Helper loaded: date_helper
INFO - 2018-05-03 16:16:11 --> Database Driver Class Initialized
DEBUG - 2018-05-03 16:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 16:16:11 --> Form Validation Class Initialized
INFO - 2018-05-03 16:16:11 --> Model Class Initialized
INFO - 2018-05-03 16:16:11 --> Controller Class Initialized
INFO - 2018-05-03 16:16:11 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-03 16:16:11 --> Final output sent to browser
DEBUG - 2018-05-03 16:16:11 --> Total execution time: 0.9482
INFO - 2018-05-03 16:16:19 --> Config Class Initialized
INFO - 2018-05-03 16:16:19 --> Hooks Class Initialized
DEBUG - 2018-05-03 16:16:19 --> UTF-8 Support Enabled
INFO - 2018-05-03 16:16:19 --> Utf8 Class Initialized
INFO - 2018-05-03 16:16:19 --> URI Class Initialized
INFO - 2018-05-03 16:16:19 --> Router Class Initialized
INFO - 2018-05-03 16:16:19 --> Output Class Initialized
INFO - 2018-05-03 16:16:19 --> Security Class Initialized
DEBUG - 2018-05-03 16:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 16:16:19 --> Input Class Initialized
INFO - 2018-05-03 16:16:19 --> Language Class Initialized
INFO - 2018-05-03 16:16:19 --> Loader Class Initialized
INFO - 2018-05-03 16:16:19 --> Helper loaded: url_helper
INFO - 2018-05-03 16:16:19 --> Helper loaded: form_helper
INFO - 2018-05-03 16:16:19 --> Helper loaded: date_helper
INFO - 2018-05-03 16:16:19 --> Database Driver Class Initialized
DEBUG - 2018-05-03 16:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 16:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 16:16:19 --> Form Validation Class Initialized
INFO - 2018-05-03 16:16:19 --> Model Class Initialized
INFO - 2018-05-03 16:16:19 --> Controller Class Initialized
INFO - 2018-05-03 16:16:20 --> Config Class Initialized
INFO - 2018-05-03 16:16:20 --> Hooks Class Initialized
DEBUG - 2018-05-03 16:16:20 --> UTF-8 Support Enabled
INFO - 2018-05-03 16:16:20 --> Utf8 Class Initialized
INFO - 2018-05-03 16:16:20 --> URI Class Initialized
INFO - 2018-05-03 16:16:20 --> Router Class Initialized
INFO - 2018-05-03 16:16:20 --> Output Class Initialized
INFO - 2018-05-03 16:16:20 --> Security Class Initialized
DEBUG - 2018-05-03 16:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 16:16:20 --> Input Class Initialized
INFO - 2018-05-03 16:16:20 --> Language Class Initialized
INFO - 2018-05-03 16:16:20 --> Loader Class Initialized
INFO - 2018-05-03 16:16:20 --> Helper loaded: url_helper
INFO - 2018-05-03 16:16:20 --> Helper loaded: form_helper
INFO - 2018-05-03 16:16:20 --> Helper loaded: date_helper
INFO - 2018-05-03 16:16:20 --> Database Driver Class Initialized
DEBUG - 2018-05-03 16:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-03 16:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-03 16:16:20 --> Form Validation Class Initialized
INFO - 2018-05-03 16:16:20 --> Model Class Initialized
INFO - 2018-05-03 16:16:20 --> Controller Class Initialized
INFO - 2018-05-03 16:16:21 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-03 16:16:21 --> Final output sent to browser
DEBUG - 2018-05-03 16:16:21 --> Total execution time: 1.3520
INFO - 2018-05-03 16:16:21 --> Config Class Initialized
INFO - 2018-05-03 16:16:21 --> Hooks Class Initialized
DEBUG - 2018-05-03 16:16:21 --> UTF-8 Support Enabled
INFO - 2018-05-03 16:16:21 --> Utf8 Class Initialized
INFO - 2018-05-03 16:16:21 --> URI Class Initialized
INFO - 2018-05-03 16:16:21 --> Router Class Initialized
INFO - 2018-05-03 16:16:21 --> Output Class Initialized
INFO - 2018-05-03 16:16:21 --> Security Class Initialized
DEBUG - 2018-05-03 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 16:16:21 --> Input Class Initialized
INFO - 2018-05-03 16:16:21 --> Language Class Initialized
ERROR - 2018-05-03 16:16:21 --> 404 Page Not Found: Main/css
INFO - 2018-05-03 16:16:45 --> Config Class Initialized
INFO - 2018-05-03 16:16:45 --> Hooks Class Initialized
DEBUG - 2018-05-03 16:16:45 --> UTF-8 Support Enabled
INFO - 2018-05-03 16:16:45 --> Utf8 Class Initialized
INFO - 2018-05-03 16:16:45 --> URI Class Initialized
INFO - 2018-05-03 16:16:45 --> Router Class Initialized
INFO - 2018-05-03 16:16:45 --> Output Class Initialized
INFO - 2018-05-03 16:16:45 --> Security Class Initialized
DEBUG - 2018-05-03 16:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-03 16:16:45 --> Input Class Initialized
INFO - 2018-05-03 16:16:45 --> Language Class Initialized
ERROR - 2018-05-03 16:16:45 --> 404 Page Not Found: Main/img
