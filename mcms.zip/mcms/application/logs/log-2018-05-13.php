<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-13 14:04:21 --> Config Class Initialized
INFO - 2018-05-13 14:04:21 --> Hooks Class Initialized
DEBUG - 2018-05-13 14:04:21 --> UTF-8 Support Enabled
INFO - 2018-05-13 14:04:21 --> Utf8 Class Initialized
INFO - 2018-05-13 14:04:21 --> URI Class Initialized
DEBUG - 2018-05-13 14:04:21 --> No URI present. Default controller set.
INFO - 2018-05-13 14:04:21 --> Router Class Initialized
INFO - 2018-05-13 14:04:21 --> Output Class Initialized
INFO - 2018-05-13 14:04:22 --> Security Class Initialized
DEBUG - 2018-05-13 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 14:04:22 --> Input Class Initialized
INFO - 2018-05-13 14:04:22 --> Language Class Initialized
INFO - 2018-05-13 14:04:22 --> Loader Class Initialized
INFO - 2018-05-13 14:04:22 --> Helper loaded: url_helper
INFO - 2018-05-13 14:04:22 --> Helper loaded: form_helper
INFO - 2018-05-13 14:04:22 --> Helper loaded: date_helper
INFO - 2018-05-13 14:04:22 --> Database Driver Class Initialized
DEBUG - 2018-05-13 14:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 14:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 14:04:24 --> Form Validation Class Initialized
INFO - 2018-05-13 14:04:24 --> Model Class Initialized
INFO - 2018-05-13 14:04:24 --> Controller Class Initialized
INFO - 2018-05-13 14:04:24 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-13 14:04:24 --> Final output sent to browser
DEBUG - 2018-05-13 14:04:24 --> Total execution time: 3.6390
INFO - 2018-05-13 14:20:40 --> Config Class Initialized
INFO - 2018-05-13 14:20:40 --> Hooks Class Initialized
DEBUG - 2018-05-13 14:20:40 --> UTF-8 Support Enabled
INFO - 2018-05-13 14:20:40 --> Utf8 Class Initialized
INFO - 2018-05-13 14:20:40 --> URI Class Initialized
DEBUG - 2018-05-13 14:20:40 --> No URI present. Default controller set.
INFO - 2018-05-13 14:20:40 --> Router Class Initialized
INFO - 2018-05-13 14:20:40 --> Output Class Initialized
INFO - 2018-05-13 14:20:40 --> Security Class Initialized
DEBUG - 2018-05-13 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 14:20:40 --> Input Class Initialized
INFO - 2018-05-13 14:20:41 --> Language Class Initialized
INFO - 2018-05-13 14:20:41 --> Loader Class Initialized
INFO - 2018-05-13 14:20:41 --> Helper loaded: url_helper
INFO - 2018-05-13 14:20:41 --> Helper loaded: form_helper
INFO - 2018-05-13 14:20:41 --> Helper loaded: date_helper
INFO - 2018-05-13 14:20:41 --> Database Driver Class Initialized
DEBUG - 2018-05-13 14:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 14:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 14:20:41 --> Form Validation Class Initialized
INFO - 2018-05-13 14:20:41 --> Model Class Initialized
INFO - 2018-05-13 14:20:41 --> Controller Class Initialized
INFO - 2018-05-13 14:20:41 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-13 14:20:41 --> Final output sent to browser
DEBUG - 2018-05-13 14:20:41 --> Total execution time: 0.7639
INFO - 2018-05-13 14:23:16 --> Config Class Initialized
INFO - 2018-05-13 14:23:16 --> Hooks Class Initialized
DEBUG - 2018-05-13 14:23:16 --> UTF-8 Support Enabled
INFO - 2018-05-13 14:23:16 --> Utf8 Class Initialized
INFO - 2018-05-13 14:23:16 --> URI Class Initialized
INFO - 2018-05-13 14:23:16 --> Router Class Initialized
INFO - 2018-05-13 14:23:16 --> Output Class Initialized
INFO - 2018-05-13 14:23:16 --> Security Class Initialized
DEBUG - 2018-05-13 14:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 14:23:16 --> Input Class Initialized
INFO - 2018-05-13 14:23:16 --> Language Class Initialized
INFO - 2018-05-13 14:23:16 --> Loader Class Initialized
INFO - 2018-05-13 14:23:16 --> Helper loaded: url_helper
INFO - 2018-05-13 14:23:16 --> Helper loaded: form_helper
INFO - 2018-05-13 14:23:16 --> Helper loaded: date_helper
INFO - 2018-05-13 14:23:16 --> Database Driver Class Initialized
DEBUG - 2018-05-13 14:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 14:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 14:23:16 --> Form Validation Class Initialized
INFO - 2018-05-13 14:23:16 --> Model Class Initialized
INFO - 2018-05-13 14:23:16 --> Controller Class Initialized
INFO - 2018-05-13 14:23:16 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-13 14:23:16 --> Final output sent to browser
DEBUG - 2018-05-13 14:23:16 --> Total execution time: 0.7634
INFO - 2018-05-13 14:48:56 --> Config Class Initialized
INFO - 2018-05-13 14:48:56 --> Hooks Class Initialized
DEBUG - 2018-05-13 14:48:56 --> UTF-8 Support Enabled
INFO - 2018-05-13 14:48:56 --> Utf8 Class Initialized
INFO - 2018-05-13 14:48:56 --> URI Class Initialized
DEBUG - 2018-05-13 14:48:57 --> No URI present. Default controller set.
INFO - 2018-05-13 14:48:57 --> Router Class Initialized
INFO - 2018-05-13 14:48:57 --> Output Class Initialized
INFO - 2018-05-13 14:48:57 --> Security Class Initialized
DEBUG - 2018-05-13 14:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 14:48:57 --> Input Class Initialized
INFO - 2018-05-13 14:48:57 --> Language Class Initialized
INFO - 2018-05-13 14:48:57 --> Loader Class Initialized
INFO - 2018-05-13 14:48:57 --> Helper loaded: url_helper
INFO - 2018-05-13 14:48:57 --> Helper loaded: form_helper
INFO - 2018-05-13 14:48:57 --> Helper loaded: date_helper
INFO - 2018-05-13 14:48:57 --> Database Driver Class Initialized
DEBUG - 2018-05-13 14:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 14:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 14:48:58 --> Form Validation Class Initialized
INFO - 2018-05-13 14:48:58 --> Model Class Initialized
INFO - 2018-05-13 14:48:58 --> Controller Class Initialized
INFO - 2018-05-13 14:48:58 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-13 14:48:58 --> Final output sent to browser
DEBUG - 2018-05-13 14:48:59 --> Total execution time: 3.0571
INFO - 2018-05-13 15:02:24 --> Config Class Initialized
INFO - 2018-05-13 15:02:24 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:02:24 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:02:24 --> Utf8 Class Initialized
INFO - 2018-05-13 15:02:24 --> URI Class Initialized
INFO - 2018-05-13 15:02:24 --> Router Class Initialized
INFO - 2018-05-13 15:02:24 --> Output Class Initialized
INFO - 2018-05-13 15:02:24 --> Security Class Initialized
DEBUG - 2018-05-13 15:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:02:24 --> Input Class Initialized
INFO - 2018-05-13 15:02:24 --> Language Class Initialized
INFO - 2018-05-13 15:02:24 --> Loader Class Initialized
INFO - 2018-05-13 15:02:24 --> Helper loaded: url_helper
INFO - 2018-05-13 15:02:24 --> Helper loaded: form_helper
INFO - 2018-05-13 15:02:24 --> Helper loaded: date_helper
INFO - 2018-05-13 15:02:24 --> Database Driver Class Initialized
DEBUG - 2018-05-13 15:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 15:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 15:02:24 --> Form Validation Class Initialized
INFO - 2018-05-13 15:02:24 --> Model Class Initialized
INFO - 2018-05-13 15:02:24 --> Controller Class Initialized
INFO - 2018-05-13 15:02:24 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-13 15:02:24 --> Final output sent to browser
DEBUG - 2018-05-13 15:02:24 --> Total execution time: 0.6254
INFO - 2018-05-13 15:02:30 --> Config Class Initialized
INFO - 2018-05-13 15:02:30 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:02:30 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:02:30 --> Utf8 Class Initialized
INFO - 2018-05-13 15:02:30 --> URI Class Initialized
INFO - 2018-05-13 15:02:30 --> Router Class Initialized
INFO - 2018-05-13 15:02:30 --> Output Class Initialized
INFO - 2018-05-13 15:02:30 --> Security Class Initialized
DEBUG - 2018-05-13 15:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:02:30 --> Input Class Initialized
INFO - 2018-05-13 15:02:30 --> Language Class Initialized
INFO - 2018-05-13 15:02:30 --> Loader Class Initialized
INFO - 2018-05-13 15:02:30 --> Helper loaded: url_helper
INFO - 2018-05-13 15:02:30 --> Helper loaded: form_helper
INFO - 2018-05-13 15:02:30 --> Helper loaded: date_helper
INFO - 2018-05-13 15:02:30 --> Database Driver Class Initialized
DEBUG - 2018-05-13 15:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 15:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 15:02:30 --> Form Validation Class Initialized
INFO - 2018-05-13 15:02:30 --> Model Class Initialized
INFO - 2018-05-13 15:02:30 --> Controller Class Initialized
INFO - 2018-05-13 15:02:31 --> Config Class Initialized
INFO - 2018-05-13 15:02:31 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:02:31 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:02:31 --> Utf8 Class Initialized
INFO - 2018-05-13 15:02:31 --> URI Class Initialized
INFO - 2018-05-13 15:02:31 --> Router Class Initialized
INFO - 2018-05-13 15:02:31 --> Output Class Initialized
INFO - 2018-05-13 15:02:31 --> Security Class Initialized
DEBUG - 2018-05-13 15:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:02:31 --> Input Class Initialized
INFO - 2018-05-13 15:02:31 --> Language Class Initialized
INFO - 2018-05-13 15:02:31 --> Loader Class Initialized
INFO - 2018-05-13 15:02:31 --> Helper loaded: url_helper
INFO - 2018-05-13 15:02:31 --> Helper loaded: form_helper
INFO - 2018-05-13 15:02:31 --> Helper loaded: date_helper
INFO - 2018-05-13 15:02:31 --> Database Driver Class Initialized
DEBUG - 2018-05-13 15:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 15:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 15:02:31 --> Form Validation Class Initialized
INFO - 2018-05-13 15:02:32 --> Model Class Initialized
INFO - 2018-05-13 15:02:32 --> Controller Class Initialized
INFO - 2018-05-13 15:02:32 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-13 15:02:32 --> Final output sent to browser
DEBUG - 2018-05-13 15:02:32 --> Total execution time: 1.1831
INFO - 2018-05-13 15:02:32 --> Config Class Initialized
INFO - 2018-05-13 15:02:32 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:02:32 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:02:32 --> Utf8 Class Initialized
INFO - 2018-05-13 15:02:33 --> URI Class Initialized
INFO - 2018-05-13 15:02:33 --> Router Class Initialized
INFO - 2018-05-13 15:02:33 --> Output Class Initialized
INFO - 2018-05-13 15:02:33 --> Security Class Initialized
DEBUG - 2018-05-13 15:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:02:33 --> Input Class Initialized
INFO - 2018-05-13 15:02:33 --> Language Class Initialized
ERROR - 2018-05-13 15:02:33 --> 404 Page Not Found: Main/css
INFO - 2018-05-13 15:03:30 --> Config Class Initialized
INFO - 2018-05-13 15:03:30 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:03:30 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:03:30 --> Utf8 Class Initialized
INFO - 2018-05-13 15:03:30 --> URI Class Initialized
INFO - 2018-05-13 15:03:30 --> Router Class Initialized
INFO - 2018-05-13 15:03:30 --> Output Class Initialized
INFO - 2018-05-13 15:03:30 --> Security Class Initialized
DEBUG - 2018-05-13 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:03:30 --> Input Class Initialized
INFO - 2018-05-13 15:03:30 --> Language Class Initialized
ERROR - 2018-05-13 15:03:30 --> 404 Page Not Found: Main/img
INFO - 2018-05-13 15:32:32 --> Config Class Initialized
INFO - 2018-05-13 15:32:32 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:32:32 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:32:33 --> Utf8 Class Initialized
INFO - 2018-05-13 15:32:33 --> URI Class Initialized
INFO - 2018-05-13 15:32:33 --> Router Class Initialized
INFO - 2018-05-13 15:32:33 --> Output Class Initialized
INFO - 2018-05-13 15:32:33 --> Security Class Initialized
DEBUG - 2018-05-13 15:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:32:33 --> Input Class Initialized
INFO - 2018-05-13 15:32:33 --> Language Class Initialized
INFO - 2018-05-13 15:32:33 --> Loader Class Initialized
INFO - 2018-05-13 15:32:33 --> Helper loaded: url_helper
INFO - 2018-05-13 15:32:33 --> Helper loaded: form_helper
INFO - 2018-05-13 15:32:33 --> Helper loaded: date_helper
INFO - 2018-05-13 15:32:33 --> Database Driver Class Initialized
DEBUG - 2018-05-13 15:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 15:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 15:32:33 --> Form Validation Class Initialized
INFO - 2018-05-13 15:32:33 --> Model Class Initialized
INFO - 2018-05-13 15:32:33 --> Controller Class Initialized
INFO - 2018-05-13 15:32:33 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-13 15:32:33 --> Final output sent to browser
DEBUG - 2018-05-13 15:32:33 --> Total execution time: 0.5402
INFO - 2018-05-13 15:32:33 --> Config Class Initialized
INFO - 2018-05-13 15:32:33 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:32:33 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:32:33 --> Utf8 Class Initialized
INFO - 2018-05-13 15:32:33 --> URI Class Initialized
INFO - 2018-05-13 15:32:33 --> Router Class Initialized
INFO - 2018-05-13 15:32:33 --> Output Class Initialized
INFO - 2018-05-13 15:32:33 --> Security Class Initialized
DEBUG - 2018-05-13 15:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:32:33 --> Input Class Initialized
INFO - 2018-05-13 15:32:33 --> Language Class Initialized
ERROR - 2018-05-13 15:32:33 --> 404 Page Not Found: Main/css
INFO - 2018-05-13 15:32:34 --> Config Class Initialized
INFO - 2018-05-13 15:32:34 --> Hooks Class Initialized
DEBUG - 2018-05-13 15:32:34 --> UTF-8 Support Enabled
INFO - 2018-05-13 15:32:34 --> Utf8 Class Initialized
INFO - 2018-05-13 15:32:34 --> URI Class Initialized
INFO - 2018-05-13 15:32:34 --> Router Class Initialized
INFO - 2018-05-13 15:32:34 --> Output Class Initialized
INFO - 2018-05-13 15:32:34 --> Security Class Initialized
DEBUG - 2018-05-13 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-13 15:32:34 --> Input Class Initialized
INFO - 2018-05-13 15:32:34 --> Language Class Initialized
INFO - 2018-05-13 15:32:34 --> Loader Class Initialized
INFO - 2018-05-13 15:32:34 --> Helper loaded: url_helper
INFO - 2018-05-13 15:32:34 --> Helper loaded: form_helper
INFO - 2018-05-13 15:32:34 --> Helper loaded: date_helper
INFO - 2018-05-13 15:32:34 --> Database Driver Class Initialized
DEBUG - 2018-05-13 15:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-13 15:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-13 15:32:34 --> Form Validation Class Initialized
INFO - 2018-05-13 15:32:34 --> Model Class Initialized
INFO - 2018-05-13 15:32:35 --> Controller Class Initialized
ERROR - 2018-05-13 15:32:35 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
ERROR - 2018-05-13 15:32:35 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
