<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-23 08:57:48 --> Config Class Initialized
INFO - 2018-04-23 08:57:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 08:57:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 08:57:48 --> Utf8 Class Initialized
INFO - 2018-04-23 08:57:49 --> URI Class Initialized
DEBUG - 2018-04-23 08:57:49 --> No URI present. Default controller set.
INFO - 2018-04-23 08:57:49 --> Router Class Initialized
INFO - 2018-04-23 08:57:49 --> Output Class Initialized
INFO - 2018-04-23 08:57:49 --> Security Class Initialized
DEBUG - 2018-04-23 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 08:57:49 --> Input Class Initialized
INFO - 2018-04-23 08:57:49 --> Language Class Initialized
INFO - 2018-04-23 08:57:49 --> Loader Class Initialized
INFO - 2018-04-23 08:57:49 --> Helper loaded: url_helper
INFO - 2018-04-23 08:57:50 --> Helper loaded: form_helper
INFO - 2018-04-23 08:57:50 --> Helper loaded: date_helper
INFO - 2018-04-23 08:57:50 --> Database Driver Class Initialized
DEBUG - 2018-04-23 08:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 08:57:50 --> Form Validation Class Initialized
INFO - 2018-04-23 08:57:50 --> Model Class Initialized
INFO - 2018-04-23 08:57:50 --> Controller Class Initialized
INFO - 2018-04-23 08:57:50 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-04-23 08:57:51 --> Final output sent to browser
DEBUG - 2018-04-23 08:57:51 --> Total execution time: 2.1388
INFO - 2018-04-23 10:35:52 --> Config Class Initialized
INFO - 2018-04-23 10:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:35:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:35:53 --> Utf8 Class Initialized
INFO - 2018-04-23 10:35:53 --> URI Class Initialized
INFO - 2018-04-23 10:35:53 --> Router Class Initialized
INFO - 2018-04-23 10:35:53 --> Output Class Initialized
INFO - 2018-04-23 10:35:53 --> Security Class Initialized
DEBUG - 2018-04-23 10:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:35:53 --> Input Class Initialized
INFO - 2018-04-23 10:35:53 --> Language Class Initialized
ERROR - 2018-04-23 10:35:53 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:36:02 --> Config Class Initialized
INFO - 2018-04-23 10:36:02 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:36:02 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:36:02 --> Utf8 Class Initialized
INFO - 2018-04-23 10:36:02 --> URI Class Initialized
INFO - 2018-04-23 10:36:02 --> Router Class Initialized
INFO - 2018-04-23 10:36:02 --> Output Class Initialized
INFO - 2018-04-23 10:36:02 --> Security Class Initialized
DEBUG - 2018-04-23 10:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:36:02 --> Input Class Initialized
INFO - 2018-04-23 10:36:02 --> Language Class Initialized
ERROR - 2018-04-23 10:36:02 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:36:24 --> Config Class Initialized
INFO - 2018-04-23 10:36:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:36:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:36:24 --> Utf8 Class Initialized
INFO - 2018-04-23 10:36:24 --> URI Class Initialized
INFO - 2018-04-23 10:36:24 --> Router Class Initialized
INFO - 2018-04-23 10:36:24 --> Output Class Initialized
INFO - 2018-04-23 10:36:24 --> Security Class Initialized
DEBUG - 2018-04-23 10:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:36:24 --> Input Class Initialized
INFO - 2018-04-23 10:36:25 --> Language Class Initialized
ERROR - 2018-04-23 10:36:25 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:36:29 --> Config Class Initialized
INFO - 2018-04-23 10:36:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:36:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:36:29 --> Utf8 Class Initialized
INFO - 2018-04-23 10:36:29 --> URI Class Initialized
INFO - 2018-04-23 10:36:29 --> Router Class Initialized
INFO - 2018-04-23 10:36:29 --> Output Class Initialized
INFO - 2018-04-23 10:36:29 --> Security Class Initialized
DEBUG - 2018-04-23 10:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:36:29 --> Input Class Initialized
INFO - 2018-04-23 10:36:29 --> Language Class Initialized
ERROR - 2018-04-23 10:36:29 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:40:35 --> Config Class Initialized
INFO - 2018-04-23 10:40:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:40:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:40:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:40:35 --> URI Class Initialized
INFO - 2018-04-23 10:40:35 --> Router Class Initialized
INFO - 2018-04-23 10:40:35 --> Output Class Initialized
INFO - 2018-04-23 10:40:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:40:35 --> Input Class Initialized
INFO - 2018-04-23 10:40:35 --> Language Class Initialized
ERROR - 2018-04-23 10:40:35 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:41:07 --> Config Class Initialized
INFO - 2018-04-23 10:41:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:41:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:41:07 --> Utf8 Class Initialized
INFO - 2018-04-23 10:41:07 --> URI Class Initialized
INFO - 2018-04-23 10:41:07 --> Router Class Initialized
INFO - 2018-04-23 10:41:07 --> Output Class Initialized
INFO - 2018-04-23 10:41:07 --> Security Class Initialized
DEBUG - 2018-04-23 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:41:07 --> Input Class Initialized
INFO - 2018-04-23 10:41:07 --> Language Class Initialized
ERROR - 2018-04-23 10:41:07 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:41:21 --> Config Class Initialized
INFO - 2018-04-23 10:41:21 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:41:21 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:41:21 --> Utf8 Class Initialized
INFO - 2018-04-23 10:41:21 --> URI Class Initialized
INFO - 2018-04-23 10:41:21 --> Router Class Initialized
INFO - 2018-04-23 10:41:21 --> Output Class Initialized
INFO - 2018-04-23 10:41:21 --> Security Class Initialized
DEBUG - 2018-04-23 10:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:41:21 --> Input Class Initialized
INFO - 2018-04-23 10:41:21 --> Language Class Initialized
ERROR - 2018-04-23 10:41:21 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:41:43 --> Config Class Initialized
INFO - 2018-04-23 10:41:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:41:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:41:43 --> Utf8 Class Initialized
INFO - 2018-04-23 10:41:43 --> URI Class Initialized
INFO - 2018-04-23 10:41:43 --> Router Class Initialized
INFO - 2018-04-23 10:41:43 --> Output Class Initialized
INFO - 2018-04-23 10:41:43 --> Security Class Initialized
DEBUG - 2018-04-23 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:41:43 --> Input Class Initialized
INFO - 2018-04-23 10:41:43 --> Language Class Initialized
ERROR - 2018-04-23 10:41:43 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:48:36 --> Config Class Initialized
INFO - 2018-04-23 10:48:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:48:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:48:36 --> Utf8 Class Initialized
INFO - 2018-04-23 10:48:36 --> URI Class Initialized
INFO - 2018-04-23 10:48:36 --> Router Class Initialized
INFO - 2018-04-23 10:48:36 --> Output Class Initialized
INFO - 2018-04-23 10:48:36 --> Security Class Initialized
DEBUG - 2018-04-23 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:48:36 --> Input Class Initialized
INFO - 2018-04-23 10:48:36 --> Language Class Initialized
ERROR - 2018-04-23 10:48:36 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:48:46 --> Config Class Initialized
INFO - 2018-04-23 10:48:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:48:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:48:46 --> Utf8 Class Initialized
INFO - 2018-04-23 10:48:46 --> URI Class Initialized
INFO - 2018-04-23 10:48:46 --> Router Class Initialized
INFO - 2018-04-23 10:48:46 --> Output Class Initialized
INFO - 2018-04-23 10:48:47 --> Security Class Initialized
DEBUG - 2018-04-23 10:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:48:47 --> Input Class Initialized
INFO - 2018-04-23 10:48:47 --> Language Class Initialized
ERROR - 2018-04-23 10:48:47 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:49:54 --> Config Class Initialized
INFO - 2018-04-23 10:49:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:49:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:49:54 --> Utf8 Class Initialized
INFO - 2018-04-23 10:49:54 --> URI Class Initialized
INFO - 2018-04-23 10:49:54 --> Router Class Initialized
INFO - 2018-04-23 10:49:54 --> Output Class Initialized
INFO - 2018-04-23 10:49:54 --> Security Class Initialized
DEBUG - 2018-04-23 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:49:54 --> Input Class Initialized
INFO - 2018-04-23 10:49:54 --> Language Class Initialized
ERROR - 2018-04-23 10:49:54 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:50:02 --> Config Class Initialized
INFO - 2018-04-23 10:50:02 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:50:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:50:03 --> Utf8 Class Initialized
INFO - 2018-04-23 10:50:03 --> URI Class Initialized
INFO - 2018-04-23 10:50:03 --> Router Class Initialized
INFO - 2018-04-23 10:50:03 --> Output Class Initialized
INFO - 2018-04-23 10:50:03 --> Security Class Initialized
DEBUG - 2018-04-23 10:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:50:03 --> Input Class Initialized
INFO - 2018-04-23 10:50:03 --> Language Class Initialized
ERROR - 2018-04-23 10:50:03 --> 404 Page Not Found: Booking/Main
INFO - 2018-04-23 10:51:15 --> Config Class Initialized
INFO - 2018-04-23 10:51:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:15 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:15 --> URI Class Initialized
INFO - 2018-04-23 10:51:15 --> Router Class Initialized
INFO - 2018-04-23 10:51:15 --> Output Class Initialized
INFO - 2018-04-23 10:51:15 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:15 --> Input Class Initialized
INFO - 2018-04-23 10:51:15 --> Language Class Initialized
ERROR - 2018-04-23 10:51:15 --> 404 Page Not Found: Booking/Main
