<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-14 04:55:03 --> Config Class Initialized
INFO - 2018-05-14 04:55:03 --> Hooks Class Initialized
DEBUG - 2018-05-14 04:55:03 --> UTF-8 Support Enabled
INFO - 2018-05-14 04:55:03 --> Utf8 Class Initialized
INFO - 2018-05-14 04:55:03 --> URI Class Initialized
DEBUG - 2018-05-14 04:55:03 --> No URI present. Default controller set.
INFO - 2018-05-14 04:55:03 --> Router Class Initialized
INFO - 2018-05-14 04:55:03 --> Output Class Initialized
INFO - 2018-05-14 04:55:04 --> Security Class Initialized
DEBUG - 2018-05-14 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 04:55:04 --> Input Class Initialized
INFO - 2018-05-14 04:55:04 --> Language Class Initialized
INFO - 2018-05-14 04:55:04 --> Loader Class Initialized
INFO - 2018-05-14 04:55:04 --> Helper loaded: url_helper
INFO - 2018-05-14 04:55:04 --> Helper loaded: form_helper
INFO - 2018-05-14 04:55:05 --> Helper loaded: date_helper
INFO - 2018-05-14 04:55:05 --> Database Driver Class Initialized
DEBUG - 2018-05-14 04:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 04:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 04:55:06 --> Form Validation Class Initialized
INFO - 2018-05-14 04:55:06 --> Model Class Initialized
INFO - 2018-05-14 04:55:06 --> Controller Class Initialized
INFO - 2018-05-14 04:55:06 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 04:55:06 --> Final output sent to browser
DEBUG - 2018-05-14 04:55:06 --> Total execution time: 3.0588
INFO - 2018-05-14 04:56:46 --> Config Class Initialized
INFO - 2018-05-14 04:56:46 --> Hooks Class Initialized
DEBUG - 2018-05-14 04:56:46 --> UTF-8 Support Enabled
INFO - 2018-05-14 04:56:46 --> Utf8 Class Initialized
INFO - 2018-05-14 04:56:46 --> URI Class Initialized
INFO - 2018-05-14 04:56:46 --> Router Class Initialized
INFO - 2018-05-14 04:56:46 --> Output Class Initialized
INFO - 2018-05-14 04:56:46 --> Security Class Initialized
DEBUG - 2018-05-14 04:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 04:56:46 --> Input Class Initialized
INFO - 2018-05-14 04:56:46 --> Language Class Initialized
INFO - 2018-05-14 04:56:46 --> Loader Class Initialized
INFO - 2018-05-14 04:56:46 --> Helper loaded: url_helper
INFO - 2018-05-14 04:56:46 --> Helper loaded: form_helper
INFO - 2018-05-14 04:56:46 --> Helper loaded: date_helper
INFO - 2018-05-14 04:56:46 --> Database Driver Class Initialized
DEBUG - 2018-05-14 04:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 04:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 04:56:46 --> Form Validation Class Initialized
INFO - 2018-05-14 04:56:46 --> Model Class Initialized
INFO - 2018-05-14 04:56:46 --> Controller Class Initialized
INFO - 2018-05-14 04:56:46 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 04:56:46 --> Final output sent to browser
DEBUG - 2018-05-14 04:56:46 --> Total execution time: 0.7750
INFO - 2018-05-14 04:56:50 --> Config Class Initialized
INFO - 2018-05-14 04:56:50 --> Hooks Class Initialized
DEBUG - 2018-05-14 04:56:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 04:56:50 --> Utf8 Class Initialized
INFO - 2018-05-14 04:56:50 --> URI Class Initialized
INFO - 2018-05-14 04:56:50 --> Router Class Initialized
INFO - 2018-05-14 04:56:50 --> Output Class Initialized
INFO - 2018-05-14 04:56:50 --> Security Class Initialized
DEBUG - 2018-05-14 04:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 04:56:51 --> Input Class Initialized
INFO - 2018-05-14 04:56:51 --> Language Class Initialized
INFO - 2018-05-14 04:56:51 --> Loader Class Initialized
INFO - 2018-05-14 04:56:51 --> Helper loaded: url_helper
INFO - 2018-05-14 04:56:51 --> Helper loaded: form_helper
INFO - 2018-05-14 04:56:51 --> Helper loaded: date_helper
INFO - 2018-05-14 04:56:51 --> Database Driver Class Initialized
DEBUG - 2018-05-14 04:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 04:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 04:56:51 --> Form Validation Class Initialized
INFO - 2018-05-14 04:56:51 --> Model Class Initialized
INFO - 2018-05-14 04:56:51 --> Controller Class Initialized
INFO - 2018-05-14 04:56:52 --> Config Class Initialized
INFO - 2018-05-14 04:56:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 04:56:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 04:56:52 --> Utf8 Class Initialized
INFO - 2018-05-14 04:56:52 --> URI Class Initialized
INFO - 2018-05-14 04:56:52 --> Router Class Initialized
INFO - 2018-05-14 04:56:52 --> Output Class Initialized
INFO - 2018-05-14 04:56:52 --> Security Class Initialized
DEBUG - 2018-05-14 04:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 04:56:52 --> Input Class Initialized
INFO - 2018-05-14 04:56:52 --> Language Class Initialized
INFO - 2018-05-14 04:56:52 --> Loader Class Initialized
INFO - 2018-05-14 04:56:52 --> Helper loaded: url_helper
INFO - 2018-05-14 04:56:52 --> Helper loaded: form_helper
INFO - 2018-05-14 04:56:52 --> Helper loaded: date_helper
INFO - 2018-05-14 04:56:52 --> Database Driver Class Initialized
DEBUG - 2018-05-14 04:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 04:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 04:56:52 --> Form Validation Class Initialized
INFO - 2018-05-14 04:56:52 --> Model Class Initialized
INFO - 2018-05-14 04:56:52 --> Controller Class Initialized
INFO - 2018-05-14 04:56:53 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 04:56:53 --> Final output sent to browser
DEBUG - 2018-05-14 04:56:53 --> Total execution time: 1.4225
INFO - 2018-05-14 04:56:53 --> Config Class Initialized
INFO - 2018-05-14 04:56:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 04:56:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 04:56:53 --> Utf8 Class Initialized
INFO - 2018-05-14 04:56:53 --> URI Class Initialized
INFO - 2018-05-14 04:56:53 --> Router Class Initialized
INFO - 2018-05-14 04:56:53 --> Output Class Initialized
INFO - 2018-05-14 04:56:53 --> Security Class Initialized
DEBUG - 2018-05-14 04:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 04:56:53 --> Input Class Initialized
INFO - 2018-05-14 04:56:53 --> Language Class Initialized
ERROR - 2018-05-14 04:56:53 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 04:56:55 --> Config Class Initialized
INFO - 2018-05-14 04:56:55 --> Hooks Class Initialized
DEBUG - 2018-05-14 04:56:55 --> UTF-8 Support Enabled
INFO - 2018-05-14 04:56:55 --> Utf8 Class Initialized
INFO - 2018-05-14 04:56:55 --> URI Class Initialized
INFO - 2018-05-14 04:56:55 --> Router Class Initialized
INFO - 2018-05-14 04:56:55 --> Output Class Initialized
INFO - 2018-05-14 04:56:55 --> Security Class Initialized
DEBUG - 2018-05-14 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 04:56:55 --> Input Class Initialized
INFO - 2018-05-14 04:56:55 --> Language Class Initialized
ERROR - 2018-05-14 04:56:55 --> 404 Page Not Found: Main/img
INFO - 2018-05-14 05:06:07 --> Config Class Initialized
INFO - 2018-05-14 05:06:07 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:06:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:06:07 --> Utf8 Class Initialized
INFO - 2018-05-14 05:06:07 --> URI Class Initialized
INFO - 2018-05-14 05:06:07 --> Router Class Initialized
INFO - 2018-05-14 05:06:07 --> Output Class Initialized
INFO - 2018-05-14 05:06:07 --> Security Class Initialized
DEBUG - 2018-05-14 05:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:06:07 --> Input Class Initialized
INFO - 2018-05-14 05:06:07 --> Language Class Initialized
INFO - 2018-05-14 05:06:07 --> Loader Class Initialized
INFO - 2018-05-14 05:06:07 --> Helper loaded: url_helper
INFO - 2018-05-14 05:06:07 --> Helper loaded: form_helper
INFO - 2018-05-14 05:06:07 --> Helper loaded: date_helper
INFO - 2018-05-14 05:06:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 05:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 05:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 05:06:07 --> Form Validation Class Initialized
INFO - 2018-05-14 05:06:07 --> Model Class Initialized
INFO - 2018-05-14 05:06:07 --> Controller Class Initialized
INFO - 2018-05-14 05:06:07 --> Config Class Initialized
INFO - 2018-05-14 05:06:07 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:06:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:06:07 --> Utf8 Class Initialized
INFO - 2018-05-14 05:06:07 --> URI Class Initialized
INFO - 2018-05-14 05:06:07 --> Router Class Initialized
INFO - 2018-05-14 05:06:07 --> Output Class Initialized
INFO - 2018-05-14 05:06:07 --> Security Class Initialized
DEBUG - 2018-05-14 05:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:06:07 --> Input Class Initialized
INFO - 2018-05-14 05:06:07 --> Language Class Initialized
INFO - 2018-05-14 05:06:07 --> Loader Class Initialized
INFO - 2018-05-14 05:06:07 --> Helper loaded: url_helper
INFO - 2018-05-14 05:06:07 --> Helper loaded: form_helper
INFO - 2018-05-14 05:06:07 --> Helper loaded: date_helper
INFO - 2018-05-14 05:06:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 05:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 05:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 05:06:07 --> Form Validation Class Initialized
INFO - 2018-05-14 05:06:07 --> Model Class Initialized
INFO - 2018-05-14 05:06:07 --> Controller Class Initialized
INFO - 2018-05-14 05:06:07 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 05:06:08 --> Final output sent to browser
DEBUG - 2018-05-14 05:06:08 --> Total execution time: 0.4615
INFO - 2018-05-14 05:06:19 --> Config Class Initialized
INFO - 2018-05-14 05:06:19 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:06:19 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:06:19 --> Utf8 Class Initialized
INFO - 2018-05-14 05:06:19 --> URI Class Initialized
INFO - 2018-05-14 05:06:19 --> Router Class Initialized
INFO - 2018-05-14 05:06:19 --> Output Class Initialized
INFO - 2018-05-14 05:06:19 --> Security Class Initialized
DEBUG - 2018-05-14 05:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:06:19 --> Input Class Initialized
INFO - 2018-05-14 05:06:19 --> Language Class Initialized
INFO - 2018-05-14 05:06:19 --> Loader Class Initialized
INFO - 2018-05-14 05:06:19 --> Helper loaded: url_helper
INFO - 2018-05-14 05:06:19 --> Helper loaded: form_helper
INFO - 2018-05-14 05:06:19 --> Helper loaded: date_helper
INFO - 2018-05-14 05:06:19 --> Database Driver Class Initialized
DEBUG - 2018-05-14 05:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 05:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 05:06:19 --> Form Validation Class Initialized
INFO - 2018-05-14 05:06:19 --> Model Class Initialized
INFO - 2018-05-14 05:06:19 --> Controller Class Initialized
INFO - 2018-05-14 05:06:19 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 05:06:19 --> Final output sent to browser
DEBUG - 2018-05-14 05:06:19 --> Total execution time: 0.3598
INFO - 2018-05-14 05:06:23 --> Config Class Initialized
INFO - 2018-05-14 05:06:23 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:06:23 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:06:23 --> Utf8 Class Initialized
INFO - 2018-05-14 05:06:23 --> URI Class Initialized
INFO - 2018-05-14 05:06:23 --> Router Class Initialized
INFO - 2018-05-14 05:06:23 --> Output Class Initialized
INFO - 2018-05-14 05:06:23 --> Security Class Initialized
DEBUG - 2018-05-14 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:06:23 --> Input Class Initialized
INFO - 2018-05-14 05:06:23 --> Language Class Initialized
INFO - 2018-05-14 05:06:23 --> Loader Class Initialized
INFO - 2018-05-14 05:06:23 --> Helper loaded: url_helper
INFO - 2018-05-14 05:06:23 --> Helper loaded: form_helper
INFO - 2018-05-14 05:06:23 --> Helper loaded: date_helper
INFO - 2018-05-14 05:06:23 --> Database Driver Class Initialized
DEBUG - 2018-05-14 05:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 05:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 05:06:23 --> Form Validation Class Initialized
INFO - 2018-05-14 05:06:23 --> Model Class Initialized
INFO - 2018-05-14 05:06:23 --> Controller Class Initialized
INFO - 2018-05-14 05:06:23 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 05:06:23 --> Final output sent to browser
DEBUG - 2018-05-14 05:06:23 --> Total execution time: 0.3824
INFO - 2018-05-14 05:29:59 --> Config Class Initialized
INFO - 2018-05-14 05:29:59 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:29:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:29:59 --> Utf8 Class Initialized
INFO - 2018-05-14 05:29:59 --> URI Class Initialized
INFO - 2018-05-14 05:29:59 --> Router Class Initialized
INFO - 2018-05-14 05:29:59 --> Output Class Initialized
INFO - 2018-05-14 05:30:00 --> Security Class Initialized
DEBUG - 2018-05-14 05:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:30:00 --> Input Class Initialized
INFO - 2018-05-14 05:30:00 --> Language Class Initialized
INFO - 2018-05-14 05:30:00 --> Loader Class Initialized
INFO - 2018-05-14 05:30:00 --> Helper loaded: url_helper
INFO - 2018-05-14 05:30:00 --> Helper loaded: form_helper
INFO - 2018-05-14 05:30:00 --> Helper loaded: date_helper
INFO - 2018-05-14 05:30:00 --> Database Driver Class Initialized
DEBUG - 2018-05-14 05:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 05:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 05:30:00 --> Form Validation Class Initialized
INFO - 2018-05-14 05:30:00 --> Model Class Initialized
INFO - 2018-05-14 05:30:00 --> Controller Class Initialized
INFO - 2018-05-14 05:30:00 --> Config Class Initialized
INFO - 2018-05-14 05:30:00 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:30:00 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:30:00 --> Utf8 Class Initialized
INFO - 2018-05-14 05:30:00 --> URI Class Initialized
INFO - 2018-05-14 05:30:00 --> Router Class Initialized
INFO - 2018-05-14 05:30:00 --> Output Class Initialized
INFO - 2018-05-14 05:30:00 --> Security Class Initialized
DEBUG - 2018-05-14 05:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:30:00 --> Input Class Initialized
INFO - 2018-05-14 05:30:00 --> Language Class Initialized
INFO - 2018-05-14 05:30:00 --> Loader Class Initialized
INFO - 2018-05-14 05:30:00 --> Helper loaded: url_helper
INFO - 2018-05-14 05:30:00 --> Helper loaded: form_helper
INFO - 2018-05-14 05:30:00 --> Helper loaded: date_helper
INFO - 2018-05-14 05:30:00 --> Database Driver Class Initialized
DEBUG - 2018-05-14 05:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 05:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 05:30:01 --> Form Validation Class Initialized
INFO - 2018-05-14 05:30:01 --> Model Class Initialized
INFO - 2018-05-14 05:30:01 --> Controller Class Initialized
INFO - 2018-05-14 05:30:01 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 05:30:01 --> Final output sent to browser
DEBUG - 2018-05-14 05:30:01 --> Total execution time: 0.7247
INFO - 2018-05-14 05:30:01 --> Config Class Initialized
INFO - 2018-05-14 05:30:01 --> Hooks Class Initialized
DEBUG - 2018-05-14 05:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-14 05:30:01 --> Utf8 Class Initialized
INFO - 2018-05-14 05:30:01 --> URI Class Initialized
INFO - 2018-05-14 05:30:01 --> Router Class Initialized
INFO - 2018-05-14 05:30:01 --> Output Class Initialized
INFO - 2018-05-14 05:30:01 --> Security Class Initialized
DEBUG - 2018-05-14 05:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 05:30:01 --> Input Class Initialized
INFO - 2018-05-14 05:30:01 --> Language Class Initialized
ERROR - 2018-05-14 05:30:01 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 06:27:11 --> Config Class Initialized
INFO - 2018-05-14 06:27:11 --> Hooks Class Initialized
DEBUG - 2018-05-14 06:27:11 --> UTF-8 Support Enabled
INFO - 2018-05-14 06:27:11 --> Utf8 Class Initialized
INFO - 2018-05-14 06:27:11 --> URI Class Initialized
INFO - 2018-05-14 06:27:11 --> Router Class Initialized
INFO - 2018-05-14 06:27:11 --> Output Class Initialized
INFO - 2018-05-14 06:27:11 --> Security Class Initialized
DEBUG - 2018-05-14 06:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 06:27:11 --> Input Class Initialized
INFO - 2018-05-14 06:27:11 --> Language Class Initialized
INFO - 2018-05-14 06:27:11 --> Loader Class Initialized
INFO - 2018-05-14 06:27:11 --> Helper loaded: url_helper
INFO - 2018-05-14 06:27:11 --> Helper loaded: form_helper
INFO - 2018-05-14 06:27:11 --> Helper loaded: date_helper
INFO - 2018-05-14 06:27:12 --> Database Driver Class Initialized
DEBUG - 2018-05-14 06:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 06:27:12 --> Form Validation Class Initialized
INFO - 2018-05-14 06:27:12 --> Model Class Initialized
INFO - 2018-05-14 06:27:12 --> Controller Class Initialized
INFO - 2018-05-14 06:27:12 --> Config Class Initialized
INFO - 2018-05-14 06:27:12 --> Hooks Class Initialized
DEBUG - 2018-05-14 06:27:12 --> UTF-8 Support Enabled
INFO - 2018-05-14 06:27:12 --> Utf8 Class Initialized
INFO - 2018-05-14 06:27:12 --> URI Class Initialized
INFO - 2018-05-14 06:27:12 --> Router Class Initialized
INFO - 2018-05-14 06:27:12 --> Output Class Initialized
INFO - 2018-05-14 06:27:12 --> Security Class Initialized
DEBUG - 2018-05-14 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 06:27:12 --> Input Class Initialized
INFO - 2018-05-14 06:27:12 --> Language Class Initialized
INFO - 2018-05-14 06:27:12 --> Loader Class Initialized
INFO - 2018-05-14 06:27:12 --> Helper loaded: url_helper
INFO - 2018-05-14 06:27:12 --> Helper loaded: form_helper
INFO - 2018-05-14 06:27:12 --> Helper loaded: date_helper
INFO - 2018-05-14 06:27:12 --> Database Driver Class Initialized
DEBUG - 2018-05-14 06:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 06:27:12 --> Form Validation Class Initialized
INFO - 2018-05-14 06:27:12 --> Model Class Initialized
INFO - 2018-05-14 06:27:12 --> Controller Class Initialized
INFO - 2018-05-14 06:27:12 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 06:27:12 --> Final output sent to browser
DEBUG - 2018-05-14 06:27:12 --> Total execution time: 0.3107
INFO - 2018-05-14 06:27:37 --> Config Class Initialized
INFO - 2018-05-14 06:27:37 --> Hooks Class Initialized
DEBUG - 2018-05-14 06:27:37 --> UTF-8 Support Enabled
INFO - 2018-05-14 06:27:37 --> Utf8 Class Initialized
INFO - 2018-05-14 06:27:37 --> URI Class Initialized
INFO - 2018-05-14 06:27:37 --> Router Class Initialized
INFO - 2018-05-14 06:27:37 --> Output Class Initialized
INFO - 2018-05-14 06:27:38 --> Security Class Initialized
DEBUG - 2018-05-14 06:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 06:27:38 --> Input Class Initialized
INFO - 2018-05-14 06:27:38 --> Language Class Initialized
INFO - 2018-05-14 06:27:38 --> Loader Class Initialized
INFO - 2018-05-14 06:27:38 --> Helper loaded: url_helper
INFO - 2018-05-14 06:27:38 --> Helper loaded: form_helper
INFO - 2018-05-14 06:27:38 --> Helper loaded: date_helper
INFO - 2018-05-14 06:27:38 --> Database Driver Class Initialized
DEBUG - 2018-05-14 06:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 06:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 06:27:38 --> Form Validation Class Initialized
INFO - 2018-05-14 06:27:38 --> Model Class Initialized
INFO - 2018-05-14 06:27:38 --> Controller Class Initialized
INFO - 2018-05-14 06:27:38 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 06:27:38 --> Final output sent to browser
DEBUG - 2018-05-14 06:27:38 --> Total execution time: 0.3343
INFO - 2018-05-14 06:27:42 --> Config Class Initialized
INFO - 2018-05-14 06:27:42 --> Hooks Class Initialized
DEBUG - 2018-05-14 06:27:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 06:27:42 --> Utf8 Class Initialized
INFO - 2018-05-14 06:27:42 --> URI Class Initialized
INFO - 2018-05-14 06:27:42 --> Router Class Initialized
INFO - 2018-05-14 06:27:42 --> Output Class Initialized
INFO - 2018-05-14 06:27:42 --> Security Class Initialized
DEBUG - 2018-05-14 06:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 06:27:42 --> Input Class Initialized
INFO - 2018-05-14 06:27:42 --> Language Class Initialized
INFO - 2018-05-14 06:27:42 --> Loader Class Initialized
INFO - 2018-05-14 06:27:42 --> Helper loaded: url_helper
INFO - 2018-05-14 06:27:42 --> Helper loaded: form_helper
INFO - 2018-05-14 06:27:43 --> Helper loaded: date_helper
INFO - 2018-05-14 06:27:43 --> Database Driver Class Initialized
DEBUG - 2018-05-14 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 06:27:43 --> Form Validation Class Initialized
INFO - 2018-05-14 06:27:43 --> Model Class Initialized
INFO - 2018-05-14 06:27:43 --> Controller Class Initialized
INFO - 2018-05-14 06:27:43 --> Config Class Initialized
INFO - 2018-05-14 06:27:43 --> Hooks Class Initialized
DEBUG - 2018-05-14 06:27:43 --> UTF-8 Support Enabled
INFO - 2018-05-14 06:27:43 --> Utf8 Class Initialized
INFO - 2018-05-14 06:27:43 --> URI Class Initialized
INFO - 2018-05-14 06:27:43 --> Router Class Initialized
INFO - 2018-05-14 06:27:43 --> Output Class Initialized
INFO - 2018-05-14 06:27:43 --> Security Class Initialized
DEBUG - 2018-05-14 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 06:27:43 --> Input Class Initialized
INFO - 2018-05-14 06:27:43 --> Language Class Initialized
INFO - 2018-05-14 06:27:43 --> Loader Class Initialized
INFO - 2018-05-14 06:27:43 --> Helper loaded: url_helper
INFO - 2018-05-14 06:27:43 --> Helper loaded: form_helper
INFO - 2018-05-14 06:27:43 --> Helper loaded: date_helper
INFO - 2018-05-14 06:27:43 --> Database Driver Class Initialized
DEBUG - 2018-05-14 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 06:27:43 --> Form Validation Class Initialized
INFO - 2018-05-14 06:27:43 --> Model Class Initialized
INFO - 2018-05-14 06:27:43 --> Controller Class Initialized
INFO - 2018-05-14 06:27:43 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 06:27:43 --> Final output sent to browser
DEBUG - 2018-05-14 06:27:43 --> Total execution time: 0.3326
INFO - 2018-05-14 06:27:43 --> Config Class Initialized
INFO - 2018-05-14 06:27:43 --> Hooks Class Initialized
DEBUG - 2018-05-14 06:27:43 --> UTF-8 Support Enabled
INFO - 2018-05-14 06:27:43 --> Utf8 Class Initialized
INFO - 2018-05-14 06:27:43 --> URI Class Initialized
INFO - 2018-05-14 06:27:43 --> Router Class Initialized
INFO - 2018-05-14 06:27:43 --> Output Class Initialized
INFO - 2018-05-14 06:27:43 --> Security Class Initialized
DEBUG - 2018-05-14 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 06:27:43 --> Input Class Initialized
INFO - 2018-05-14 06:27:43 --> Language Class Initialized
ERROR - 2018-05-14 06:27:43 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 11:26:48 --> Config Class Initialized
INFO - 2018-05-14 11:26:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:26:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:26:48 --> Utf8 Class Initialized
INFO - 2018-05-14 11:26:48 --> URI Class Initialized
DEBUG - 2018-05-14 11:26:49 --> No URI present. Default controller set.
INFO - 2018-05-14 11:26:49 --> Router Class Initialized
INFO - 2018-05-14 11:26:49 --> Output Class Initialized
INFO - 2018-05-14 11:26:49 --> Security Class Initialized
DEBUG - 2018-05-14 11:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:26:49 --> Input Class Initialized
INFO - 2018-05-14 11:26:49 --> Language Class Initialized
INFO - 2018-05-14 11:26:49 --> Loader Class Initialized
INFO - 2018-05-14 11:26:49 --> Helper loaded: url_helper
INFO - 2018-05-14 11:26:49 --> Helper loaded: form_helper
INFO - 2018-05-14 11:26:49 --> Helper loaded: date_helper
INFO - 2018-05-14 11:26:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:26:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:26:50 --> Model Class Initialized
INFO - 2018-05-14 11:26:50 --> Controller Class Initialized
INFO - 2018-05-14 11:26:50 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:26:50 --> Final output sent to browser
INFO - 2018-05-14 11:26:50 --> Config Class Initialized
DEBUG - 2018-05-14 11:26:50 --> Total execution time: 1.9097
INFO - 2018-05-14 11:26:50 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:26:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:26:50 --> Utf8 Class Initialized
INFO - 2018-05-14 11:26:50 --> URI Class Initialized
DEBUG - 2018-05-14 11:26:50 --> No URI present. Default controller set.
INFO - 2018-05-14 11:26:50 --> Router Class Initialized
INFO - 2018-05-14 11:26:50 --> Output Class Initialized
INFO - 2018-05-14 11:26:50 --> Security Class Initialized
DEBUG - 2018-05-14 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:26:50 --> Input Class Initialized
INFO - 2018-05-14 11:26:50 --> Language Class Initialized
INFO - 2018-05-14 11:26:50 --> Loader Class Initialized
INFO - 2018-05-14 11:26:50 --> Helper loaded: url_helper
INFO - 2018-05-14 11:26:50 --> Helper loaded: form_helper
INFO - 2018-05-14 11:26:50 --> Helper loaded: date_helper
INFO - 2018-05-14 11:26:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:26:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:26:50 --> Model Class Initialized
INFO - 2018-05-14 11:26:50 --> Controller Class Initialized
INFO - 2018-05-14 11:26:50 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:26:50 --> Final output sent to browser
DEBUG - 2018-05-14 11:26:50 --> Total execution time: 0.4094
INFO - 2018-05-14 11:27:34 --> Config Class Initialized
INFO - 2018-05-14 11:27:34 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:27:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:27:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:27:34 --> URI Class Initialized
INFO - 2018-05-14 11:27:34 --> Router Class Initialized
INFO - 2018-05-14 11:27:34 --> Output Class Initialized
INFO - 2018-05-14 11:27:34 --> Security Class Initialized
DEBUG - 2018-05-14 11:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:27:34 --> Input Class Initialized
INFO - 2018-05-14 11:27:34 --> Language Class Initialized
INFO - 2018-05-14 11:27:34 --> Loader Class Initialized
INFO - 2018-05-14 11:27:34 --> Helper loaded: url_helper
INFO - 2018-05-14 11:27:34 --> Helper loaded: form_helper
INFO - 2018-05-14 11:27:34 --> Helper loaded: date_helper
INFO - 2018-05-14 11:27:34 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:27:34 --> Form Validation Class Initialized
INFO - 2018-05-14 11:27:34 --> Model Class Initialized
INFO - 2018-05-14 11:27:34 --> Controller Class Initialized
INFO - 2018-05-14 11:27:34 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 11:27:34 --> Final output sent to browser
DEBUG - 2018-05-14 11:27:34 --> Total execution time: 0.3924
INFO - 2018-05-14 11:27:40 --> Config Class Initialized
INFO - 2018-05-14 11:27:40 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:27:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:27:40 --> Utf8 Class Initialized
INFO - 2018-05-14 11:27:40 --> URI Class Initialized
INFO - 2018-05-14 11:27:40 --> Router Class Initialized
INFO - 2018-05-14 11:27:40 --> Output Class Initialized
INFO - 2018-05-14 11:27:40 --> Security Class Initialized
DEBUG - 2018-05-14 11:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:27:40 --> Input Class Initialized
INFO - 2018-05-14 11:27:40 --> Language Class Initialized
INFO - 2018-05-14 11:27:40 --> Loader Class Initialized
INFO - 2018-05-14 11:27:40 --> Helper loaded: url_helper
INFO - 2018-05-14 11:27:40 --> Helper loaded: form_helper
INFO - 2018-05-14 11:27:40 --> Helper loaded: date_helper
INFO - 2018-05-14 11:27:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:27:40 --> Form Validation Class Initialized
INFO - 2018-05-14 11:27:40 --> Model Class Initialized
INFO - 2018-05-14 11:27:40 --> Controller Class Initialized
INFO - 2018-05-14 11:27:40 --> Config Class Initialized
INFO - 2018-05-14 11:27:40 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:27:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:27:40 --> Utf8 Class Initialized
INFO - 2018-05-14 11:27:40 --> URI Class Initialized
INFO - 2018-05-14 11:27:40 --> Router Class Initialized
INFO - 2018-05-14 11:27:40 --> Output Class Initialized
INFO - 2018-05-14 11:27:40 --> Security Class Initialized
DEBUG - 2018-05-14 11:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:27:40 --> Input Class Initialized
INFO - 2018-05-14 11:27:40 --> Language Class Initialized
INFO - 2018-05-14 11:27:40 --> Loader Class Initialized
INFO - 2018-05-14 11:27:40 --> Helper loaded: url_helper
INFO - 2018-05-14 11:27:40 --> Helper loaded: form_helper
INFO - 2018-05-14 11:27:40 --> Helper loaded: date_helper
INFO - 2018-05-14 11:27:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:27:40 --> Form Validation Class Initialized
INFO - 2018-05-14 11:27:40 --> Model Class Initialized
INFO - 2018-05-14 11:27:40 --> Controller Class Initialized
INFO - 2018-05-14 11:27:40 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 11:27:41 --> Final output sent to browser
DEBUG - 2018-05-14 11:27:41 --> Total execution time: 0.4705
INFO - 2018-05-14 11:27:41 --> Config Class Initialized
INFO - 2018-05-14 11:27:41 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:27:41 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:27:41 --> Utf8 Class Initialized
INFO - 2018-05-14 11:27:41 --> URI Class Initialized
INFO - 2018-05-14 11:27:41 --> Router Class Initialized
INFO - 2018-05-14 11:27:41 --> Output Class Initialized
INFO - 2018-05-14 11:27:41 --> Security Class Initialized
DEBUG - 2018-05-14 11:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:27:41 --> Input Class Initialized
INFO - 2018-05-14 11:27:41 --> Language Class Initialized
ERROR - 2018-05-14 11:27:41 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 11:28:17 --> Config Class Initialized
INFO - 2018-05-14 11:28:17 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:17 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:17 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:17 --> URI Class Initialized
INFO - 2018-05-14 11:28:17 --> Router Class Initialized
INFO - 2018-05-14 11:28:17 --> Output Class Initialized
INFO - 2018-05-14 11:28:17 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:17 --> Input Class Initialized
INFO - 2018-05-14 11:28:17 --> Language Class Initialized
INFO - 2018-05-14 11:28:17 --> Loader Class Initialized
INFO - 2018-05-14 11:28:17 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:18 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:18 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:18 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:18 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:18 --> Model Class Initialized
INFO - 2018-05-14 11:28:18 --> Controller Class Initialized
INFO - 2018-05-14 11:28:18 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 11:28:18 --> Final output sent to browser
DEBUG - 2018-05-14 11:28:18 --> Total execution time: 0.3248
INFO - 2018-05-14 11:28:18 --> Config Class Initialized
INFO - 2018-05-14 11:28:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:18 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:18 --> URI Class Initialized
INFO - 2018-05-14 11:28:18 --> Router Class Initialized
INFO - 2018-05-14 11:28:18 --> Output Class Initialized
INFO - 2018-05-14 11:28:18 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:18 --> Input Class Initialized
INFO - 2018-05-14 11:28:18 --> Language Class Initialized
ERROR - 2018-05-14 11:28:18 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 11:28:18 --> Config Class Initialized
INFO - 2018-05-14 11:28:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:18 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:18 --> URI Class Initialized
INFO - 2018-05-14 11:28:18 --> Router Class Initialized
INFO - 2018-05-14 11:28:18 --> Output Class Initialized
INFO - 2018-05-14 11:28:18 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:19 --> Input Class Initialized
INFO - 2018-05-14 11:28:19 --> Language Class Initialized
INFO - 2018-05-14 11:28:19 --> Loader Class Initialized
INFO - 2018-05-14 11:28:19 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:19 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:19 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:19 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:19 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:19 --> Model Class Initialized
INFO - 2018-05-14 11:28:19 --> Controller Class Initialized
ERROR - 2018-05-14 11:28:19 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
ERROR - 2018-05-14 11:28:19 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
INFO - 2018-05-14 11:28:48 --> Config Class Initialized
INFO - 2018-05-14 11:28:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:48 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:48 --> URI Class Initialized
INFO - 2018-05-14 11:28:48 --> Router Class Initialized
INFO - 2018-05-14 11:28:48 --> Output Class Initialized
INFO - 2018-05-14 11:28:48 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:48 --> Input Class Initialized
INFO - 2018-05-14 11:28:48 --> Language Class Initialized
INFO - 2018-05-14 11:28:48 --> Loader Class Initialized
INFO - 2018-05-14 11:28:48 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:48 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:48 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:48 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:48 --> Model Class Initialized
INFO - 2018-05-14 11:28:48 --> Controller Class Initialized
INFO - 2018-05-14 11:28:48 --> Config Class Initialized
INFO - 2018-05-14 11:28:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:48 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:48 --> URI Class Initialized
INFO - 2018-05-14 11:28:48 --> Router Class Initialized
INFO - 2018-05-14 11:28:48 --> Output Class Initialized
INFO - 2018-05-14 11:28:48 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:48 --> Input Class Initialized
INFO - 2018-05-14 11:28:48 --> Language Class Initialized
INFO - 2018-05-14 11:28:48 --> Loader Class Initialized
INFO - 2018-05-14 11:28:48 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:48 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:48 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:48 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:48 --> Model Class Initialized
INFO - 2018-05-14 11:28:48 --> Controller Class Initialized
INFO - 2018-05-14 11:28:48 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:28:48 --> Final output sent to browser
DEBUG - 2018-05-14 11:28:48 --> Total execution time: 0.3392
INFO - 2018-05-14 11:28:52 --> Config Class Initialized
INFO - 2018-05-14 11:28:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:52 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:52 --> URI Class Initialized
INFO - 2018-05-14 11:28:52 --> Router Class Initialized
INFO - 2018-05-14 11:28:52 --> Output Class Initialized
INFO - 2018-05-14 11:28:52 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:52 --> Input Class Initialized
INFO - 2018-05-14 11:28:52 --> Language Class Initialized
INFO - 2018-05-14 11:28:52 --> Loader Class Initialized
INFO - 2018-05-14 11:28:52 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:52 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:52 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:52 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:52 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:52 --> Model Class Initialized
INFO - 2018-05-14 11:28:52 --> Controller Class Initialized
INFO - 2018-05-14 11:28:52 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 11:28:52 --> Final output sent to browser
DEBUG - 2018-05-14 11:28:52 --> Total execution time: 0.5200
INFO - 2018-05-14 11:28:56 --> Config Class Initialized
INFO - 2018-05-14 11:28:56 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:56 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:56 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:56 --> URI Class Initialized
INFO - 2018-05-14 11:28:56 --> Router Class Initialized
INFO - 2018-05-14 11:28:56 --> Output Class Initialized
INFO - 2018-05-14 11:28:56 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:56 --> Input Class Initialized
INFO - 2018-05-14 11:28:56 --> Language Class Initialized
INFO - 2018-05-14 11:28:56 --> Loader Class Initialized
INFO - 2018-05-14 11:28:56 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:56 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:56 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:56 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:56 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:56 --> Model Class Initialized
INFO - 2018-05-14 11:28:56 --> Controller Class Initialized
DEBUG - 2018-05-14 11:28:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:28:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:28:56 --> Config Class Initialized
INFO - 2018-05-14 11:28:57 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:28:57 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:28:57 --> Utf8 Class Initialized
INFO - 2018-05-14 11:28:57 --> URI Class Initialized
INFO - 2018-05-14 11:28:57 --> Router Class Initialized
INFO - 2018-05-14 11:28:57 --> Output Class Initialized
INFO - 2018-05-14 11:28:57 --> Security Class Initialized
DEBUG - 2018-05-14 11:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:28:57 --> Input Class Initialized
INFO - 2018-05-14 11:28:57 --> Language Class Initialized
INFO - 2018-05-14 11:28:57 --> Loader Class Initialized
INFO - 2018-05-14 11:28:57 --> Helper loaded: url_helper
INFO - 2018-05-14 11:28:57 --> Helper loaded: form_helper
INFO - 2018-05-14 11:28:57 --> Helper loaded: date_helper
INFO - 2018-05-14 11:28:57 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:28:57 --> Form Validation Class Initialized
INFO - 2018-05-14 11:28:57 --> Model Class Initialized
INFO - 2018-05-14 11:28:57 --> Controller Class Initialized
INFO - 2018-05-14 11:28:57 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 11:28:57 --> Final output sent to browser
DEBUG - 2018-05-14 11:28:57 --> Total execution time: 0.3154
INFO - 2018-05-14 11:29:08 --> Config Class Initialized
INFO - 2018-05-14 11:29:08 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:29:08 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:29:08 --> Utf8 Class Initialized
INFO - 2018-05-14 11:29:09 --> URI Class Initialized
INFO - 2018-05-14 11:29:09 --> Router Class Initialized
INFO - 2018-05-14 11:29:09 --> Output Class Initialized
INFO - 2018-05-14 11:29:09 --> Security Class Initialized
DEBUG - 2018-05-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:29:09 --> Input Class Initialized
INFO - 2018-05-14 11:29:09 --> Language Class Initialized
INFO - 2018-05-14 11:29:09 --> Loader Class Initialized
INFO - 2018-05-14 11:29:09 --> Helper loaded: url_helper
INFO - 2018-05-14 11:29:09 --> Helper loaded: form_helper
INFO - 2018-05-14 11:29:09 --> Helper loaded: date_helper
INFO - 2018-05-14 11:29:09 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:29:09 --> Form Validation Class Initialized
INFO - 2018-05-14 11:29:09 --> Model Class Initialized
INFO - 2018-05-14 11:29:09 --> Controller Class Initialized
DEBUG - 2018-05-14 11:29:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:29:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:29:09 --> Config Class Initialized
INFO - 2018-05-14 11:29:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:29:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:29:09 --> Utf8 Class Initialized
INFO - 2018-05-14 11:29:09 --> URI Class Initialized
INFO - 2018-05-14 11:29:09 --> Router Class Initialized
INFO - 2018-05-14 11:29:09 --> Output Class Initialized
INFO - 2018-05-14 11:29:09 --> Security Class Initialized
DEBUG - 2018-05-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:29:09 --> Input Class Initialized
INFO - 2018-05-14 11:29:09 --> Language Class Initialized
INFO - 2018-05-14 11:29:09 --> Loader Class Initialized
INFO - 2018-05-14 11:29:09 --> Helper loaded: url_helper
INFO - 2018-05-14 11:29:09 --> Helper loaded: form_helper
INFO - 2018-05-14 11:29:09 --> Helper loaded: date_helper
INFO - 2018-05-14 11:29:09 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:29:09 --> Form Validation Class Initialized
INFO - 2018-05-14 11:29:09 --> Model Class Initialized
INFO - 2018-05-14 11:29:09 --> Controller Class Initialized
INFO - 2018-05-14 11:29:09 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 11:29:09 --> Final output sent to browser
DEBUG - 2018-05-14 11:29:09 --> Total execution time: 0.3250
INFO - 2018-05-14 11:29:21 --> Config Class Initialized
INFO - 2018-05-14 11:29:21 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:29:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:29:21 --> Utf8 Class Initialized
INFO - 2018-05-14 11:29:21 --> URI Class Initialized
INFO - 2018-05-14 11:29:21 --> Router Class Initialized
INFO - 2018-05-14 11:29:22 --> Output Class Initialized
INFO - 2018-05-14 11:29:22 --> Security Class Initialized
DEBUG - 2018-05-14 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:29:22 --> Input Class Initialized
INFO - 2018-05-14 11:29:22 --> Language Class Initialized
INFO - 2018-05-14 11:29:22 --> Loader Class Initialized
INFO - 2018-05-14 11:29:22 --> Helper loaded: url_helper
INFO - 2018-05-14 11:29:22 --> Helper loaded: form_helper
INFO - 2018-05-14 11:29:22 --> Helper loaded: date_helper
INFO - 2018-05-14 11:29:22 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:29:22 --> Form Validation Class Initialized
INFO - 2018-05-14 11:29:22 --> Model Class Initialized
INFO - 2018-05-14 11:29:22 --> Controller Class Initialized
DEBUG - 2018-05-14 11:29:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:29:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:29:22 --> Config Class Initialized
INFO - 2018-05-14 11:29:22 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:29:22 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:29:22 --> Utf8 Class Initialized
INFO - 2018-05-14 11:29:22 --> URI Class Initialized
INFO - 2018-05-14 11:29:22 --> Router Class Initialized
INFO - 2018-05-14 11:29:22 --> Output Class Initialized
INFO - 2018-05-14 11:29:22 --> Security Class Initialized
DEBUG - 2018-05-14 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:29:22 --> Input Class Initialized
INFO - 2018-05-14 11:29:22 --> Language Class Initialized
INFO - 2018-05-14 11:29:22 --> Loader Class Initialized
INFO - 2018-05-14 11:29:22 --> Helper loaded: url_helper
INFO - 2018-05-14 11:29:22 --> Helper loaded: form_helper
INFO - 2018-05-14 11:29:22 --> Helper loaded: date_helper
INFO - 2018-05-14 11:29:22 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:29:22 --> Form Validation Class Initialized
INFO - 2018-05-14 11:29:22 --> Model Class Initialized
INFO - 2018-05-14 11:29:22 --> Controller Class Initialized
INFO - 2018-05-14 11:29:22 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 11:29:22 --> Final output sent to browser
DEBUG - 2018-05-14 11:29:22 --> Total execution time: 0.2888
INFO - 2018-05-14 11:29:29 --> Config Class Initialized
INFO - 2018-05-14 11:29:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:29:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:29:29 --> Utf8 Class Initialized
INFO - 2018-05-14 11:29:29 --> URI Class Initialized
INFO - 2018-05-14 11:29:29 --> Router Class Initialized
INFO - 2018-05-14 11:29:29 --> Output Class Initialized
INFO - 2018-05-14 11:29:29 --> Security Class Initialized
DEBUG - 2018-05-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:29:29 --> Input Class Initialized
INFO - 2018-05-14 11:29:29 --> Language Class Initialized
INFO - 2018-05-14 11:29:29 --> Loader Class Initialized
INFO - 2018-05-14 11:29:29 --> Helper loaded: url_helper
INFO - 2018-05-14 11:29:29 --> Helper loaded: form_helper
INFO - 2018-05-14 11:29:29 --> Helper loaded: date_helper
INFO - 2018-05-14 11:29:29 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:29:29 --> Form Validation Class Initialized
INFO - 2018-05-14 11:29:29 --> Model Class Initialized
INFO - 2018-05-14 11:29:30 --> Controller Class Initialized
DEBUG - 2018-05-14 11:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:29:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:29:30 --> Config Class Initialized
INFO - 2018-05-14 11:29:30 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:29:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:29:30 --> Utf8 Class Initialized
INFO - 2018-05-14 11:29:30 --> URI Class Initialized
INFO - 2018-05-14 11:29:30 --> Router Class Initialized
INFO - 2018-05-14 11:29:30 --> Output Class Initialized
INFO - 2018-05-14 11:29:30 --> Security Class Initialized
DEBUG - 2018-05-14 11:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:29:30 --> Input Class Initialized
INFO - 2018-05-14 11:29:30 --> Language Class Initialized
INFO - 2018-05-14 11:29:30 --> Loader Class Initialized
INFO - 2018-05-14 11:29:30 --> Helper loaded: url_helper
INFO - 2018-05-14 11:29:30 --> Helper loaded: form_helper
INFO - 2018-05-14 11:29:30 --> Helper loaded: date_helper
INFO - 2018-05-14 11:29:30 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:29:30 --> Form Validation Class Initialized
INFO - 2018-05-14 11:29:30 --> Model Class Initialized
INFO - 2018-05-14 11:29:30 --> Controller Class Initialized
INFO - 2018-05-14 11:29:30 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 11:29:30 --> Final output sent to browser
DEBUG - 2018-05-14 11:29:30 --> Total execution time: 0.3033
INFO - 2018-05-14 11:30:33 --> Config Class Initialized
INFO - 2018-05-14 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:30:33 --> Utf8 Class Initialized
INFO - 2018-05-14 11:30:33 --> URI Class Initialized
INFO - 2018-05-14 11:30:33 --> Router Class Initialized
INFO - 2018-05-14 11:30:33 --> Output Class Initialized
INFO - 2018-05-14 11:30:33 --> Security Class Initialized
DEBUG - 2018-05-14 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:30:33 --> Input Class Initialized
INFO - 2018-05-14 11:30:33 --> Language Class Initialized
INFO - 2018-05-14 11:30:33 --> Loader Class Initialized
INFO - 2018-05-14 11:30:33 --> Helper loaded: url_helper
INFO - 2018-05-14 11:30:33 --> Helper loaded: form_helper
INFO - 2018-05-14 11:30:33 --> Helper loaded: date_helper
INFO - 2018-05-14 11:30:33 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:30:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:30:33 --> Model Class Initialized
INFO - 2018-05-14 11:30:33 --> Controller Class Initialized
DEBUG - 2018-05-14 11:30:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:30:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:30:33 --> Config Class Initialized
INFO - 2018-05-14 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:30:33 --> Utf8 Class Initialized
INFO - 2018-05-14 11:30:33 --> URI Class Initialized
INFO - 2018-05-14 11:30:33 --> Router Class Initialized
INFO - 2018-05-14 11:30:33 --> Output Class Initialized
INFO - 2018-05-14 11:30:33 --> Security Class Initialized
DEBUG - 2018-05-14 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:30:33 --> Input Class Initialized
INFO - 2018-05-14 11:30:33 --> Language Class Initialized
INFO - 2018-05-14 11:30:33 --> Loader Class Initialized
INFO - 2018-05-14 11:30:33 --> Helper loaded: url_helper
INFO - 2018-05-14 11:30:33 --> Helper loaded: form_helper
INFO - 2018-05-14 11:30:33 --> Helper loaded: date_helper
INFO - 2018-05-14 11:30:33 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:30:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:30:33 --> Model Class Initialized
INFO - 2018-05-14 11:30:33 --> Controller Class Initialized
INFO - 2018-05-14 11:30:34 --> Model Class Initialized
INFO - 2018-05-14 11:30:34 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 11:30:34 --> Final output sent to browser
DEBUG - 2018-05-14 11:30:34 --> Total execution time: 0.6329
INFO - 2018-05-14 11:30:35 --> Config Class Initialized
INFO - 2018-05-14 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:30:35 --> Utf8 Class Initialized
INFO - 2018-05-14 11:30:35 --> URI Class Initialized
INFO - 2018-05-14 11:30:35 --> Router Class Initialized
INFO - 2018-05-14 11:30:35 --> Output Class Initialized
INFO - 2018-05-14 11:30:35 --> Security Class Initialized
DEBUG - 2018-05-14 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:30:35 --> Input Class Initialized
INFO - 2018-05-14 11:30:35 --> Language Class Initialized
INFO - 2018-05-14 11:30:35 --> Config Class Initialized
INFO - 2018-05-14 11:30:35 --> Loader Class Initialized
INFO - 2018-05-14 11:30:35 --> Hooks Class Initialized
INFO - 2018-05-14 11:30:35 --> Helper loaded: url_helper
DEBUG - 2018-05-14 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:30:35 --> Helper loaded: form_helper
INFO - 2018-05-14 11:30:35 --> Utf8 Class Initialized
INFO - 2018-05-14 11:30:35 --> Helper loaded: date_helper
INFO - 2018-05-14 11:30:35 --> URI Class Initialized
INFO - 2018-05-14 11:30:35 --> Router Class Initialized
INFO - 2018-05-14 11:30:35 --> Database Driver Class Initialized
INFO - 2018-05-14 11:30:35 --> Output Class Initialized
DEBUG - 2018-05-14 11:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:30:35 --> Security Class Initialized
INFO - 2018-05-14 11:30:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-14 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:30:35 --> Form Validation Class Initialized
INFO - 2018-05-14 11:30:35 --> Input Class Initialized
INFO - 2018-05-14 11:30:35 --> Language Class Initialized
INFO - 2018-05-14 11:30:35 --> Model Class Initialized
ERROR - 2018-05-14 11:30:35 --> 404 Page Not Found: Public/images
INFO - 2018-05-14 11:30:35 --> Controller Class Initialized
ERROR - 2018-05-14 11:30:35 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
ERROR - 2018-05-14 11:30:35 --> Severity: Notice --> Undefined property: stdClass::$ID C:\xampp\htdocs\mcms\application\controllers\Main.php 286
INFO - 2018-05-14 11:35:03 --> Config Class Initialized
INFO - 2018-05-14 11:35:04 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:35:04 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:35:04 --> Utf8 Class Initialized
INFO - 2018-05-14 11:35:04 --> URI Class Initialized
INFO - 2018-05-14 11:35:04 --> Router Class Initialized
INFO - 2018-05-14 11:35:04 --> Output Class Initialized
INFO - 2018-05-14 11:35:04 --> Security Class Initialized
DEBUG - 2018-05-14 11:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:35:04 --> Input Class Initialized
INFO - 2018-05-14 11:35:04 --> Language Class Initialized
INFO - 2018-05-14 11:35:04 --> Loader Class Initialized
INFO - 2018-05-14 11:35:04 --> Helper loaded: url_helper
INFO - 2018-05-14 11:35:04 --> Helper loaded: form_helper
INFO - 2018-05-14 11:35:04 --> Helper loaded: date_helper
INFO - 2018-05-14 11:35:04 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:35:04 --> Form Validation Class Initialized
INFO - 2018-05-14 11:35:04 --> Model Class Initialized
INFO - 2018-05-14 11:35:04 --> Controller Class Initialized
INFO - 2018-05-14 11:35:04 --> Model Class Initialized
INFO - 2018-05-14 11:35:04 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 11:35:04 --> Final output sent to browser
DEBUG - 2018-05-14 11:35:04 --> Total execution time: 0.5229
INFO - 2018-05-14 11:35:05 --> Config Class Initialized
INFO - 2018-05-14 11:35:05 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:35:05 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:35:05 --> Utf8 Class Initialized
INFO - 2018-05-14 11:35:05 --> URI Class Initialized
INFO - 2018-05-14 11:35:05 --> Router Class Initialized
INFO - 2018-05-14 11:35:05 --> Output Class Initialized
INFO - 2018-05-14 11:35:05 --> Security Class Initialized
DEBUG - 2018-05-14 11:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:35:05 --> Input Class Initialized
INFO - 2018-05-14 11:35:05 --> Language Class Initialized
INFO - 2018-05-14 11:35:05 --> Loader Class Initialized
INFO - 2018-05-14 11:35:05 --> Helper loaded: url_helper
INFO - 2018-05-14 11:35:05 --> Helper loaded: form_helper
INFO - 2018-05-14 11:35:05 --> Helper loaded: date_helper
INFO - 2018-05-14 11:35:05 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:35:05 --> Form Validation Class Initialized
INFO - 2018-05-14 11:35:05 --> Model Class Initialized
INFO - 2018-05-14 11:35:05 --> Controller Class Initialized
INFO - 2018-05-14 11:39:01 --> Config Class Initialized
INFO - 2018-05-14 11:39:01 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:01 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:01 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:01 --> URI Class Initialized
DEBUG - 2018-05-14 11:39:01 --> No URI present. Default controller set.
INFO - 2018-05-14 11:39:01 --> Router Class Initialized
INFO - 2018-05-14 11:39:01 --> Output Class Initialized
INFO - 2018-05-14 11:39:01 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:01 --> Input Class Initialized
INFO - 2018-05-14 11:39:01 --> Language Class Initialized
INFO - 2018-05-14 11:39:01 --> Loader Class Initialized
INFO - 2018-05-14 11:39:01 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:01 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:01 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:01 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:01 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:01 --> Model Class Initialized
INFO - 2018-05-14 11:39:01 --> Controller Class Initialized
INFO - 2018-05-14 11:39:01 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:39:01 --> Final output sent to browser
DEBUG - 2018-05-14 11:39:01 --> Total execution time: 0.6663
INFO - 2018-05-14 11:39:02 --> Config Class Initialized
INFO - 2018-05-14 11:39:02 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:02 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:02 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:02 --> URI Class Initialized
DEBUG - 2018-05-14 11:39:02 --> No URI present. Default controller set.
INFO - 2018-05-14 11:39:02 --> Router Class Initialized
INFO - 2018-05-14 11:39:02 --> Output Class Initialized
INFO - 2018-05-14 11:39:02 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:02 --> Input Class Initialized
INFO - 2018-05-14 11:39:02 --> Language Class Initialized
INFO - 2018-05-14 11:39:02 --> Loader Class Initialized
INFO - 2018-05-14 11:39:02 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:02 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:02 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:02 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:02 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:02 --> Model Class Initialized
INFO - 2018-05-14 11:39:02 --> Controller Class Initialized
INFO - 2018-05-14 11:39:02 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:39:02 --> Final output sent to browser
DEBUG - 2018-05-14 11:39:02 --> Total execution time: 0.4531
INFO - 2018-05-14 11:39:07 --> Config Class Initialized
INFO - 2018-05-14 11:39:07 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:07 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:07 --> URI Class Initialized
INFO - 2018-05-14 11:39:07 --> Router Class Initialized
INFO - 2018-05-14 11:39:07 --> Output Class Initialized
INFO - 2018-05-14 11:39:07 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:07 --> Input Class Initialized
INFO - 2018-05-14 11:39:07 --> Language Class Initialized
INFO - 2018-05-14 11:39:07 --> Loader Class Initialized
INFO - 2018-05-14 11:39:07 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:07 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:07 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:07 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:07 --> Model Class Initialized
INFO - 2018-05-14 11:39:07 --> Controller Class Initialized
INFO - 2018-05-14 11:39:07 --> Config Class Initialized
INFO - 2018-05-14 11:39:07 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:07 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:07 --> URI Class Initialized
INFO - 2018-05-14 11:39:07 --> Router Class Initialized
INFO - 2018-05-14 11:39:07 --> Output Class Initialized
INFO - 2018-05-14 11:39:07 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:07 --> Input Class Initialized
INFO - 2018-05-14 11:39:07 --> Language Class Initialized
INFO - 2018-05-14 11:39:07 --> Loader Class Initialized
INFO - 2018-05-14 11:39:07 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:07 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:07 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:08 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:08 --> Model Class Initialized
INFO - 2018-05-14 11:39:08 --> Controller Class Initialized
INFO - 2018-05-14 11:39:08 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:39:08 --> Final output sent to browser
DEBUG - 2018-05-14 11:39:08 --> Total execution time: 0.3893
INFO - 2018-05-14 11:39:13 --> Config Class Initialized
INFO - 2018-05-14 11:39:13 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:13 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:13 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:13 --> URI Class Initialized
INFO - 2018-05-14 11:39:13 --> Router Class Initialized
INFO - 2018-05-14 11:39:13 --> Output Class Initialized
INFO - 2018-05-14 11:39:13 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:13 --> Input Class Initialized
INFO - 2018-05-14 11:39:14 --> Language Class Initialized
INFO - 2018-05-14 11:39:14 --> Loader Class Initialized
INFO - 2018-05-14 11:39:14 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:14 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:14 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:14 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:14 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:14 --> Model Class Initialized
INFO - 2018-05-14 11:39:14 --> Controller Class Initialized
INFO - 2018-05-14 11:39:14 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 11:39:14 --> Final output sent to browser
INFO - 2018-05-14 11:39:14 --> Config Class Initialized
DEBUG - 2018-05-14 11:39:14 --> Total execution time: 0.4150
INFO - 2018-05-14 11:39:14 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:14 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:14 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:14 --> URI Class Initialized
INFO - 2018-05-14 11:39:14 --> Router Class Initialized
INFO - 2018-05-14 11:39:14 --> Output Class Initialized
INFO - 2018-05-14 11:39:14 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:14 --> Input Class Initialized
INFO - 2018-05-14 11:39:14 --> Language Class Initialized
ERROR - 2018-05-14 11:39:14 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 11:39:17 --> Config Class Initialized
INFO - 2018-05-14 11:39:17 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:17 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:17 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:17 --> URI Class Initialized
INFO - 2018-05-14 11:39:17 --> Router Class Initialized
INFO - 2018-05-14 11:39:17 --> Output Class Initialized
INFO - 2018-05-14 11:39:17 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:17 --> Input Class Initialized
INFO - 2018-05-14 11:39:17 --> Language Class Initialized
INFO - 2018-05-14 11:39:17 --> Loader Class Initialized
INFO - 2018-05-14 11:39:17 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:17 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:17 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:17 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:17 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:18 --> Model Class Initialized
INFO - 2018-05-14 11:39:18 --> Controller Class Initialized
INFO - 2018-05-14 11:39:18 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 11:39:18 --> Final output sent to browser
INFO - 2018-05-14 11:39:18 --> Config Class Initialized
DEBUG - 2018-05-14 11:39:18 --> Total execution time: 0.5343
INFO - 2018-05-14 11:39:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:18 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:18 --> URI Class Initialized
INFO - 2018-05-14 11:39:18 --> Router Class Initialized
INFO - 2018-05-14 11:39:18 --> Output Class Initialized
INFO - 2018-05-14 11:39:18 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:18 --> Input Class Initialized
INFO - 2018-05-14 11:39:18 --> Language Class Initialized
ERROR - 2018-05-14 11:39:18 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 11:39:18 --> Config Class Initialized
INFO - 2018-05-14 11:39:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:18 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:18 --> URI Class Initialized
INFO - 2018-05-14 11:39:18 --> Router Class Initialized
INFO - 2018-05-14 11:39:18 --> Output Class Initialized
INFO - 2018-05-14 11:39:18 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:18 --> Input Class Initialized
INFO - 2018-05-14 11:39:19 --> Language Class Initialized
INFO - 2018-05-14 11:39:19 --> Loader Class Initialized
INFO - 2018-05-14 11:39:19 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:19 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:19 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:19 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:19 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:19 --> Model Class Initialized
INFO - 2018-05-14 11:39:19 --> Controller Class Initialized
INFO - 2018-05-14 11:39:24 --> Config Class Initialized
INFO - 2018-05-14 11:39:24 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:24 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:24 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:24 --> URI Class Initialized
INFO - 2018-05-14 11:39:24 --> Router Class Initialized
INFO - 2018-05-14 11:39:24 --> Output Class Initialized
INFO - 2018-05-14 11:39:24 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:24 --> Input Class Initialized
INFO - 2018-05-14 11:39:24 --> Language Class Initialized
ERROR - 2018-05-14 11:39:24 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 11:39:29 --> Config Class Initialized
INFO - 2018-05-14 11:39:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:29 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:29 --> URI Class Initialized
INFO - 2018-05-14 11:39:29 --> Router Class Initialized
INFO - 2018-05-14 11:39:29 --> Output Class Initialized
INFO - 2018-05-14 11:39:29 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:29 --> Input Class Initialized
INFO - 2018-05-14 11:39:29 --> Language Class Initialized
INFO - 2018-05-14 11:39:29 --> Loader Class Initialized
INFO - 2018-05-14 11:39:29 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:29 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:29 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:29 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:29 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:29 --> Model Class Initialized
INFO - 2018-05-14 11:39:29 --> Controller Class Initialized
INFO - 2018-05-14 11:39:29 --> Config Class Initialized
INFO - 2018-05-14 11:39:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:30 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:30 --> URI Class Initialized
INFO - 2018-05-14 11:39:30 --> Router Class Initialized
INFO - 2018-05-14 11:39:30 --> Output Class Initialized
INFO - 2018-05-14 11:39:30 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:30 --> Input Class Initialized
INFO - 2018-05-14 11:39:30 --> Language Class Initialized
INFO - 2018-05-14 11:39:30 --> Loader Class Initialized
INFO - 2018-05-14 11:39:30 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:30 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:30 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:30 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:30 --> Config Class Initialized
INFO - 2018-05-14 11:39:30 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:30 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:30 --> Model Class Initialized
DEBUG - 2018-05-14 11:39:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:30 --> Controller Class Initialized
INFO - 2018-05-14 11:39:30 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:30 --> URI Class Initialized
INFO - 2018-05-14 11:39:30 --> Router Class Initialized
INFO - 2018-05-14 11:39:30 --> Output Class Initialized
INFO - 2018-05-14 11:39:30 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:30 --> Input Class Initialized
INFO - 2018-05-14 11:39:30 --> Language Class Initialized
INFO - 2018-05-14 11:39:30 --> Loader Class Initialized
INFO - 2018-05-14 11:39:30 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:30 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:30 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:30 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:30 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:30 --> Config Class Initialized
INFO - 2018-05-14 11:39:30 --> Model Class Initialized
INFO - 2018-05-14 11:39:30 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:30 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:30 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:30 --> URI Class Initialized
INFO - 2018-05-14 11:39:30 --> Router Class Initialized
INFO - 2018-05-14 11:39:30 --> Output Class Initialized
INFO - 2018-05-14 11:39:30 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:30 --> Input Class Initialized
INFO - 2018-05-14 11:39:30 --> Language Class Initialized
INFO - 2018-05-14 11:39:30 --> Loader Class Initialized
INFO - 2018-05-14 11:39:31 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:31 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:31 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:31 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:31 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:31 --> Model Class Initialized
INFO - 2018-05-14 11:39:31 --> Controller Class Initialized
INFO - 2018-05-14 11:39:31 --> Config Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:31 --> Hooks Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
DEBUG - 2018-05-14 11:39:31 --> UTF-8 Support Enabled
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:31 --> Utf8 Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:31 --> URI Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:39:31 --> Router Class Initialized
INFO - 2018-05-14 11:39:31 --> Output Class Initialized
INFO - 2018-05-14 11:39:31 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:31 --> Input Class Initialized
INFO - 2018-05-14 11:39:31 --> Language Class Initialized
INFO - 2018-05-14 11:39:31 --> Loader Class Initialized
INFO - 2018-05-14 11:39:31 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:31 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:31 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:31 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:31 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:31 --> Model Class Initialized
INFO - 2018-05-14 11:39:31 --> Controller Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:39:31 --> Config Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:31 --> Hooks Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
DEBUG - 2018-05-14 11:39:31 --> UTF-8 Support Enabled
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:31 --> Utf8 Class Initialized
ERROR - 2018-05-14 11:39:31 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:39:31 --> URI Class Initialized
INFO - 2018-05-14 11:39:31 --> Router Class Initialized
INFO - 2018-05-14 11:39:31 --> Output Class Initialized
INFO - 2018-05-14 11:39:31 --> Config Class Initialized
INFO - 2018-05-14 11:39:31 --> Security Class Initialized
INFO - 2018-05-14 11:39:31 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 11:39:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:32 --> Input Class Initialized
INFO - 2018-05-14 11:39:32 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:32 --> Language Class Initialized
INFO - 2018-05-14 11:39:32 --> URI Class Initialized
INFO - 2018-05-14 11:39:32 --> Loader Class Initialized
INFO - 2018-05-14 11:39:32 --> Config Class Initialized
INFO - 2018-05-14 11:39:32 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:32 --> Router Class Initialized
DEBUG - 2018-05-14 11:39:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:32 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:32 --> Output Class Initialized
INFO - 2018-05-14 11:39:32 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:32 --> URI Class Initialized
INFO - 2018-05-14 11:39:32 --> Security Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:32 --> Router Class Initialized
DEBUG - 2018-05-14 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:32 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:32 --> Output Class Initialized
INFO - 2018-05-14 11:39:32 --> Input Class Initialized
DEBUG - 2018-05-14 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:32 --> Config Class Initialized
INFO - 2018-05-14 11:39:32 --> Security Class Initialized
INFO - 2018-05-14 11:39:32 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:32 --> Language Class Initialized
INFO - 2018-05-14 11:39:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-14 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:32 --> Loader Class Initialized
DEBUG - 2018-05-14 11:39:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:32 --> Input Class Initialized
INFO - 2018-05-14 11:39:32 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:32 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:32 --> Language Class Initialized
INFO - 2018-05-14 11:39:32 --> URI Class Initialized
INFO - 2018-05-14 11:39:32 --> Model Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:32 --> Loader Class Initialized
INFO - 2018-05-14 11:39:32 --> Controller Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:32 --> Config Class Initialized
INFO - 2018-05-14 11:39:32 --> Router Class Initialized
ERROR - 2018-05-14 11:39:32 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:32 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:32 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:32 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:32 --> Output Class Initialized
DEBUG - 2018-05-14 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-05-14 11:39:32 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
DEBUG - 2018-05-14 11:39:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:32 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:32 --> Security Class Initialized
INFO - 2018-05-14 11:39:32 --> Utf8 Class Initialized
ERROR - 2018-05-14 11:39:32 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:32 --> Helper loaded: date_helper
DEBUG - 2018-05-14 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:32 --> URI Class Initialized
INFO - 2018-05-14 11:39:32 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:32 --> Input Class Initialized
ERROR - 2018-05-14 11:39:32 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:39:32 --> Router Class Initialized
INFO - 2018-05-14 11:39:32 --> Output Class Initialized
DEBUG - 2018-05-14 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:32 --> Security Class Initialized
INFO - 2018-05-14 11:39:32 --> Config Class Initialized
INFO - 2018-05-14 11:39:32 --> Language Class Initialized
ERROR - 2018-05-14 11:39:32 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:39:32 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:32 --> Input Class Initialized
INFO - 2018-05-14 11:39:32 --> Language Class Initialized
INFO - 2018-05-14 11:39:32 --> Loader Class Initialized
INFO - 2018-05-14 11:39:32 --> Loader Class Initialized
ERROR - 2018-05-14 11:39:32 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
DEBUG - 2018-05-14 11:39:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:32 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:32 --> Config Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:32 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:32 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:32 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:32 --> URI Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: form_helper
DEBUG - 2018-05-14 11:39:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:32 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:32 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:32 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:32 --> Model Class Initialized
INFO - 2018-05-14 11:39:32 --> Router Class Initialized
INFO - 2018-05-14 11:39:32 --> Controller Class Initialized
INFO - 2018-05-14 11:39:32 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:32 --> URI Class Initialized
INFO - 2018-05-14 11:39:32 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:32 --> Output Class Initialized
DEBUG - 2018-05-14 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-14 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:33 --> Router Class Initialized
INFO - 2018-05-14 11:39:33 --> Security Class Initialized
INFO - 2018-05-14 11:39:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:33 --> Output Class Initialized
DEBUG - 2018-05-14 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:33 --> Model Class Initialized
INFO - 2018-05-14 11:39:33 --> Input Class Initialized
INFO - 2018-05-14 11:39:33 --> Security Class Initialized
INFO - 2018-05-14 11:39:33 --> Controller Class Initialized
INFO - 2018-05-14 11:39:33 --> Language Class Initialized
DEBUG - 2018-05-14 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:33 --> Loader Class Initialized
INFO - 2018-05-14 11:39:33 --> Input Class Initialized
INFO - 2018-05-14 11:39:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:33 --> Model Class Initialized
INFO - 2018-05-14 11:39:33 --> Language Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:33 --> Controller Class Initialized
INFO - 2018-05-14 11:39:33 --> Loader Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:33 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:33 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:33 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:33 --> Config Class Initialized
INFO - 2018-05-14 11:39:33 --> Model Class Initialized
INFO - 2018-05-14 11:39:33 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:33 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:33 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:33 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-14 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-14 11:39:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:33 --> Config Class Initialized
INFO - 2018-05-14 11:39:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:33 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:33 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:33 --> URI Class Initialized
DEBUG - 2018-05-14 11:39:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:33 --> Model Class Initialized
INFO - 2018-05-14 11:39:33 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:33 --> Controller Class Initialized
INFO - 2018-05-14 11:39:33 --> Router Class Initialized
INFO - 2018-05-14 11:39:33 --> URI Class Initialized
INFO - 2018-05-14 11:39:33 --> Output Class Initialized
INFO - 2018-05-14 11:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:33 --> Router Class Initialized
INFO - 2018-05-14 11:39:33 --> Security Class Initialized
INFO - 2018-05-14 11:39:33 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:33 --> Output Class Initialized
INFO - 2018-05-14 11:39:33 --> Model Class Initialized
DEBUG - 2018-05-14 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:33 --> Security Class Initialized
INFO - 2018-05-14 11:39:33 --> Input Class Initialized
INFO - 2018-05-14 11:39:33 --> Controller Class Initialized
INFO - 2018-05-14 11:39:33 --> Language Class Initialized
DEBUG - 2018-05-14 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:33 --> Config Class Initialized
INFO - 2018-05-14 11:39:33 --> Input Class Initialized
INFO - 2018-05-14 11:39:33 --> Config Class Initialized
INFO - 2018-05-14 11:39:33 --> Loader Class Initialized
INFO - 2018-05-14 11:39:33 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:33 --> Language Class Initialized
INFO - 2018-05-14 11:39:33 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: url_helper
DEBUG - 2018-05-14 11:39:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 11:39:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:33 --> Loader Class Initialized
INFO - 2018-05-14 11:39:33 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:33 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:33 --> URI Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:33 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:33 --> URI Class Initialized
INFO - 2018-05-14 11:39:33 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:33 --> Router Class Initialized
INFO - 2018-05-14 11:39:33 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:34 --> Output Class Initialized
DEBUG - 2018-05-14 11:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:34 --> Security Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:34 --> Router Class Initialized
INFO - 2018-05-14 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:34 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:34 --> Output Class Initialized
DEBUG - 2018-05-14 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:34 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:34 --> Input Class Initialized
INFO - 2018-05-14 11:39:34 --> Language Class Initialized
DEBUG - 2018-05-14 11:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:34 --> Model Class Initialized
INFO - 2018-05-14 11:39:34 --> Security Class Initialized
INFO - 2018-05-14 11:39:34 --> Loader Class Initialized
INFO - 2018-05-14 11:39:34 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:34 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:34 --> Input Class Initialized
INFO - 2018-05-14 11:39:34 --> Config Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:34 --> Language Class Initialized
INFO - 2018-05-14 11:39:34 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:34 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: date_helper
DEBUG - 2018-05-14 11:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:34 --> Model Class Initialized
INFO - 2018-05-14 11:39:34 --> Loader Class Initialized
INFO - 2018-05-14 11:39:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:34 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:34 --> Controller Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:34 --> URI Class Initialized
INFO - 2018-05-14 11:39:34 --> Config Class Initialized
INFO - 2018-05-14 11:39:34 --> Config Class Initialized
DEBUG - 2018-05-14 11:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:34 --> Config Class Initialized
INFO - 2018-05-14 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:34 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:34 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:34 --> Router Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:34 --> Form Validation Class Initialized
DEBUG - 2018-05-14 11:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:34 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:34 --> Output Class Initialized
INFO - 2018-05-14 11:39:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:34 --> Model Class Initialized
INFO - 2018-05-14 11:39:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:34 --> Controller Class Initialized
INFO - 2018-05-14 11:39:34 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:34 --> Security Class Initialized
INFO - 2018-05-14 11:39:34 --> URI Class Initialized
INFO - 2018-05-14 11:39:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:34 --> URI Class Initialized
DEBUG - 2018-05-14 11:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-14 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:34 --> Router Class Initialized
INFO - 2018-05-14 11:39:34 --> Router Class Initialized
INFO - 2018-05-14 11:39:34 --> URI Class Initialized
INFO - 2018-05-14 11:39:34 --> Input Class Initialized
INFO - 2018-05-14 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:34 --> Language Class Initialized
INFO - 2018-05-14 11:39:34 --> Output Class Initialized
INFO - 2018-05-14 11:39:34 --> Output Class Initialized
INFO - 2018-05-14 11:39:34 --> Router Class Initialized
INFO - 2018-05-14 11:39:34 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:34 --> Config Class Initialized
INFO - 2018-05-14 11:39:34 --> Loader Class Initialized
INFO - 2018-05-14 11:39:34 --> Output Class Initialized
INFO - 2018-05-14 11:39:34 --> Security Class Initialized
INFO - 2018-05-14 11:39:34 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:34 --> Security Class Initialized
INFO - 2018-05-14 11:39:34 --> Model Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: url_helper
DEBUG - 2018-05-14 11:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:34 --> Security Class Initialized
INFO - 2018-05-14 11:39:34 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:34 --> Input Class Initialized
INFO - 2018-05-14 11:39:34 --> Helper loaded: form_helper
DEBUG - 2018-05-14 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:34 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:34 --> Language Class Initialized
INFO - 2018-05-14 11:39:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:34 --> Input Class Initialized
INFO - 2018-05-14 11:39:34 --> Config Class Initialized
INFO - 2018-05-14 11:39:34 --> URI Class Initialized
INFO - 2018-05-14 11:39:34 --> Input Class Initialized
INFO - 2018-05-14 11:39:34 --> Hooks Class Initialized
INFO - 2018-05-14 11:39:34 --> Language Class Initialized
DEBUG - 2018-05-14 11:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:34 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:34 --> Loader Class Initialized
INFO - 2018-05-14 11:39:34 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:34 --> Loader Class Initialized
INFO - 2018-05-14 11:39:34 --> Router Class Initialized
INFO - 2018-05-14 11:39:34 --> Language Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: url_helper
DEBUG - 2018-05-14 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:35 --> Output Class Initialized
INFO - 2018-05-14 11:39:35 --> URI Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:35 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:35 --> Loader Class Initialized
INFO - 2018-05-14 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:35 --> Router Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:35 --> Security Class Initialized
INFO - 2018-05-14 11:39:35 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:35 --> Helper loaded: date_helper
DEBUG - 2018-05-14 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:35 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:35 --> Output Class Initialized
INFO - 2018-05-14 11:39:35 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:35 --> Model Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:35 --> Input Class Initialized
INFO - 2018-05-14 11:39:35 --> Security Class Initialized
INFO - 2018-05-14 11:39:35 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:35 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:35 --> Language Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: date_helper
DEBUG - 2018-05-14 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-14 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:35 --> Loader Class Initialized
INFO - 2018-05-14 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:35 --> Input Class Initialized
INFO - 2018-05-14 11:39:35 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:35 --> Language Class Initialized
DEBUG - 2018-05-14 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:35 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:35 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:35 --> Loader Class Initialized
INFO - 2018-05-14 11:39:35 --> Model Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:35 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:35 --> Controller Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:35 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:35 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:35 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:35 --> Form Validation Class Initialized
DEBUG - 2018-05-14 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:35 --> Model Class Initialized
INFO - 2018-05-14 11:39:35 --> Database Driver Class Initialized
INFO - 2018-05-14 11:39:35 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:35 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:35 --> Model Class Initialized
INFO - 2018-05-14 11:39:35 --> Controller Class Initialized
INFO - 2018-05-14 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:35 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:35 --> Model Class Initialized
INFO - 2018-05-14 11:39:35 --> Controller Class Initialized
INFO - 2018-05-14 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:35 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:35 --> Model Class Initialized
INFO - 2018-05-14 11:39:35 --> Controller Class Initialized
INFO - 2018-05-14 11:39:51 --> Config Class Initialized
INFO - 2018-05-14 11:39:51 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:51 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:51 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:51 --> URI Class Initialized
INFO - 2018-05-14 11:39:51 --> Router Class Initialized
INFO - 2018-05-14 11:39:51 --> Output Class Initialized
INFO - 2018-05-14 11:39:51 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:51 --> Input Class Initialized
INFO - 2018-05-14 11:39:51 --> Language Class Initialized
INFO - 2018-05-14 11:39:51 --> Loader Class Initialized
INFO - 2018-05-14 11:39:51 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:51 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:51 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:51 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:51 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:51 --> Model Class Initialized
INFO - 2018-05-14 11:39:51 --> Controller Class Initialized
INFO - 2018-05-14 11:39:51 --> Config Class Initialized
INFO - 2018-05-14 11:39:51 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:51 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:51 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:51 --> URI Class Initialized
INFO - 2018-05-14 11:39:51 --> Router Class Initialized
INFO - 2018-05-14 11:39:51 --> Output Class Initialized
INFO - 2018-05-14 11:39:52 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:52 --> Input Class Initialized
INFO - 2018-05-14 11:39:52 --> Language Class Initialized
INFO - 2018-05-14 11:39:52 --> Loader Class Initialized
INFO - 2018-05-14 11:39:52 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:52 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:52 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:52 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:52 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:52 --> Model Class Initialized
INFO - 2018-05-14 11:39:52 --> Controller Class Initialized
INFO - 2018-05-14 11:39:52 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 11:39:52 --> Final output sent to browser
DEBUG - 2018-05-14 11:39:52 --> Total execution time: 0.4489
INFO - 2018-05-14 11:39:53 --> Config Class Initialized
INFO - 2018-05-14 11:39:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:53 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:53 --> URI Class Initialized
INFO - 2018-05-14 11:39:53 --> Router Class Initialized
INFO - 2018-05-14 11:39:53 --> Output Class Initialized
INFO - 2018-05-14 11:39:53 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:54 --> Input Class Initialized
INFO - 2018-05-14 11:39:54 --> Language Class Initialized
INFO - 2018-05-14 11:39:54 --> Loader Class Initialized
INFO - 2018-05-14 11:39:54 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:54 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:54 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:54 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:54 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:54 --> Model Class Initialized
INFO - 2018-05-14 11:39:54 --> Controller Class Initialized
INFO - 2018-05-14 11:39:54 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 11:39:54 --> Final output sent to browser
DEBUG - 2018-05-14 11:39:54 --> Total execution time: 0.5058
INFO - 2018-05-14 11:39:57 --> Config Class Initialized
INFO - 2018-05-14 11:39:57 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:39:57 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:39:57 --> Utf8 Class Initialized
INFO - 2018-05-14 11:39:57 --> URI Class Initialized
INFO - 2018-05-14 11:39:57 --> Router Class Initialized
INFO - 2018-05-14 11:39:57 --> Output Class Initialized
INFO - 2018-05-14 11:39:57 --> Security Class Initialized
DEBUG - 2018-05-14 11:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:39:57 --> Input Class Initialized
INFO - 2018-05-14 11:39:57 --> Language Class Initialized
INFO - 2018-05-14 11:39:57 --> Loader Class Initialized
INFO - 2018-05-14 11:39:57 --> Helper loaded: url_helper
INFO - 2018-05-14 11:39:57 --> Helper loaded: form_helper
INFO - 2018-05-14 11:39:57 --> Helper loaded: date_helper
INFO - 2018-05-14 11:39:57 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:39:57 --> Form Validation Class Initialized
INFO - 2018-05-14 11:39:57 --> Model Class Initialized
INFO - 2018-05-14 11:39:57 --> Controller Class Initialized
DEBUG - 2018-05-14 11:39:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:39:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:40:48 --> Config Class Initialized
INFO - 2018-05-14 11:40:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:40:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:40:48 --> Utf8 Class Initialized
INFO - 2018-05-14 11:40:48 --> URI Class Initialized
INFO - 2018-05-14 11:40:48 --> Router Class Initialized
INFO - 2018-05-14 11:40:48 --> Output Class Initialized
INFO - 2018-05-14 11:40:48 --> Security Class Initialized
DEBUG - 2018-05-14 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:40:48 --> Input Class Initialized
INFO - 2018-05-14 11:40:48 --> Language Class Initialized
INFO - 2018-05-14 11:40:48 --> Loader Class Initialized
INFO - 2018-05-14 11:40:48 --> Helper loaded: url_helper
INFO - 2018-05-14 11:40:48 --> Helper loaded: form_helper
INFO - 2018-05-14 11:40:48 --> Helper loaded: date_helper
INFO - 2018-05-14 11:40:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:40:49 --> Form Validation Class Initialized
INFO - 2018-05-14 11:40:49 --> Model Class Initialized
INFO - 2018-05-14 11:40:49 --> Controller Class Initialized
DEBUG - 2018-05-14 11:40:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 11:40:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 11:40:49 --> Config Class Initialized
INFO - 2018-05-14 11:40:49 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:40:49 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:40:49 --> Utf8 Class Initialized
INFO - 2018-05-14 11:40:49 --> URI Class Initialized
INFO - 2018-05-14 11:40:49 --> Router Class Initialized
INFO - 2018-05-14 11:40:49 --> Output Class Initialized
INFO - 2018-05-14 11:40:49 --> Security Class Initialized
DEBUG - 2018-05-14 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:40:49 --> Input Class Initialized
INFO - 2018-05-14 11:40:49 --> Language Class Initialized
INFO - 2018-05-14 11:40:49 --> Loader Class Initialized
INFO - 2018-05-14 11:40:49 --> Helper loaded: url_helper
INFO - 2018-05-14 11:40:49 --> Helper loaded: form_helper
INFO - 2018-05-14 11:40:49 --> Helper loaded: date_helper
INFO - 2018-05-14 11:40:49 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:40:49 --> Form Validation Class Initialized
INFO - 2018-05-14 11:40:49 --> Model Class Initialized
INFO - 2018-05-14 11:40:49 --> Controller Class Initialized
INFO - 2018-05-14 11:40:49 --> Model Class Initialized
INFO - 2018-05-14 11:40:49 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 11:40:49 --> Final output sent to browser
DEBUG - 2018-05-14 11:40:49 --> Total execution time: 0.5663
INFO - 2018-05-14 11:40:50 --> Config Class Initialized
INFO - 2018-05-14 11:40:50 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:40:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:40:50 --> Utf8 Class Initialized
INFO - 2018-05-14 11:40:50 --> URI Class Initialized
INFO - 2018-05-14 11:40:50 --> Router Class Initialized
INFO - 2018-05-14 11:40:50 --> Output Class Initialized
INFO - 2018-05-14 11:40:50 --> Security Class Initialized
DEBUG - 2018-05-14 11:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:40:50 --> Input Class Initialized
INFO - 2018-05-14 11:40:50 --> Language Class Initialized
INFO - 2018-05-14 11:40:50 --> Loader Class Initialized
INFO - 2018-05-14 11:40:50 --> Helper loaded: url_helper
INFO - 2018-05-14 11:40:50 --> Helper loaded: form_helper
INFO - 2018-05-14 11:40:50 --> Helper loaded: date_helper
INFO - 2018-05-14 11:40:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:40:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:40:50 --> Model Class Initialized
INFO - 2018-05-14 11:40:50 --> Controller Class Initialized
INFO - 2018-05-14 11:45:39 --> Config Class Initialized
INFO - 2018-05-14 11:45:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:45:39 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:39 --> Utf8 Class Initialized
INFO - 2018-05-14 11:45:39 --> URI Class Initialized
INFO - 2018-05-14 11:45:39 --> Router Class Initialized
INFO - 2018-05-14 11:45:39 --> Output Class Initialized
INFO - 2018-05-14 11:45:39 --> Security Class Initialized
DEBUG - 2018-05-14 11:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:45:40 --> Input Class Initialized
INFO - 2018-05-14 11:45:40 --> Config Class Initialized
INFO - 2018-05-14 11:45:40 --> Hooks Class Initialized
INFO - 2018-05-14 11:45:40 --> Config Class Initialized
DEBUG - 2018-05-14 11:45:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:40 --> Hooks Class Initialized
INFO - 2018-05-14 11:45:40 --> Language Class Initialized
INFO - 2018-05-14 11:45:40 --> Utf8 Class Initialized
INFO - 2018-05-14 11:45:40 --> Loader Class Initialized
DEBUG - 2018-05-14 11:45:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:40 --> URI Class Initialized
INFO - 2018-05-14 11:45:40 --> Utf8 Class Initialized
INFO - 2018-05-14 11:45:40 --> Helper loaded: url_helper
INFO - 2018-05-14 11:45:40 --> Router Class Initialized
INFO - 2018-05-14 11:45:40 --> URI Class Initialized
INFO - 2018-05-14 11:45:40 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:40 --> Output Class Initialized
INFO - 2018-05-14 11:45:40 --> Router Class Initialized
INFO - 2018-05-14 11:45:40 --> Helper loaded: date_helper
INFO - 2018-05-14 11:45:40 --> Output Class Initialized
INFO - 2018-05-14 11:45:40 --> Security Class Initialized
INFO - 2018-05-14 11:45:40 --> Database Driver Class Initialized
INFO - 2018-05-14 11:45:40 --> Security Class Initialized
DEBUG - 2018-05-14 11:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:45:40 --> Input Class Initialized
DEBUG - 2018-05-14 11:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:40 --> Language Class Initialized
INFO - 2018-05-14 11:45:40 --> Input Class Initialized
INFO - 2018-05-14 11:45:40 --> Language Class Initialized
INFO - 2018-05-14 11:45:40 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:40 --> Loader Class Initialized
INFO - 2018-05-14 11:45:40 --> Loader Class Initialized
INFO - 2018-05-14 11:45:40 --> Model Class Initialized
INFO - 2018-05-14 11:45:40 --> Helper loaded: url_helper
INFO - 2018-05-14 11:45:40 --> Controller Class Initialized
INFO - 2018-05-14 11:45:40 --> Helper loaded: url_helper
INFO - 2018-05-14 11:45:40 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:40 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:40 --> Helper loaded: date_helper
INFO - 2018-05-14 11:45:40 --> Helper loaded: date_helper
INFO - 2018-05-14 11:45:40 --> Database Driver Class Initialized
INFO - 2018-05-14 11:45:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-14 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:40 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:40 --> Model Class Initialized
INFO - 2018-05-14 11:45:40 --> Controller Class Initialized
INFO - 2018-05-14 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:40 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:40 --> Model Class Initialized
INFO - 2018-05-14 11:45:40 --> Controller Class Initialized
INFO - 2018-05-14 11:45:41 --> Config Class Initialized
INFO - 2018-05-14 11:45:41 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:45:41 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:41 --> Utf8 Class Initialized
INFO - 2018-05-14 11:45:41 --> URI Class Initialized
INFO - 2018-05-14 11:45:41 --> Router Class Initialized
INFO - 2018-05-14 11:45:41 --> Output Class Initialized
INFO - 2018-05-14 11:45:41 --> Security Class Initialized
DEBUG - 2018-05-14 11:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:45:42 --> Input Class Initialized
INFO - 2018-05-14 11:45:42 --> Config Class Initialized
INFO - 2018-05-14 11:45:42 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:45:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:42 --> Utf8 Class Initialized
INFO - 2018-05-14 11:45:42 --> Language Class Initialized
INFO - 2018-05-14 11:45:42 --> URI Class Initialized
INFO - 2018-05-14 11:45:42 --> Loader Class Initialized
INFO - 2018-05-14 11:45:42 --> Router Class Initialized
INFO - 2018-05-14 11:45:42 --> Helper loaded: url_helper
INFO - 2018-05-14 11:45:42 --> Output Class Initialized
INFO - 2018-05-14 11:45:42 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:42 --> Security Class Initialized
INFO - 2018-05-14 11:45:42 --> Helper loaded: date_helper
DEBUG - 2018-05-14 11:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:45:42 --> Database Driver Class Initialized
INFO - 2018-05-14 11:45:42 --> Input Class Initialized
INFO - 2018-05-14 11:45:42 --> Language Class Initialized
DEBUG - 2018-05-14 11:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:45:42 --> Loader Class Initialized
INFO - 2018-05-14 11:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:42 --> Helper loaded: url_helper
INFO - 2018-05-14 11:45:42 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:42 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:42 --> Model Class Initialized
INFO - 2018-05-14 11:45:42 --> Helper loaded: date_helper
INFO - 2018-05-14 11:45:42 --> Controller Class Initialized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:45:42 --> Database Driver Class Initialized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
DEBUG - 2018-05-14 11:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:45:42 --> Config Class Initialized
INFO - 2018-05-14 11:45:42 --> Hooks Class Initialized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
DEBUG - 2018-05-14 11:45:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:42 --> Utf8 Class Initialized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:42 --> URI Class Initialized
INFO - 2018-05-14 11:45:42 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:42 --> Router Class Initialized
INFO - 2018-05-14 11:45:42 --> Model Class Initialized
INFO - 2018-05-14 11:45:42 --> Output Class Initialized
INFO - 2018-05-14 11:45:42 --> Controller Class Initialized
INFO - 2018-05-14 11:45:42 --> Security Class Initialized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
DEBUG - 2018-05-14 11:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:45:42 --> Input Class Initialized
ERROR - 2018-05-14 11:45:42 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:45:43 --> Language Class Initialized
ERROR - 2018-05-14 11:45:43 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:45:43 --> Loader Class Initialized
ERROR - 2018-05-14 11:45:43 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:45:43 --> Helper loaded: url_helper
ERROR - 2018-05-14 11:45:43 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:45:43 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:43 --> Helper loaded: date_helper
INFO - 2018-05-14 11:45:43 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:43 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:43 --> Model Class Initialized
INFO - 2018-05-14 11:45:43 --> Controller Class Initialized
INFO - 2018-05-14 11:45:44 --> Config Class Initialized
INFO - 2018-05-14 11:45:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:45:44 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:45:44 --> Utf8 Class Initialized
INFO - 2018-05-14 11:45:44 --> URI Class Initialized
INFO - 2018-05-14 11:45:44 --> Router Class Initialized
INFO - 2018-05-14 11:45:44 --> Output Class Initialized
INFO - 2018-05-14 11:45:44 --> Security Class Initialized
DEBUG - 2018-05-14 11:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:45:45 --> Input Class Initialized
INFO - 2018-05-14 11:45:45 --> Language Class Initialized
INFO - 2018-05-14 11:45:45 --> Loader Class Initialized
INFO - 2018-05-14 11:45:45 --> Helper loaded: url_helper
INFO - 2018-05-14 11:45:45 --> Helper loaded: form_helper
INFO - 2018-05-14 11:45:45 --> Helper loaded: date_helper
INFO - 2018-05-14 11:45:45 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:45:45 --> Form Validation Class Initialized
INFO - 2018-05-14 11:45:45 --> Model Class Initialized
INFO - 2018-05-14 11:45:45 --> Controller Class Initialized
ERROR - 2018-05-14 11:45:45 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:45:45 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:45:45 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:45:45 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:45:45 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:45:45 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:26 --> Config Class Initialized
INFO - 2018-05-14 11:50:26 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:26 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:26 --> URI Class Initialized
INFO - 2018-05-14 11:50:26 --> Router Class Initialized
INFO - 2018-05-14 11:50:26 --> Output Class Initialized
INFO - 2018-05-14 11:50:26 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:26 --> Input Class Initialized
INFO - 2018-05-14 11:50:26 --> Language Class Initialized
INFO - 2018-05-14 11:50:26 --> Loader Class Initialized
INFO - 2018-05-14 11:50:26 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:26 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:26 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:26 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:26 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:26 --> Model Class Initialized
INFO - 2018-05-14 11:50:26 --> Controller Class Initialized
ERROR - 2018-05-14 11:50:26 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:50:26 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:50:26 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:50:26 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:50:26 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:50:26 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:38 --> Config Class Initialized
INFO - 2018-05-14 11:50:38 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:38 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:38 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:38 --> URI Class Initialized
INFO - 2018-05-14 11:50:38 --> Router Class Initialized
INFO - 2018-05-14 11:50:38 --> Output Class Initialized
INFO - 2018-05-14 11:50:38 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:38 --> Input Class Initialized
INFO - 2018-05-14 11:50:38 --> Language Class Initialized
INFO - 2018-05-14 11:50:38 --> Loader Class Initialized
INFO - 2018-05-14 11:50:38 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:38 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:38 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:38 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:39 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:39 --> Model Class Initialized
INFO - 2018-05-14 11:50:39 --> Controller Class Initialized
INFO - 2018-05-14 11:50:39 --> Model Class Initialized
INFO - 2018-05-14 11:50:39 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 11:50:39 --> Final output sent to browser
DEBUG - 2018-05-14 11:50:39 --> Total execution time: 0.7672
INFO - 2018-05-14 11:50:42 --> Config Class Initialized
INFO - 2018-05-14 11:50:42 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:42 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:42 --> URI Class Initialized
INFO - 2018-05-14 11:50:42 --> Router Class Initialized
INFO - 2018-05-14 11:50:42 --> Output Class Initialized
INFO - 2018-05-14 11:50:42 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:42 --> Input Class Initialized
INFO - 2018-05-14 11:50:42 --> Language Class Initialized
INFO - 2018-05-14 11:50:42 --> Loader Class Initialized
INFO - 2018-05-14 11:50:43 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:43 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:43 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:43 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:43 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:43 --> Model Class Initialized
INFO - 2018-05-14 11:50:43 --> Controller Class Initialized
INFO - 2018-05-14 11:50:45 --> Config Class Initialized
INFO - 2018-05-14 11:50:45 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:45 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:45 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:45 --> URI Class Initialized
INFO - 2018-05-14 11:50:45 --> Router Class Initialized
INFO - 2018-05-14 11:50:45 --> Output Class Initialized
INFO - 2018-05-14 11:50:45 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:45 --> Input Class Initialized
INFO - 2018-05-14 11:50:45 --> Language Class Initialized
INFO - 2018-05-14 11:50:45 --> Loader Class Initialized
INFO - 2018-05-14 11:50:45 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:45 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:45 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:45 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:45 --> Config Class Initialized
INFO - 2018-05-14 11:50:45 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:45 --> Hooks Class Initialized
INFO - 2018-05-14 11:50:45 --> Model Class Initialized
INFO - 2018-05-14 11:50:45 --> Controller Class Initialized
DEBUG - 2018-05-14 11:50:45 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:45 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:46 --> URI Class Initialized
INFO - 2018-05-14 11:50:46 --> Router Class Initialized
INFO - 2018-05-14 11:50:46 --> Output Class Initialized
INFO - 2018-05-14 11:50:46 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:46 --> Input Class Initialized
INFO - 2018-05-14 11:50:46 --> Language Class Initialized
INFO - 2018-05-14 11:50:46 --> Loader Class Initialized
INFO - 2018-05-14 11:50:46 --> Config Class Initialized
INFO - 2018-05-14 11:50:46 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:46 --> Hooks Class Initialized
INFO - 2018-05-14 11:50:46 --> Helper loaded: form_helper
DEBUG - 2018-05-14 11:50:46 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:46 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:46 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:46 --> URI Class Initialized
INFO - 2018-05-14 11:50:46 --> Database Driver Class Initialized
INFO - 2018-05-14 11:50:46 --> Router Class Initialized
DEBUG - 2018-05-14 11:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:46 --> Output Class Initialized
INFO - 2018-05-14 11:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:46 --> Security Class Initialized
INFO - 2018-05-14 11:50:46 --> Form Validation Class Initialized
DEBUG - 2018-05-14 11:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:46 --> Model Class Initialized
INFO - 2018-05-14 11:50:46 --> Input Class Initialized
INFO - 2018-05-14 11:50:46 --> Controller Class Initialized
INFO - 2018-05-14 11:50:46 --> Language Class Initialized
INFO - 2018-05-14 11:50:46 --> Loader Class Initialized
INFO - 2018-05-14 11:50:46 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:46 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:46 --> Config Class Initialized
INFO - 2018-05-14 11:50:46 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:46 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:46 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:46 --> Database Driver Class Initialized
INFO - 2018-05-14 11:50:46 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:46 --> URI Class Initialized
DEBUG - 2018-05-14 11:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:46 --> Router Class Initialized
INFO - 2018-05-14 11:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:46 --> Output Class Initialized
INFO - 2018-05-14 11:50:46 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:46 --> Security Class Initialized
INFO - 2018-05-14 11:50:46 --> Model Class Initialized
INFO - 2018-05-14 11:50:47 --> Controller Class Initialized
DEBUG - 2018-05-14 11:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:47 --> Input Class Initialized
INFO - 2018-05-14 11:50:47 --> Language Class Initialized
INFO - 2018-05-14 11:50:47 --> Loader Class Initialized
INFO - 2018-05-14 11:50:47 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:47 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:47 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:47 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:47 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:47 --> Model Class Initialized
INFO - 2018-05-14 11:50:47 --> Controller Class Initialized
ERROR - 2018-05-14 11:50:47 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:50:47 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:50:47 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:50:47 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:50:47 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:50:47 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:48 --> Config Class Initialized
INFO - 2018-05-14 11:50:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:48 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:48 --> URI Class Initialized
INFO - 2018-05-14 11:50:48 --> Router Class Initialized
INFO - 2018-05-14 11:50:49 --> Output Class Initialized
INFO - 2018-05-14 11:50:49 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:49 --> Input Class Initialized
INFO - 2018-05-14 11:50:49 --> Language Class Initialized
INFO - 2018-05-14 11:50:49 --> Loader Class Initialized
INFO - 2018-05-14 11:50:49 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:49 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:49 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:49 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:49 --> Config Class Initialized
INFO - 2018-05-14 11:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:49 --> Hooks Class Initialized
INFO - 2018-05-14 11:50:49 --> Form Validation Class Initialized
DEBUG - 2018-05-14 11:50:49 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:49 --> Model Class Initialized
INFO - 2018-05-14 11:50:49 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:49 --> Controller Class Initialized
INFO - 2018-05-14 11:50:49 --> URI Class Initialized
ERROR - 2018-05-14 11:50:49 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:50:49 --> Router Class Initialized
ERROR - 2018-05-14 11:50:49 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 11:50:49 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:50:49 --> Output Class Initialized
INFO - 2018-05-14 11:50:49 --> Config Class Initialized
ERROR - 2018-05-14 11:50:49 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:49 --> Hooks Class Initialized
INFO - 2018-05-14 11:50:49 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:49 --> UTF-8 Support Enabled
ERROR - 2018-05-14 11:50:49 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:50:49 --> Config Class Initialized
DEBUG - 2018-05-14 11:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:49 --> Utf8 Class Initialized
ERROR - 2018-05-14 11:50:49 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:49 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:50:49 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:49 --> Input Class Initialized
INFO - 2018-05-14 11:50:49 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:49 --> URI Class Initialized
INFO - 2018-05-14 11:50:49 --> Language Class Initialized
INFO - 2018-05-14 11:50:49 --> Router Class Initialized
INFO - 2018-05-14 11:50:49 --> URI Class Initialized
INFO - 2018-05-14 11:50:49 --> Loader Class Initialized
INFO - 2018-05-14 11:50:49 --> Router Class Initialized
INFO - 2018-05-14 11:50:49 --> Output Class Initialized
INFO - 2018-05-14 11:50:49 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:49 --> Config Class Initialized
INFO - 2018-05-14 11:50:49 --> Output Class Initialized
INFO - 2018-05-14 11:50:49 --> Security Class Initialized
INFO - 2018-05-14 11:50:49 --> Hooks Class Initialized
INFO - 2018-05-14 11:50:49 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:49 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 11:50:49 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:49 --> Input Class Initialized
INFO - 2018-05-14 11:50:49 --> Helper loaded: date_helper
DEBUG - 2018-05-14 11:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:49 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:49 --> Language Class Initialized
INFO - 2018-05-14 11:50:49 --> Database Driver Class Initialized
INFO - 2018-05-14 11:50:49 --> Input Class Initialized
INFO - 2018-05-14 11:50:49 --> URI Class Initialized
INFO - 2018-05-14 11:50:49 --> Loader Class Initialized
INFO - 2018-05-14 11:50:49 --> Router Class Initialized
DEBUG - 2018-05-14 11:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:49 --> Language Class Initialized
INFO - 2018-05-14 11:50:49 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:49 --> Loader Class Initialized
INFO - 2018-05-14 11:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:49 --> Output Class Initialized
INFO - 2018-05-14 11:50:49 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:50 --> Security Class Initialized
INFO - 2018-05-14 11:50:50 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:50 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:50 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:50 --> Model Class Initialized
DEBUG - 2018-05-14 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:50 --> Database Driver Class Initialized
INFO - 2018-05-14 11:50:50 --> Controller Class Initialized
INFO - 2018-05-14 11:50:50 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:50 --> Input Class Initialized
DEBUG - 2018-05-14 11:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-05-14 11:50:50 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:50:50 --> Database Driver Class Initialized
INFO - 2018-05-14 11:50:50 --> Language Class Initialized
ERROR - 2018-05-14 11:50:50 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
DEBUG - 2018-05-14 11:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:50 --> Loader Class Initialized
ERROR - 2018-05-14 11:50:50 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:50:50 --> Helper loaded: url_helper
ERROR - 2018-05-14 11:50:50 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:50 --> Helper loaded: form_helper
ERROR - 2018-05-14 11:50:50 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 11:50:50 --> Helper loaded: date_helper
ERROR - 2018-05-14 11:50:50 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 11:50:50 --> Database Driver Class Initialized
INFO - 2018-05-14 11:50:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-14 11:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:50 --> Model Class Initialized
INFO - 2018-05-14 11:50:50 --> Controller Class Initialized
INFO - 2018-05-14 11:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:50 --> Model Class Initialized
INFO - 2018-05-14 11:50:50 --> Controller Class Initialized
INFO - 2018-05-14 11:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:50 --> Config Class Initialized
INFO - 2018-05-14 11:50:50 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:50 --> Hooks Class Initialized
INFO - 2018-05-14 11:50:50 --> Model Class Initialized
INFO - 2018-05-14 11:50:50 --> Controller Class Initialized
DEBUG - 2018-05-14 11:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:50:50 --> Utf8 Class Initialized
INFO - 2018-05-14 11:50:50 --> URI Class Initialized
INFO - 2018-05-14 11:50:50 --> Router Class Initialized
INFO - 2018-05-14 11:50:50 --> Output Class Initialized
INFO - 2018-05-14 11:50:50 --> Security Class Initialized
DEBUG - 2018-05-14 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:50:50 --> Input Class Initialized
INFO - 2018-05-14 11:50:50 --> Language Class Initialized
INFO - 2018-05-14 11:50:50 --> Loader Class Initialized
INFO - 2018-05-14 11:50:50 --> Helper loaded: url_helper
INFO - 2018-05-14 11:50:50 --> Helper loaded: form_helper
INFO - 2018-05-14 11:50:50 --> Helper loaded: date_helper
INFO - 2018-05-14 11:50:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:50:51 --> Form Validation Class Initialized
INFO - 2018-05-14 11:50:51 --> Model Class Initialized
INFO - 2018-05-14 11:50:51 --> Controller Class Initialized
INFO - 2018-05-14 11:51:14 --> Config Class Initialized
INFO - 2018-05-14 11:51:15 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:51:15 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:51:15 --> Utf8 Class Initialized
INFO - 2018-05-14 11:51:15 --> URI Class Initialized
INFO - 2018-05-14 11:51:15 --> Router Class Initialized
INFO - 2018-05-14 11:51:15 --> Output Class Initialized
INFO - 2018-05-14 11:51:15 --> Security Class Initialized
DEBUG - 2018-05-14 11:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:51:15 --> Input Class Initialized
INFO - 2018-05-14 11:51:15 --> Language Class Initialized
INFO - 2018-05-14 11:51:15 --> Loader Class Initialized
INFO - 2018-05-14 11:51:15 --> Helper loaded: url_helper
INFO - 2018-05-14 11:51:15 --> Helper loaded: form_helper
INFO - 2018-05-14 11:51:15 --> Helper loaded: date_helper
INFO - 2018-05-14 11:51:15 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:51:15 --> Form Validation Class Initialized
INFO - 2018-05-14 11:51:15 --> Model Class Initialized
INFO - 2018-05-14 11:51:15 --> Controller Class Initialized
INFO - 2018-05-14 11:51:15 --> Config Class Initialized
INFO - 2018-05-14 11:51:15 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:51:15 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:51:15 --> Utf8 Class Initialized
INFO - 2018-05-14 11:51:15 --> URI Class Initialized
INFO - 2018-05-14 11:51:15 --> Router Class Initialized
INFO - 2018-05-14 11:51:15 --> Output Class Initialized
INFO - 2018-05-14 11:51:15 --> Security Class Initialized
DEBUG - 2018-05-14 11:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:51:15 --> Input Class Initialized
INFO - 2018-05-14 11:51:15 --> Language Class Initialized
INFO - 2018-05-14 11:51:15 --> Loader Class Initialized
INFO - 2018-05-14 11:51:15 --> Helper loaded: url_helper
INFO - 2018-05-14 11:51:15 --> Helper loaded: form_helper
INFO - 2018-05-14 11:51:15 --> Helper loaded: date_helper
INFO - 2018-05-14 11:51:15 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:51:16 --> Form Validation Class Initialized
INFO - 2018-05-14 11:51:16 --> Model Class Initialized
INFO - 2018-05-14 11:51:16 --> Controller Class Initialized
INFO - 2018-05-14 11:51:16 --> Model Class Initialized
INFO - 2018-05-14 11:51:16 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 11:51:16 --> Final output sent to browser
DEBUG - 2018-05-14 11:51:16 --> Total execution time: 0.5047
INFO - 2018-05-14 11:51:16 --> Config Class Initialized
INFO - 2018-05-14 11:51:16 --> Hooks Class Initialized
DEBUG - 2018-05-14 11:51:16 --> UTF-8 Support Enabled
INFO - 2018-05-14 11:51:16 --> Utf8 Class Initialized
INFO - 2018-05-14 11:51:16 --> URI Class Initialized
INFO - 2018-05-14 11:51:16 --> Router Class Initialized
INFO - 2018-05-14 11:51:16 --> Output Class Initialized
INFO - 2018-05-14 11:51:16 --> Security Class Initialized
DEBUG - 2018-05-14 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 11:51:16 --> Input Class Initialized
INFO - 2018-05-14 11:51:16 --> Language Class Initialized
INFO - 2018-05-14 11:51:16 --> Loader Class Initialized
INFO - 2018-05-14 11:51:16 --> Helper loaded: url_helper
INFO - 2018-05-14 11:51:16 --> Helper loaded: form_helper
INFO - 2018-05-14 11:51:16 --> Helper loaded: date_helper
INFO - 2018-05-14 11:51:16 --> Database Driver Class Initialized
DEBUG - 2018-05-14 11:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 11:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 11:51:17 --> Form Validation Class Initialized
INFO - 2018-05-14 11:51:17 --> Model Class Initialized
INFO - 2018-05-14 11:51:17 --> Controller Class Initialized
ERROR - 2018-05-14 11:51:17 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 11:51:17 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:05:06 --> Config Class Initialized
INFO - 2018-05-14 12:05:06 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:05:06 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:05:06 --> Utf8 Class Initialized
INFO - 2018-05-14 12:05:06 --> URI Class Initialized
INFO - 2018-05-14 12:05:06 --> Router Class Initialized
INFO - 2018-05-14 12:05:06 --> Output Class Initialized
INFO - 2018-05-14 12:05:06 --> Security Class Initialized
DEBUG - 2018-05-14 12:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:05:06 --> Input Class Initialized
INFO - 2018-05-14 12:05:06 --> Language Class Initialized
INFO - 2018-05-14 12:05:06 --> Loader Class Initialized
INFO - 2018-05-14 12:05:06 --> Helper loaded: url_helper
INFO - 2018-05-14 12:05:06 --> Helper loaded: form_helper
INFO - 2018-05-14 12:05:06 --> Helper loaded: date_helper
INFO - 2018-05-14 12:05:06 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:05:06 --> Form Validation Class Initialized
INFO - 2018-05-14 12:05:06 --> Model Class Initialized
INFO - 2018-05-14 12:05:06 --> Controller Class Initialized
INFO - 2018-05-14 12:05:06 --> Model Class Initialized
INFO - 2018-05-14 12:05:06 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 12:05:06 --> Final output sent to browser
DEBUG - 2018-05-14 12:05:07 --> Total execution time: 0.5443
INFO - 2018-05-14 12:05:07 --> Config Class Initialized
INFO - 2018-05-14 12:05:07 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:05:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:05:07 --> Utf8 Class Initialized
INFO - 2018-05-14 12:05:07 --> URI Class Initialized
INFO - 2018-05-14 12:05:07 --> Router Class Initialized
INFO - 2018-05-14 12:05:07 --> Output Class Initialized
INFO - 2018-05-14 12:05:07 --> Security Class Initialized
DEBUG - 2018-05-14 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:05:07 --> Input Class Initialized
INFO - 2018-05-14 12:05:07 --> Language Class Initialized
INFO - 2018-05-14 12:05:07 --> Loader Class Initialized
INFO - 2018-05-14 12:05:07 --> Helper loaded: url_helper
INFO - 2018-05-14 12:05:07 --> Helper loaded: form_helper
INFO - 2018-05-14 12:05:07 --> Helper loaded: date_helper
INFO - 2018-05-14 12:05:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:05:07 --> Form Validation Class Initialized
INFO - 2018-05-14 12:05:07 --> Model Class Initialized
INFO - 2018-05-14 12:05:08 --> Controller Class Initialized
ERROR - 2018-05-14 12:05:08 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:05:08 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:07:48 --> Config Class Initialized
INFO - 2018-05-14 12:07:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:07:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:07:48 --> Utf8 Class Initialized
INFO - 2018-05-14 12:07:48 --> URI Class Initialized
INFO - 2018-05-14 12:07:48 --> Router Class Initialized
INFO - 2018-05-14 12:07:48 --> Output Class Initialized
INFO - 2018-05-14 12:07:48 --> Security Class Initialized
DEBUG - 2018-05-14 12:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:07:48 --> Input Class Initialized
INFO - 2018-05-14 12:07:48 --> Language Class Initialized
INFO - 2018-05-14 12:07:48 --> Loader Class Initialized
INFO - 2018-05-14 12:07:48 --> Helper loaded: url_helper
INFO - 2018-05-14 12:07:48 --> Helper loaded: form_helper
INFO - 2018-05-14 12:07:48 --> Helper loaded: date_helper
INFO - 2018-05-14 12:07:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:07:48 --> Form Validation Class Initialized
INFO - 2018-05-14 12:07:48 --> Model Class Initialized
INFO - 2018-05-14 12:07:48 --> Controller Class Initialized
INFO - 2018-05-14 12:07:49 --> File loaded: C:\xampp\htdocs\mcms\application\views\full_calendar_example.php
INFO - 2018-05-14 12:07:49 --> Final output sent to browser
DEBUG - 2018-05-14 12:07:49 --> Total execution time: 0.7846
INFO - 2018-05-14 12:07:50 --> Config Class Initialized
INFO - 2018-05-14 12:07:50 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:07:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:07:50 --> Utf8 Class Initialized
INFO - 2018-05-14 12:07:50 --> URI Class Initialized
INFO - 2018-05-14 12:07:50 --> Router Class Initialized
INFO - 2018-05-14 12:07:50 --> Output Class Initialized
INFO - 2018-05-14 12:07:50 --> Security Class Initialized
DEBUG - 2018-05-14 12:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:07:51 --> Input Class Initialized
INFO - 2018-05-14 12:07:51 --> Language Class Initialized
INFO - 2018-05-14 12:07:51 --> Loader Class Initialized
INFO - 2018-05-14 12:07:51 --> Helper loaded: url_helper
INFO - 2018-05-14 12:07:51 --> Helper loaded: form_helper
INFO - 2018-05-14 12:07:51 --> Helper loaded: date_helper
INFO - 2018-05-14 12:07:51 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:07:51 --> Form Validation Class Initialized
INFO - 2018-05-14 12:07:51 --> Model Class Initialized
INFO - 2018-05-14 12:07:51 --> Controller Class Initialized
ERROR - 2018-05-14 12:07:51 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:07:51 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:09:43 --> Config Class Initialized
INFO - 2018-05-14 12:09:43 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:09:43 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:43 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:43 --> URI Class Initialized
INFO - 2018-05-14 12:09:43 --> Router Class Initialized
INFO - 2018-05-14 12:09:43 --> Output Class Initialized
INFO - 2018-05-14 12:09:43 --> Security Class Initialized
DEBUG - 2018-05-14 12:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:43 --> Input Class Initialized
INFO - 2018-05-14 12:09:43 --> Language Class Initialized
INFO - 2018-05-14 12:09:43 --> Loader Class Initialized
INFO - 2018-05-14 12:09:43 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:44 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:44 --> Helper loaded: date_helper
INFO - 2018-05-14 12:09:44 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:44 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:44 --> Model Class Initialized
INFO - 2018-05-14 12:09:44 --> Controller Class Initialized
INFO - 2018-05-14 12:09:44 --> Config Class Initialized
INFO - 2018-05-14 12:09:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:09:44 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:44 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:44 --> URI Class Initialized
INFO - 2018-05-14 12:09:44 --> Router Class Initialized
INFO - 2018-05-14 12:09:44 --> Output Class Initialized
INFO - 2018-05-14 12:09:44 --> Security Class Initialized
DEBUG - 2018-05-14 12:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:44 --> Input Class Initialized
INFO - 2018-05-14 12:09:44 --> Language Class Initialized
INFO - 2018-05-14 12:09:44 --> Loader Class Initialized
INFO - 2018-05-14 12:09:44 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:44 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:44 --> Helper loaded: date_helper
INFO - 2018-05-14 12:09:44 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:44 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:44 --> Model Class Initialized
INFO - 2018-05-14 12:09:44 --> Controller Class Initialized
INFO - 2018-05-14 12:09:45 --> Config Class Initialized
INFO - 2018-05-14 12:09:45 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:09:45 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:45 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:45 --> URI Class Initialized
INFO - 2018-05-14 12:09:45 --> Router Class Initialized
INFO - 2018-05-14 12:09:45 --> Output Class Initialized
INFO - 2018-05-14 12:09:45 --> Security Class Initialized
DEBUG - 2018-05-14 12:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:45 --> Input Class Initialized
INFO - 2018-05-14 12:09:45 --> Language Class Initialized
INFO - 2018-05-14 12:09:45 --> Loader Class Initialized
INFO - 2018-05-14 12:09:45 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:45 --> Config Class Initialized
INFO - 2018-05-14 12:09:45 --> Hooks Class Initialized
INFO - 2018-05-14 12:09:46 --> Helper loaded: form_helper
DEBUG - 2018-05-14 12:09:46 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:46 --> Helper loaded: date_helper
INFO - 2018-05-14 12:09:46 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:46 --> URI Class Initialized
INFO - 2018-05-14 12:09:46 --> Database Driver Class Initialized
INFO - 2018-05-14 12:09:46 --> Router Class Initialized
DEBUG - 2018-05-14 12:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:46 --> Output Class Initialized
INFO - 2018-05-14 12:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:46 --> Security Class Initialized
INFO - 2018-05-14 12:09:46 --> Form Validation Class Initialized
DEBUG - 2018-05-14 12:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:46 --> Model Class Initialized
INFO - 2018-05-14 12:09:46 --> Input Class Initialized
INFO - 2018-05-14 12:09:46 --> Controller Class Initialized
INFO - 2018-05-14 12:09:46 --> Language Class Initialized
INFO - 2018-05-14 12:09:46 --> Loader Class Initialized
INFO - 2018-05-14 12:09:46 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:46 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:46 --> Helper loaded: date_helper
INFO - 2018-05-14 12:09:46 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:46 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:46 --> Model Class Initialized
INFO - 2018-05-14 12:09:46 --> Controller Class Initialized
ERROR - 2018-05-14 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:09:47 --> Config Class Initialized
INFO - 2018-05-14 12:09:47 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:09:47 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:47 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:47 --> URI Class Initialized
INFO - 2018-05-14 12:09:47 --> Router Class Initialized
INFO - 2018-05-14 12:09:47 --> Output Class Initialized
INFO - 2018-05-14 12:09:47 --> Security Class Initialized
DEBUG - 2018-05-14 12:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:47 --> Input Class Initialized
INFO - 2018-05-14 12:09:47 --> Language Class Initialized
INFO - 2018-05-14 12:09:47 --> Loader Class Initialized
INFO - 2018-05-14 12:09:47 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:47 --> Config Class Initialized
INFO - 2018-05-14 12:09:47 --> Hooks Class Initialized
INFO - 2018-05-14 12:09:47 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:47 --> Helper loaded: date_helper
DEBUG - 2018-05-14 12:09:47 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:47 --> Database Driver Class Initialized
INFO - 2018-05-14 12:09:47 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:47 --> URI Class Initialized
DEBUG - 2018-05-14 12:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:47 --> Router Class Initialized
INFO - 2018-05-14 12:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:47 --> Output Class Initialized
INFO - 2018-05-14 12:09:47 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:47 --> Security Class Initialized
INFO - 2018-05-14 12:09:47 --> Model Class Initialized
DEBUG - 2018-05-14 12:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:47 --> Controller Class Initialized
INFO - 2018-05-14 12:09:47 --> Config Class Initialized
INFO - 2018-05-14 12:09:47 --> Input Class Initialized
INFO - 2018-05-14 12:09:47 --> Hooks Class Initialized
INFO - 2018-05-14 12:09:47 --> Language Class Initialized
ERROR - 2018-05-14 12:09:47 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
DEBUG - 2018-05-14 12:09:47 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:47 --> Loader Class Initialized
INFO - 2018-05-14 12:09:47 --> Utf8 Class Initialized
ERROR - 2018-05-14 12:09:47 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 12:09:47 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 12:09:47 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:47 --> URI Class Initialized
ERROR - 2018-05-14 12:09:48 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:09:48 --> Router Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: form_helper
ERROR - 2018-05-14 12:09:48 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
INFO - 2018-05-14 12:09:48 --> Output Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: date_helper
ERROR - 2018-05-14 12:09:48 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:09:48 --> Security Class Initialized
INFO - 2018-05-14 12:09:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 12:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:48 --> Input Class Initialized
INFO - 2018-05-14 12:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:48 --> Language Class Initialized
INFO - 2018-05-14 12:09:48 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:48 --> Loader Class Initialized
INFO - 2018-05-14 12:09:48 --> Model Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:48 --> Controller Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:48 --> Helper loaded: date_helper
INFO - 2018-05-14 12:09:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:48 --> Config Class Initialized
INFO - 2018-05-14 12:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:48 --> Hooks Class Initialized
INFO - 2018-05-14 12:09:48 --> Form Validation Class Initialized
DEBUG - 2018-05-14 12:09:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:48 --> Model Class Initialized
INFO - 2018-05-14 12:09:48 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:48 --> Controller Class Initialized
INFO - 2018-05-14 12:09:48 --> URI Class Initialized
INFO - 2018-05-14 12:09:48 --> Router Class Initialized
INFO - 2018-05-14 12:09:48 --> Output Class Initialized
INFO - 2018-05-14 12:09:48 --> Security Class Initialized
INFO - 2018-05-14 12:09:48 --> Config Class Initialized
DEBUG - 2018-05-14 12:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:48 --> Hooks Class Initialized
INFO - 2018-05-14 12:09:48 --> Input Class Initialized
DEBUG - 2018-05-14 12:09:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:09:48 --> Utf8 Class Initialized
INFO - 2018-05-14 12:09:48 --> Language Class Initialized
INFO - 2018-05-14 12:09:48 --> URI Class Initialized
INFO - 2018-05-14 12:09:48 --> Loader Class Initialized
INFO - 2018-05-14 12:09:48 --> Router Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:48 --> Output Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:48 --> Security Class Initialized
INFO - 2018-05-14 12:09:48 --> Helper loaded: date_helper
DEBUG - 2018-05-14 12:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:09:49 --> Database Driver Class Initialized
INFO - 2018-05-14 12:09:49 --> Input Class Initialized
DEBUG - 2018-05-14 12:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:49 --> Language Class Initialized
INFO - 2018-05-14 12:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:49 --> Loader Class Initialized
INFO - 2018-05-14 12:09:49 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:49 --> Helper loaded: url_helper
INFO - 2018-05-14 12:09:49 --> Model Class Initialized
INFO - 2018-05-14 12:09:49 --> Controller Class Initialized
INFO - 2018-05-14 12:09:49 --> Helper loaded: form_helper
INFO - 2018-05-14 12:09:49 --> Helper loaded: date_helper
INFO - 2018-05-14 12:09:49 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:09:49 --> Form Validation Class Initialized
INFO - 2018-05-14 12:09:49 --> Model Class Initialized
INFO - 2018-05-14 12:09:49 --> Controller Class Initialized
ERROR - 2018-05-14 12:09:49 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:09:49 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 12:09:49 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:09:49 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
ERROR - 2018-05-14 12:09:49 --> Severity: Notice --> Undefined property: stdClass::$patient_ID C:\xampp\htdocs\mcms\application\controllers\Main.php 287
ERROR - 2018-05-14 12:09:49 --> Severity: Notice --> Undefined property: stdClass::$contact_number C:\xampp\htdocs\mcms\application\controllers\Main.php 288
INFO - 2018-05-14 12:12:27 --> Config Class Initialized
INFO - 2018-05-14 12:12:27 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:12:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:12:27 --> Utf8 Class Initialized
INFO - 2018-05-14 12:12:27 --> URI Class Initialized
INFO - 2018-05-14 12:12:27 --> Router Class Initialized
INFO - 2018-05-14 12:12:27 --> Output Class Initialized
INFO - 2018-05-14 12:12:27 --> Security Class Initialized
DEBUG - 2018-05-14 12:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:12:28 --> Input Class Initialized
INFO - 2018-05-14 12:12:28 --> Language Class Initialized
INFO - 2018-05-14 12:12:28 --> Loader Class Initialized
INFO - 2018-05-14 12:12:28 --> Helper loaded: url_helper
INFO - 2018-05-14 12:12:28 --> Helper loaded: form_helper
INFO - 2018-05-14 12:12:28 --> Helper loaded: date_helper
INFO - 2018-05-14 12:12:28 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:12:28 --> Form Validation Class Initialized
INFO - 2018-05-14 12:12:28 --> Model Class Initialized
INFO - 2018-05-14 12:12:28 --> Controller Class Initialized
ERROR - 2018-05-14 12:12:28 --> Severity: Warning --> Missing argument 1 for Main_model::get_events(), called in C:\xampp\htdocs\mcms\application\controllers\Main.php on line 447 and defined C:\xampp\htdocs\mcms\application\models\Main_model.php 143
ERROR - 2018-05-14 12:12:28 --> Severity: Warning --> Missing argument 2 for Main_model::get_events(), called in C:\xampp\htdocs\mcms\application\controllers\Main.php on line 447 and defined C:\xampp\htdocs\mcms\application\models\Main_model.php 143
ERROR - 2018-05-14 12:12:28 --> Severity: Notice --> Undefined variable: start C:\xampp\htdocs\mcms\application\models\Main_model.php 145
ERROR - 2018-05-14 12:12:28 --> Severity: Notice --> Undefined variable: end C:\xampp\htdocs\mcms\application\models\Main_model.php 145
ERROR - 2018-05-14 12:12:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `end` < `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `calendar_events`
WHERE `start` > `IS` `NULL`
AND `end` < `IS` `NULL`
INFO - 2018-05-14 12:12:28 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-14 12:12:46 --> Config Class Initialized
INFO - 2018-05-14 12:12:46 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:12:46 --> Utf8 Class Initialized
INFO - 2018-05-14 12:12:46 --> URI Class Initialized
INFO - 2018-05-14 12:12:46 --> Router Class Initialized
INFO - 2018-05-14 12:12:46 --> Output Class Initialized
INFO - 2018-05-14 12:12:46 --> Security Class Initialized
DEBUG - 2018-05-14 12:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:12:46 --> Input Class Initialized
INFO - 2018-05-14 12:12:46 --> Language Class Initialized
INFO - 2018-05-14 12:12:46 --> Loader Class Initialized
INFO - 2018-05-14 12:12:46 --> Helper loaded: url_helper
INFO - 2018-05-14 12:12:46 --> Helper loaded: form_helper
INFO - 2018-05-14 12:12:46 --> Helper loaded: date_helper
INFO - 2018-05-14 12:12:46 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:12:46 --> Form Validation Class Initialized
INFO - 2018-05-14 12:12:46 --> Model Class Initialized
INFO - 2018-05-14 12:12:46 --> Controller Class Initialized
ERROR - 2018-05-14 12:12:46 --> Severity: Notice --> Undefined variable: start_format C:\xampp\htdocs\mcms\application\controllers\Main.php 447
ERROR - 2018-05-14 12:12:46 --> Severity: Notice --> Undefined variable: end_format C:\xampp\htdocs\mcms\application\controllers\Main.php 447
ERROR - 2018-05-14 12:12:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `end` < `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `calendar_events`
WHERE `start` > `IS` `NULL`
AND `end` < `IS` `NULL`
INFO - 2018-05-14 12:12:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-14 12:16:41 --> Config Class Initialized
INFO - 2018-05-14 12:16:41 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:16:41 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:16:41 --> Utf8 Class Initialized
INFO - 2018-05-14 12:16:41 --> URI Class Initialized
INFO - 2018-05-14 12:16:41 --> Router Class Initialized
INFO - 2018-05-14 12:16:41 --> Output Class Initialized
INFO - 2018-05-14 12:16:41 --> Security Class Initialized
DEBUG - 2018-05-14 12:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:16:41 --> Input Class Initialized
INFO - 2018-05-14 12:16:41 --> Language Class Initialized
INFO - 2018-05-14 12:16:41 --> Loader Class Initialized
INFO - 2018-05-14 12:16:41 --> Helper loaded: url_helper
INFO - 2018-05-14 12:16:41 --> Helper loaded: form_helper
INFO - 2018-05-14 12:16:41 --> Helper loaded: date_helper
INFO - 2018-05-14 12:16:41 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:16:41 --> Form Validation Class Initialized
INFO - 2018-05-14 12:16:41 --> Model Class Initialized
INFO - 2018-05-14 12:16:41 --> Controller Class Initialized
ERROR - 2018-05-14 12:16:41 --> Severity: Notice --> Undefined variable: start C:\xampp\htdocs\mcms\application\controllers\Main.php 448
ERROR - 2018-05-14 12:16:41 --> Severity: Notice --> Undefined variable: end C:\xampp\htdocs\mcms\application\controllers\Main.php 452
INFO - 2018-05-14 12:16:42 --> Final output sent to browser
DEBUG - 2018-05-14 12:16:42 --> Total execution time: 0.6473
INFO - 2018-05-14 12:17:38 --> Config Class Initialized
INFO - 2018-05-14 12:17:38 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:17:38 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:17:38 --> Utf8 Class Initialized
INFO - 2018-05-14 12:17:38 --> URI Class Initialized
INFO - 2018-05-14 12:17:38 --> Router Class Initialized
INFO - 2018-05-14 12:17:38 --> Output Class Initialized
INFO - 2018-05-14 12:17:38 --> Security Class Initialized
DEBUG - 2018-05-14 12:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:17:38 --> Input Class Initialized
INFO - 2018-05-14 12:17:38 --> Language Class Initialized
INFO - 2018-05-14 12:17:38 --> Loader Class Initialized
INFO - 2018-05-14 12:17:38 --> Helper loaded: url_helper
INFO - 2018-05-14 12:17:38 --> Helper loaded: form_helper
INFO - 2018-05-14 12:17:38 --> Helper loaded: date_helper
INFO - 2018-05-14 12:17:38 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:17:39 --> Form Validation Class Initialized
INFO - 2018-05-14 12:17:39 --> Model Class Initialized
INFO - 2018-05-14 12:17:39 --> Controller Class Initialized
ERROR - 2018-05-14 12:17:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\mcms\application\controllers\Main.php 450
ERROR - 2018-05-14 12:17:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\mcms\application\controllers\Main.php 454
INFO - 2018-05-14 12:17:39 --> Final output sent to browser
DEBUG - 2018-05-14 12:17:39 --> Total execution time: 0.5289
INFO - 2018-05-14 12:18:55 --> Config Class Initialized
INFO - 2018-05-14 12:18:55 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:18:55 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:18:55 --> Utf8 Class Initialized
INFO - 2018-05-14 12:18:55 --> URI Class Initialized
INFO - 2018-05-14 12:18:55 --> Router Class Initialized
INFO - 2018-05-14 12:18:55 --> Output Class Initialized
INFO - 2018-05-14 12:18:55 --> Security Class Initialized
DEBUG - 2018-05-14 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:18:55 --> Input Class Initialized
INFO - 2018-05-14 12:18:56 --> Language Class Initialized
INFO - 2018-05-14 12:18:56 --> Loader Class Initialized
INFO - 2018-05-14 12:18:56 --> Helper loaded: url_helper
INFO - 2018-05-14 12:18:56 --> Helper loaded: form_helper
INFO - 2018-05-14 12:18:56 --> Helper loaded: date_helper
INFO - 2018-05-14 12:18:56 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:18:56 --> Form Validation Class Initialized
INFO - 2018-05-14 12:18:56 --> Model Class Initialized
INFO - 2018-05-14 12:18:56 --> Controller Class Initialized
ERROR - 2018-05-14 12:18:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\mcms\application\controllers\Main.php 450
ERROR - 2018-05-14 12:18:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\mcms\application\controllers\Main.php 454
INFO - 2018-05-14 12:18:56 --> Final output sent to browser
DEBUG - 2018-05-14 12:18:56 --> Total execution time: 0.5010
INFO - 2018-05-14 12:24:14 --> Config Class Initialized
INFO - 2018-05-14 12:24:14 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:24:14 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:24:14 --> Utf8 Class Initialized
INFO - 2018-05-14 12:24:14 --> URI Class Initialized
INFO - 2018-05-14 12:24:14 --> Router Class Initialized
INFO - 2018-05-14 12:24:14 --> Output Class Initialized
INFO - 2018-05-14 12:24:14 --> Security Class Initialized
DEBUG - 2018-05-14 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:24:14 --> Input Class Initialized
INFO - 2018-05-14 12:24:14 --> Language Class Initialized
INFO - 2018-05-14 12:24:14 --> Loader Class Initialized
INFO - 2018-05-14 12:24:14 --> Helper loaded: url_helper
INFO - 2018-05-14 12:24:14 --> Helper loaded: form_helper
INFO - 2018-05-14 12:24:14 --> Helper loaded: date_helper
INFO - 2018-05-14 12:24:14 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:24:14 --> Form Validation Class Initialized
INFO - 2018-05-14 12:24:14 --> Model Class Initialized
INFO - 2018-05-14 12:24:14 --> Controller Class Initialized
INFO - 2018-05-14 12:24:14 --> Final output sent to browser
DEBUG - 2018-05-14 12:24:14 --> Total execution time: 0.5671
INFO - 2018-05-14 12:26:07 --> Config Class Initialized
INFO - 2018-05-14 12:26:07 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:26:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:26:07 --> Utf8 Class Initialized
INFO - 2018-05-14 12:26:07 --> URI Class Initialized
INFO - 2018-05-14 12:26:07 --> Router Class Initialized
INFO - 2018-05-14 12:26:07 --> Output Class Initialized
INFO - 2018-05-14 12:26:07 --> Security Class Initialized
DEBUG - 2018-05-14 12:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:26:07 --> Input Class Initialized
INFO - 2018-05-14 12:26:07 --> Language Class Initialized
INFO - 2018-05-14 12:26:07 --> Loader Class Initialized
INFO - 2018-05-14 12:26:07 --> Helper loaded: url_helper
INFO - 2018-05-14 12:26:07 --> Helper loaded: form_helper
INFO - 2018-05-14 12:26:07 --> Helper loaded: date_helper
INFO - 2018-05-14 12:26:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:26:07 --> Form Validation Class Initialized
INFO - 2018-05-14 12:26:07 --> Model Class Initialized
INFO - 2018-05-14 12:26:07 --> Controller Class Initialized
INFO - 2018-05-14 12:26:07 --> Final output sent to browser
DEBUG - 2018-05-14 12:26:07 --> Total execution time: 0.6229
INFO - 2018-05-14 12:28:30 --> Config Class Initialized
INFO - 2018-05-14 12:28:30 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:28:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:28:30 --> Utf8 Class Initialized
INFO - 2018-05-14 12:28:30 --> URI Class Initialized
INFO - 2018-05-14 12:28:30 --> Router Class Initialized
INFO - 2018-05-14 12:28:30 --> Output Class Initialized
INFO - 2018-05-14 12:28:30 --> Security Class Initialized
DEBUG - 2018-05-14 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:28:30 --> Input Class Initialized
INFO - 2018-05-14 12:28:30 --> Language Class Initialized
INFO - 2018-05-14 12:28:31 --> Loader Class Initialized
INFO - 2018-05-14 12:28:31 --> Helper loaded: url_helper
INFO - 2018-05-14 12:28:31 --> Helper loaded: form_helper
INFO - 2018-05-14 12:28:31 --> Helper loaded: date_helper
INFO - 2018-05-14 12:28:31 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:28:31 --> Form Validation Class Initialized
INFO - 2018-05-14 12:28:31 --> Model Class Initialized
INFO - 2018-05-14 12:28:31 --> Controller Class Initialized
INFO - 2018-05-14 12:28:31 --> Final output sent to browser
DEBUG - 2018-05-14 12:28:31 --> Total execution time: 0.5652
INFO - 2018-05-14 12:28:32 --> Config Class Initialized
INFO - 2018-05-14 12:28:32 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:28:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:28:32 --> Utf8 Class Initialized
INFO - 2018-05-14 12:28:32 --> URI Class Initialized
INFO - 2018-05-14 12:28:32 --> Router Class Initialized
INFO - 2018-05-14 12:28:32 --> Output Class Initialized
INFO - 2018-05-14 12:28:32 --> Security Class Initialized
DEBUG - 2018-05-14 12:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:28:32 --> Input Class Initialized
INFO - 2018-05-14 12:28:32 --> Language Class Initialized
INFO - 2018-05-14 12:28:32 --> Loader Class Initialized
INFO - 2018-05-14 12:28:32 --> Helper loaded: url_helper
INFO - 2018-05-14 12:28:32 --> Helper loaded: form_helper
INFO - 2018-05-14 12:28:32 --> Helper loaded: date_helper
INFO - 2018-05-14 12:28:32 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:28:33 --> Form Validation Class Initialized
INFO - 2018-05-14 12:28:33 --> Model Class Initialized
INFO - 2018-05-14 12:28:33 --> Controller Class Initialized
INFO - 2018-05-14 12:28:33 --> File loaded: C:\xampp\htdocs\mcms\application\views\full_calendar_example.php
INFO - 2018-05-14 12:28:33 --> Final output sent to browser
DEBUG - 2018-05-14 12:28:33 --> Total execution time: 0.5103
INFO - 2018-05-14 12:28:33 --> Config Class Initialized
INFO - 2018-05-14 12:28:33 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:28:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:28:33 --> Utf8 Class Initialized
INFO - 2018-05-14 12:28:33 --> URI Class Initialized
INFO - 2018-05-14 12:28:33 --> Router Class Initialized
INFO - 2018-05-14 12:28:33 --> Output Class Initialized
INFO - 2018-05-14 12:28:33 --> Security Class Initialized
DEBUG - 2018-05-14 12:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:28:33 --> Input Class Initialized
INFO - 2018-05-14 12:28:33 --> Language Class Initialized
INFO - 2018-05-14 12:28:33 --> Loader Class Initialized
INFO - 2018-05-14 12:28:33 --> Helper loaded: url_helper
INFO - 2018-05-14 12:28:33 --> Helper loaded: form_helper
INFO - 2018-05-14 12:28:33 --> Helper loaded: date_helper
INFO - 2018-05-14 12:28:33 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:28:34 --> Form Validation Class Initialized
INFO - 2018-05-14 12:28:34 --> Model Class Initialized
INFO - 2018-05-14 12:28:34 --> Controller Class Initialized
INFO - 2018-05-14 12:37:09 --> Config Class Initialized
INFO - 2018-05-14 12:37:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:37:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:37:09 --> Utf8 Class Initialized
INFO - 2018-05-14 12:37:09 --> URI Class Initialized
INFO - 2018-05-14 12:37:09 --> Router Class Initialized
INFO - 2018-05-14 12:37:09 --> Output Class Initialized
INFO - 2018-05-14 12:37:09 --> Security Class Initialized
DEBUG - 2018-05-14 12:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:37:09 --> Input Class Initialized
INFO - 2018-05-14 12:37:09 --> Language Class Initialized
INFO - 2018-05-14 12:37:09 --> Loader Class Initialized
INFO - 2018-05-14 12:37:09 --> Helper loaded: url_helper
INFO - 2018-05-14 12:37:09 --> Helper loaded: form_helper
INFO - 2018-05-14 12:37:09 --> Helper loaded: date_helper
INFO - 2018-05-14 12:37:09 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:37:09 --> Form Validation Class Initialized
INFO - 2018-05-14 12:37:09 --> Model Class Initialized
INFO - 2018-05-14 12:37:09 --> Controller Class Initialized
INFO - 2018-05-14 12:37:09 --> Model Class Initialized
INFO - 2018-05-14 12:37:09 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 12:37:09 --> Final output sent to browser
DEBUG - 2018-05-14 12:37:09 --> Total execution time: 0.7101
INFO - 2018-05-14 12:37:10 --> Config Class Initialized
INFO - 2018-05-14 12:37:10 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:37:10 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:37:10 --> Utf8 Class Initialized
INFO - 2018-05-14 12:37:10 --> URI Class Initialized
INFO - 2018-05-14 12:37:10 --> Router Class Initialized
INFO - 2018-05-14 12:37:10 --> Output Class Initialized
INFO - 2018-05-14 12:37:10 --> Security Class Initialized
DEBUG - 2018-05-14 12:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:37:10 --> Input Class Initialized
INFO - 2018-05-14 12:37:10 --> Language Class Initialized
INFO - 2018-05-14 12:37:10 --> Loader Class Initialized
INFO - 2018-05-14 12:37:10 --> Helper loaded: url_helper
INFO - 2018-05-14 12:37:10 --> Helper loaded: form_helper
INFO - 2018-05-14 12:37:10 --> Helper loaded: date_helper
INFO - 2018-05-14 12:37:10 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:37:10 --> Form Validation Class Initialized
INFO - 2018-05-14 12:37:10 --> Model Class Initialized
INFO - 2018-05-14 12:37:10 --> Controller Class Initialized
INFO - 2018-05-14 12:39:51 --> Config Class Initialized
INFO - 2018-05-14 12:39:51 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:39:51 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:39:51 --> Utf8 Class Initialized
INFO - 2018-05-14 12:39:51 --> URI Class Initialized
INFO - 2018-05-14 12:39:51 --> Router Class Initialized
INFO - 2018-05-14 12:39:51 --> Output Class Initialized
INFO - 2018-05-14 12:39:51 --> Security Class Initialized
DEBUG - 2018-05-14 12:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:39:51 --> Input Class Initialized
INFO - 2018-05-14 12:39:51 --> Language Class Initialized
INFO - 2018-05-14 12:39:51 --> Loader Class Initialized
INFO - 2018-05-14 12:39:51 --> Helper loaded: url_helper
INFO - 2018-05-14 12:39:51 --> Helper loaded: form_helper
INFO - 2018-05-14 12:39:51 --> Helper loaded: date_helper
INFO - 2018-05-14 12:39:51 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:39:51 --> Form Validation Class Initialized
INFO - 2018-05-14 12:39:51 --> Model Class Initialized
INFO - 2018-05-14 12:39:52 --> Controller Class Initialized
INFO - 2018-05-14 12:39:52 --> File loaded: C:\xampp\htdocs\mcms\application\views\full_calendar_example.php
INFO - 2018-05-14 12:39:52 --> Final output sent to browser
DEBUG - 2018-05-14 12:39:52 --> Total execution time: 0.7237
INFO - 2018-05-14 12:39:52 --> Config Class Initialized
INFO - 2018-05-14 12:39:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:39:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:39:52 --> Utf8 Class Initialized
INFO - 2018-05-14 12:39:52 --> URI Class Initialized
INFO - 2018-05-14 12:39:52 --> Router Class Initialized
INFO - 2018-05-14 12:39:52 --> Output Class Initialized
INFO - 2018-05-14 12:39:52 --> Security Class Initialized
DEBUG - 2018-05-14 12:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:39:52 --> Input Class Initialized
INFO - 2018-05-14 12:39:52 --> Language Class Initialized
INFO - 2018-05-14 12:39:52 --> Loader Class Initialized
INFO - 2018-05-14 12:39:52 --> Helper loaded: url_helper
INFO - 2018-05-14 12:39:52 --> Helper loaded: form_helper
INFO - 2018-05-14 12:39:52 --> Helper loaded: date_helper
INFO - 2018-05-14 12:39:53 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:39:53 --> Form Validation Class Initialized
INFO - 2018-05-14 12:39:53 --> Model Class Initialized
INFO - 2018-05-14 12:39:53 --> Controller Class Initialized
INFO - 2018-05-14 12:47:26 --> Config Class Initialized
INFO - 2018-05-14 12:47:26 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:27 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:27 --> URI Class Initialized
INFO - 2018-05-14 12:47:27 --> Router Class Initialized
INFO - 2018-05-14 12:47:27 --> Output Class Initialized
INFO - 2018-05-14 12:47:27 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:27 --> Input Class Initialized
INFO - 2018-05-14 12:47:27 --> Language Class Initialized
INFO - 2018-05-14 12:47:27 --> Loader Class Initialized
INFO - 2018-05-14 12:47:27 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:27 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:27 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:27 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:27 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:27 --> Model Class Initialized
INFO - 2018-05-14 12:47:27 --> Controller Class Initialized
INFO - 2018-05-14 12:47:27 --> Config Class Initialized
INFO - 2018-05-14 12:47:27 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:27 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:27 --> URI Class Initialized
INFO - 2018-05-14 12:47:27 --> Router Class Initialized
INFO - 2018-05-14 12:47:27 --> Output Class Initialized
INFO - 2018-05-14 12:47:27 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:27 --> Input Class Initialized
INFO - 2018-05-14 12:47:27 --> Language Class Initialized
INFO - 2018-05-14 12:47:27 --> Loader Class Initialized
INFO - 2018-05-14 12:47:27 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:27 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:27 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:27 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:28 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:28 --> Model Class Initialized
INFO - 2018-05-14 12:47:28 --> Controller Class Initialized
INFO - 2018-05-14 12:47:28 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 12:47:28 --> Final output sent to browser
DEBUG - 2018-05-14 12:47:28 --> Total execution time: 0.5433
INFO - 2018-05-14 12:47:29 --> Config Class Initialized
INFO - 2018-05-14 12:47:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:29 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:29 --> URI Class Initialized
INFO - 2018-05-14 12:47:29 --> Router Class Initialized
INFO - 2018-05-14 12:47:29 --> Output Class Initialized
INFO - 2018-05-14 12:47:29 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:29 --> Input Class Initialized
INFO - 2018-05-14 12:47:29 --> Language Class Initialized
INFO - 2018-05-14 12:47:29 --> Loader Class Initialized
INFO - 2018-05-14 12:47:29 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:29 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:29 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:29 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:29 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:29 --> Model Class Initialized
INFO - 2018-05-14 12:47:30 --> Controller Class Initialized
INFO - 2018-05-14 12:47:30 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 12:47:30 --> Final output sent to browser
DEBUG - 2018-05-14 12:47:30 --> Total execution time: 0.5588
INFO - 2018-05-14 12:47:30 --> Config Class Initialized
INFO - 2018-05-14 12:47:31 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:31 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:31 --> URI Class Initialized
INFO - 2018-05-14 12:47:31 --> Router Class Initialized
INFO - 2018-05-14 12:47:31 --> Output Class Initialized
INFO - 2018-05-14 12:47:31 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:31 --> Input Class Initialized
INFO - 2018-05-14 12:47:31 --> Language Class Initialized
INFO - 2018-05-14 12:47:31 --> Loader Class Initialized
INFO - 2018-05-14 12:47:31 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:31 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:31 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:31 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:31 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:31 --> Model Class Initialized
INFO - 2018-05-14 12:47:31 --> Controller Class Initialized
INFO - 2018-05-14 12:47:31 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 12:47:31 --> Final output sent to browser
DEBUG - 2018-05-14 12:47:31 --> Total execution time: 0.7144
INFO - 2018-05-14 12:47:35 --> Config Class Initialized
INFO - 2018-05-14 12:47:35 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:35 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:35 --> URI Class Initialized
INFO - 2018-05-14 12:47:35 --> Router Class Initialized
INFO - 2018-05-14 12:47:35 --> Output Class Initialized
INFO - 2018-05-14 12:47:35 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:35 --> Input Class Initialized
INFO - 2018-05-14 12:47:35 --> Language Class Initialized
INFO - 2018-05-14 12:47:35 --> Loader Class Initialized
INFO - 2018-05-14 12:47:35 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:35 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:35 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:35 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:35 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:35 --> Model Class Initialized
INFO - 2018-05-14 12:47:35 --> Controller Class Initialized
INFO - 2018-05-14 12:47:35 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 12:47:35 --> Final output sent to browser
DEBUG - 2018-05-14 12:47:35 --> Total execution time: 0.5976
INFO - 2018-05-14 12:47:39 --> Config Class Initialized
INFO - 2018-05-14 12:47:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:39 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:39 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:39 --> URI Class Initialized
INFO - 2018-05-14 12:47:39 --> Router Class Initialized
INFO - 2018-05-14 12:47:40 --> Output Class Initialized
INFO - 2018-05-14 12:47:40 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:40 --> Input Class Initialized
INFO - 2018-05-14 12:47:40 --> Language Class Initialized
INFO - 2018-05-14 12:47:40 --> Loader Class Initialized
INFO - 2018-05-14 12:47:40 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:40 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:40 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:40 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:40 --> Model Class Initialized
INFO - 2018-05-14 12:47:40 --> Controller Class Initialized
INFO - 2018-05-14 12:47:40 --> Config Class Initialized
INFO - 2018-05-14 12:47:40 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:40 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:40 --> URI Class Initialized
INFO - 2018-05-14 12:47:40 --> Router Class Initialized
INFO - 2018-05-14 12:47:40 --> Output Class Initialized
INFO - 2018-05-14 12:47:40 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:40 --> Input Class Initialized
INFO - 2018-05-14 12:47:40 --> Language Class Initialized
INFO - 2018-05-14 12:47:40 --> Loader Class Initialized
INFO - 2018-05-14 12:47:40 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:40 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:40 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:40 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:40 --> Model Class Initialized
INFO - 2018-05-14 12:47:40 --> Controller Class Initialized
INFO - 2018-05-14 12:47:40 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 12:47:40 --> Final output sent to browser
DEBUG - 2018-05-14 12:47:41 --> Total execution time: 0.5254
INFO - 2018-05-14 12:47:41 --> Config Class Initialized
INFO - 2018-05-14 12:47:41 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:41 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:41 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:41 --> URI Class Initialized
INFO - 2018-05-14 12:47:41 --> Router Class Initialized
INFO - 2018-05-14 12:47:41 --> Output Class Initialized
INFO - 2018-05-14 12:47:41 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:41 --> Input Class Initialized
INFO - 2018-05-14 12:47:41 --> Language Class Initialized
ERROR - 2018-05-14 12:47:41 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 12:47:43 --> Config Class Initialized
INFO - 2018-05-14 12:47:43 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:43 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:43 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:43 --> URI Class Initialized
INFO - 2018-05-14 12:47:43 --> Router Class Initialized
INFO - 2018-05-14 12:47:43 --> Output Class Initialized
INFO - 2018-05-14 12:47:44 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:44 --> Input Class Initialized
INFO - 2018-05-14 12:47:44 --> Language Class Initialized
INFO - 2018-05-14 12:47:44 --> Loader Class Initialized
INFO - 2018-05-14 12:47:44 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:44 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:44 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:44 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:44 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:44 --> Model Class Initialized
INFO - 2018-05-14 12:47:44 --> Controller Class Initialized
INFO - 2018-05-14 12:47:44 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 12:47:44 --> Final output sent to browser
INFO - 2018-05-14 12:47:44 --> Config Class Initialized
DEBUG - 2018-05-14 12:47:44 --> Total execution time: 0.5396
INFO - 2018-05-14 12:47:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:44 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:44 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:44 --> URI Class Initialized
INFO - 2018-05-14 12:47:44 --> Router Class Initialized
INFO - 2018-05-14 12:47:44 --> Output Class Initialized
INFO - 2018-05-14 12:47:44 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:44 --> Input Class Initialized
INFO - 2018-05-14 12:47:44 --> Language Class Initialized
ERROR - 2018-05-14 12:47:44 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 12:47:44 --> Config Class Initialized
INFO - 2018-05-14 12:47:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:47:45 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:47:45 --> Utf8 Class Initialized
INFO - 2018-05-14 12:47:45 --> URI Class Initialized
INFO - 2018-05-14 12:47:45 --> Router Class Initialized
INFO - 2018-05-14 12:47:45 --> Output Class Initialized
INFO - 2018-05-14 12:47:45 --> Security Class Initialized
DEBUG - 2018-05-14 12:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:47:45 --> Input Class Initialized
INFO - 2018-05-14 12:47:45 --> Language Class Initialized
INFO - 2018-05-14 12:47:45 --> Loader Class Initialized
INFO - 2018-05-14 12:47:45 --> Helper loaded: url_helper
INFO - 2018-05-14 12:47:45 --> Helper loaded: form_helper
INFO - 2018-05-14 12:47:45 --> Helper loaded: date_helper
INFO - 2018-05-14 12:47:45 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:47:45 --> Form Validation Class Initialized
INFO - 2018-05-14 12:47:45 --> Model Class Initialized
INFO - 2018-05-14 12:47:45 --> Controller Class Initialized
INFO - 2018-05-14 12:48:10 --> Config Class Initialized
INFO - 2018-05-14 12:48:10 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:48:10 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:48:10 --> Utf8 Class Initialized
INFO - 2018-05-14 12:48:10 --> URI Class Initialized
INFO - 2018-05-14 12:48:10 --> Router Class Initialized
INFO - 2018-05-14 12:48:11 --> Output Class Initialized
INFO - 2018-05-14 12:48:11 --> Security Class Initialized
DEBUG - 2018-05-14 12:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:48:11 --> Input Class Initialized
INFO - 2018-05-14 12:48:11 --> Language Class Initialized
INFO - 2018-05-14 12:48:11 --> Loader Class Initialized
INFO - 2018-05-14 12:48:11 --> Helper loaded: url_helper
INFO - 2018-05-14 12:48:11 --> Helper loaded: form_helper
INFO - 2018-05-14 12:48:11 --> Helper loaded: date_helper
INFO - 2018-05-14 12:48:11 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:48:11 --> Form Validation Class Initialized
INFO - 2018-05-14 12:48:11 --> Model Class Initialized
INFO - 2018-05-14 12:48:11 --> Controller Class Initialized
INFO - 2018-05-14 12:48:11 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 12:48:11 --> Final output sent to browser
DEBUG - 2018-05-14 12:48:11 --> Total execution time: 0.5937
INFO - 2018-05-14 12:48:11 --> Config Class Initialized
INFO - 2018-05-14 12:48:11 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:48:11 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:48:11 --> Utf8 Class Initialized
INFO - 2018-05-14 12:48:11 --> URI Class Initialized
INFO - 2018-05-14 12:48:11 --> Router Class Initialized
INFO - 2018-05-14 12:48:11 --> Output Class Initialized
INFO - 2018-05-14 12:48:11 --> Security Class Initialized
DEBUG - 2018-05-14 12:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:48:11 --> Input Class Initialized
INFO - 2018-05-14 12:48:11 --> Language Class Initialized
ERROR - 2018-05-14 12:48:11 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 12:48:12 --> Config Class Initialized
INFO - 2018-05-14 12:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:48:12 --> Utf8 Class Initialized
INFO - 2018-05-14 12:48:12 --> URI Class Initialized
INFO - 2018-05-14 12:48:12 --> Router Class Initialized
INFO - 2018-05-14 12:48:12 --> Output Class Initialized
INFO - 2018-05-14 12:48:12 --> Security Class Initialized
DEBUG - 2018-05-14 12:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:48:12 --> Input Class Initialized
INFO - 2018-05-14 12:48:12 --> Language Class Initialized
INFO - 2018-05-14 12:48:12 --> Loader Class Initialized
INFO - 2018-05-14 12:48:12 --> Helper loaded: url_helper
INFO - 2018-05-14 12:48:12 --> Helper loaded: form_helper
INFO - 2018-05-14 12:48:12 --> Helper loaded: date_helper
INFO - 2018-05-14 12:48:12 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:48:12 --> Form Validation Class Initialized
INFO - 2018-05-14 12:48:12 --> Model Class Initialized
INFO - 2018-05-14 12:48:12 --> Controller Class Initialized
INFO - 2018-05-14 12:53:43 --> Config Class Initialized
INFO - 2018-05-14 12:53:43 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:53:43 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:53:43 --> Utf8 Class Initialized
INFO - 2018-05-14 12:53:43 --> URI Class Initialized
DEBUG - 2018-05-14 12:53:43 --> No URI present. Default controller set.
INFO - 2018-05-14 12:53:43 --> Router Class Initialized
INFO - 2018-05-14 12:53:43 --> Output Class Initialized
INFO - 2018-05-14 12:53:44 --> Security Class Initialized
DEBUG - 2018-05-14 12:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:53:44 --> Input Class Initialized
INFO - 2018-05-14 12:53:44 --> Language Class Initialized
INFO - 2018-05-14 12:53:44 --> Loader Class Initialized
INFO - 2018-05-14 12:53:44 --> Helper loaded: url_helper
INFO - 2018-05-14 12:53:44 --> Helper loaded: form_helper
INFO - 2018-05-14 12:53:44 --> Helper loaded: date_helper
INFO - 2018-05-14 12:53:44 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:53:44 --> Form Validation Class Initialized
INFO - 2018-05-14 12:53:44 --> Model Class Initialized
INFO - 2018-05-14 12:53:44 --> Controller Class Initialized
INFO - 2018-05-14 12:53:44 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 12:53:44 --> Final output sent to browser
DEBUG - 2018-05-14 12:53:44 --> Total execution time: 0.6538
INFO - 2018-05-14 12:53:45 --> Config Class Initialized
INFO - 2018-05-14 12:53:45 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:53:45 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:53:45 --> Utf8 Class Initialized
INFO - 2018-05-14 12:53:45 --> URI Class Initialized
INFO - 2018-05-14 12:53:45 --> Router Class Initialized
INFO - 2018-05-14 12:53:45 --> Output Class Initialized
INFO - 2018-05-14 12:53:45 --> Security Class Initialized
DEBUG - 2018-05-14 12:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:53:46 --> Input Class Initialized
INFO - 2018-05-14 12:53:46 --> Language Class Initialized
INFO - 2018-05-14 12:53:46 --> Loader Class Initialized
INFO - 2018-05-14 12:53:46 --> Helper loaded: url_helper
INFO - 2018-05-14 12:53:46 --> Helper loaded: form_helper
INFO - 2018-05-14 12:53:46 --> Helper loaded: date_helper
INFO - 2018-05-14 12:53:46 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:53:46 --> Form Validation Class Initialized
INFO - 2018-05-14 12:53:46 --> Model Class Initialized
INFO - 2018-05-14 12:53:46 --> Controller Class Initialized
INFO - 2018-05-14 12:53:46 --> File loaded: C:\xampp\htdocs\mcms\application\views\test.php
INFO - 2018-05-14 12:53:46 --> Final output sent to browser
DEBUG - 2018-05-14 12:53:46 --> Total execution time: 0.5705
INFO - 2018-05-14 12:53:56 --> Config Class Initialized
INFO - 2018-05-14 12:53:56 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:53:56 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:53:56 --> Utf8 Class Initialized
INFO - 2018-05-14 12:53:56 --> URI Class Initialized
INFO - 2018-05-14 12:53:56 --> Router Class Initialized
INFO - 2018-05-14 12:53:56 --> Output Class Initialized
INFO - 2018-05-14 12:53:56 --> Security Class Initialized
DEBUG - 2018-05-14 12:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:53:56 --> Input Class Initialized
INFO - 2018-05-14 12:53:56 --> Language Class Initialized
INFO - 2018-05-14 12:53:56 --> Loader Class Initialized
INFO - 2018-05-14 12:53:56 --> Helper loaded: url_helper
INFO - 2018-05-14 12:53:56 --> Helper loaded: form_helper
INFO - 2018-05-14 12:53:56 --> Helper loaded: date_helper
INFO - 2018-05-14 12:53:56 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:53:56 --> Form Validation Class Initialized
INFO - 2018-05-14 12:53:56 --> Model Class Initialized
INFO - 2018-05-14 12:53:56 --> Controller Class Initialized
INFO - 2018-05-14 12:53:56 --> Final output sent to browser
DEBUG - 2018-05-14 12:53:56 --> Total execution time: 0.6085
INFO - 2018-05-14 12:55:06 --> Config Class Initialized
INFO - 2018-05-14 12:55:06 --> Hooks Class Initialized
DEBUG - 2018-05-14 12:55:06 --> UTF-8 Support Enabled
INFO - 2018-05-14 12:55:06 --> Utf8 Class Initialized
INFO - 2018-05-14 12:55:06 --> URI Class Initialized
INFO - 2018-05-14 12:55:06 --> Router Class Initialized
INFO - 2018-05-14 12:55:06 --> Output Class Initialized
INFO - 2018-05-14 12:55:06 --> Security Class Initialized
DEBUG - 2018-05-14 12:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 12:55:06 --> Input Class Initialized
INFO - 2018-05-14 12:55:06 --> Language Class Initialized
INFO - 2018-05-14 12:55:06 --> Loader Class Initialized
INFO - 2018-05-14 12:55:06 --> Helper loaded: url_helper
INFO - 2018-05-14 12:55:06 --> Helper loaded: form_helper
INFO - 2018-05-14 12:55:06 --> Helper loaded: date_helper
INFO - 2018-05-14 12:55:06 --> Database Driver Class Initialized
DEBUG - 2018-05-14 12:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 12:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 12:55:06 --> Form Validation Class Initialized
INFO - 2018-05-14 12:55:06 --> Model Class Initialized
INFO - 2018-05-14 12:55:06 --> Controller Class Initialized
INFO - 2018-05-14 12:55:06 --> Final output sent to browser
DEBUG - 2018-05-14 12:55:06 --> Total execution time: 0.6340
INFO - 2018-05-14 13:02:57 --> Config Class Initialized
INFO - 2018-05-14 13:02:57 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:02:57 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:02:57 --> Utf8 Class Initialized
INFO - 2018-05-14 13:02:57 --> URI Class Initialized
INFO - 2018-05-14 13:02:57 --> Router Class Initialized
INFO - 2018-05-14 13:02:57 --> Output Class Initialized
INFO - 2018-05-14 13:02:57 --> Security Class Initialized
DEBUG - 2018-05-14 13:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:02:58 --> Input Class Initialized
INFO - 2018-05-14 13:02:58 --> Language Class Initialized
INFO - 2018-05-14 13:02:58 --> Loader Class Initialized
INFO - 2018-05-14 13:02:58 --> Helper loaded: url_helper
INFO - 2018-05-14 13:02:58 --> Helper loaded: form_helper
INFO - 2018-05-14 13:02:58 --> Helper loaded: date_helper
INFO - 2018-05-14 13:02:58 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:02:58 --> Form Validation Class Initialized
INFO - 2018-05-14 13:02:58 --> Model Class Initialized
INFO - 2018-05-14 13:02:58 --> Controller Class Initialized
INFO - 2018-05-14 13:02:58 --> Final output sent to browser
DEBUG - 2018-05-14 13:02:58 --> Total execution time: 0.6890
INFO - 2018-05-14 13:24:40 --> Config Class Initialized
INFO - 2018-05-14 13:24:40 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:24:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:24:40 --> Utf8 Class Initialized
INFO - 2018-05-14 13:24:40 --> URI Class Initialized
INFO - 2018-05-14 13:24:40 --> Router Class Initialized
INFO - 2018-05-14 13:24:40 --> Output Class Initialized
INFO - 2018-05-14 13:24:40 --> Security Class Initialized
DEBUG - 2018-05-14 13:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:24:41 --> Input Class Initialized
INFO - 2018-05-14 13:24:41 --> Language Class Initialized
INFO - 2018-05-14 13:24:41 --> Loader Class Initialized
INFO - 2018-05-14 13:24:41 --> Helper loaded: url_helper
INFO - 2018-05-14 13:24:41 --> Helper loaded: form_helper
INFO - 2018-05-14 13:24:41 --> Helper loaded: date_helper
INFO - 2018-05-14 13:24:41 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:24:41 --> Form Validation Class Initialized
INFO - 2018-05-14 13:24:41 --> Model Class Initialized
INFO - 2018-05-14 13:24:41 --> Controller Class Initialized
ERROR - 2018-05-14 13:24:41 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\mcms\application\controllers\Main.php 457
INFO - 2018-05-14 13:24:41 --> Final output sent to browser
DEBUG - 2018-05-14 13:24:41 --> Total execution time: 0.7334
INFO - 2018-05-14 13:25:35 --> Config Class Initialized
INFO - 2018-05-14 13:25:35 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:25:35 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:25:35 --> Utf8 Class Initialized
INFO - 2018-05-14 13:25:35 --> URI Class Initialized
INFO - 2018-05-14 13:25:35 --> Router Class Initialized
INFO - 2018-05-14 13:25:35 --> Output Class Initialized
INFO - 2018-05-14 13:25:35 --> Security Class Initialized
DEBUG - 2018-05-14 13:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:25:35 --> Input Class Initialized
INFO - 2018-05-14 13:25:35 --> Language Class Initialized
INFO - 2018-05-14 13:25:35 --> Loader Class Initialized
INFO - 2018-05-14 13:25:35 --> Helper loaded: url_helper
INFO - 2018-05-14 13:25:36 --> Helper loaded: form_helper
INFO - 2018-05-14 13:25:36 --> Helper loaded: date_helper
INFO - 2018-05-14 13:25:36 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:25:36 --> Form Validation Class Initialized
INFO - 2018-05-14 13:25:36 --> Model Class Initialized
INFO - 2018-05-14 13:25:36 --> Controller Class Initialized
ERROR - 2018-05-14 13:25:36 --> Severity: Error --> Call to a member function add() on boolean C:\xampp\htdocs\mcms\application\controllers\Main.php 456
INFO - 2018-05-14 13:25:49 --> Config Class Initialized
INFO - 2018-05-14 13:25:49 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:25:49 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:25:49 --> Utf8 Class Initialized
INFO - 2018-05-14 13:25:49 --> URI Class Initialized
INFO - 2018-05-14 13:25:49 --> Router Class Initialized
INFO - 2018-05-14 13:25:49 --> Output Class Initialized
INFO - 2018-05-14 13:25:49 --> Security Class Initialized
DEBUG - 2018-05-14 13:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:25:49 --> Input Class Initialized
INFO - 2018-05-14 13:25:49 --> Language Class Initialized
INFO - 2018-05-14 13:25:49 --> Loader Class Initialized
INFO - 2018-05-14 13:25:49 --> Helper loaded: url_helper
INFO - 2018-05-14 13:25:49 --> Helper loaded: form_helper
INFO - 2018-05-14 13:25:49 --> Helper loaded: date_helper
INFO - 2018-05-14 13:25:49 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:25:49 --> Form Validation Class Initialized
INFO - 2018-05-14 13:25:49 --> Model Class Initialized
INFO - 2018-05-14 13:25:49 --> Controller Class Initialized
ERROR - 2018-05-14 13:25:49 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\mcms\application\controllers\Main.php 458
INFO - 2018-05-14 13:25:49 --> Final output sent to browser
DEBUG - 2018-05-14 13:25:49 --> Total execution time: 0.5265
INFO - 2018-05-14 13:27:48 --> Config Class Initialized
INFO - 2018-05-14 13:27:48 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:27:48 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:27:48 --> Utf8 Class Initialized
INFO - 2018-05-14 13:27:48 --> URI Class Initialized
INFO - 2018-05-14 13:27:48 --> Router Class Initialized
INFO - 2018-05-14 13:27:48 --> Output Class Initialized
INFO - 2018-05-14 13:27:48 --> Security Class Initialized
DEBUG - 2018-05-14 13:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:27:48 --> Input Class Initialized
INFO - 2018-05-14 13:27:48 --> Language Class Initialized
INFO - 2018-05-14 13:27:48 --> Loader Class Initialized
INFO - 2018-05-14 13:27:48 --> Helper loaded: url_helper
INFO - 2018-05-14 13:27:48 --> Helper loaded: form_helper
INFO - 2018-05-14 13:27:48 --> Helper loaded: date_helper
INFO - 2018-05-14 13:27:48 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:27:48 --> Form Validation Class Initialized
INFO - 2018-05-14 13:27:48 --> Model Class Initialized
INFO - 2018-05-14 13:27:48 --> Controller Class Initialized
ERROR - 2018-05-14 13:27:48 --> Severity: Error --> Call to a member function add() on boolean C:\xampp\htdocs\mcms\application\controllers\Main.php 457
INFO - 2018-05-14 13:35:23 --> Config Class Initialized
INFO - 2018-05-14 13:35:23 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:35:23 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:35:23 --> Utf8 Class Initialized
INFO - 2018-05-14 13:35:23 --> URI Class Initialized
INFO - 2018-05-14 13:35:23 --> Router Class Initialized
INFO - 2018-05-14 13:35:23 --> Output Class Initialized
INFO - 2018-05-14 13:35:23 --> Security Class Initialized
DEBUG - 2018-05-14 13:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:35:24 --> Input Class Initialized
INFO - 2018-05-14 13:35:24 --> Language Class Initialized
INFO - 2018-05-14 13:35:24 --> Loader Class Initialized
INFO - 2018-05-14 13:35:24 --> Helper loaded: url_helper
INFO - 2018-05-14 13:35:24 --> Helper loaded: form_helper
INFO - 2018-05-14 13:35:24 --> Helper loaded: date_helper
INFO - 2018-05-14 13:35:24 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:35:24 --> Form Validation Class Initialized
INFO - 2018-05-14 13:35:24 --> Model Class Initialized
INFO - 2018-05-14 13:35:24 --> Controller Class Initialized
ERROR - 2018-05-14 13:35:24 --> Severity: Error --> Call to a member function add() on boolean C:\xampp\htdocs\mcms\application\controllers\Main.php 457
INFO - 2018-05-14 13:35:30 --> Config Class Initialized
INFO - 2018-05-14 13:35:30 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:35:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:35:30 --> Utf8 Class Initialized
INFO - 2018-05-14 13:35:30 --> URI Class Initialized
INFO - 2018-05-14 13:35:30 --> Router Class Initialized
INFO - 2018-05-14 13:35:30 --> Output Class Initialized
INFO - 2018-05-14 13:35:30 --> Security Class Initialized
DEBUG - 2018-05-14 13:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:35:30 --> Input Class Initialized
INFO - 2018-05-14 13:35:30 --> Language Class Initialized
INFO - 2018-05-14 13:35:30 --> Loader Class Initialized
INFO - 2018-05-14 13:35:30 --> Helper loaded: url_helper
INFO - 2018-05-14 13:35:30 --> Helper loaded: form_helper
INFO - 2018-05-14 13:35:30 --> Helper loaded: date_helper
INFO - 2018-05-14 13:35:30 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:35:30 --> Form Validation Class Initialized
INFO - 2018-05-14 13:35:30 --> Model Class Initialized
INFO - 2018-05-14 13:35:30 --> Controller Class Initialized
INFO - 2018-05-14 13:35:30 --> File loaded: C:\xampp\htdocs\mcms\application\views\test.php
INFO - 2018-05-14 13:35:30 --> Final output sent to browser
DEBUG - 2018-05-14 13:35:30 --> Total execution time: 0.7319
INFO - 2018-05-14 13:35:32 --> Config Class Initialized
INFO - 2018-05-14 13:35:32 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:35:32 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:35:32 --> Utf8 Class Initialized
INFO - 2018-05-14 13:35:32 --> URI Class Initialized
INFO - 2018-05-14 13:35:32 --> Router Class Initialized
INFO - 2018-05-14 13:35:32 --> Output Class Initialized
INFO - 2018-05-14 13:35:32 --> Security Class Initialized
DEBUG - 2018-05-14 13:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:35:32 --> Input Class Initialized
INFO - 2018-05-14 13:35:32 --> Language Class Initialized
INFO - 2018-05-14 13:35:32 --> Loader Class Initialized
INFO - 2018-05-14 13:35:32 --> Helper loaded: url_helper
INFO - 2018-05-14 13:35:32 --> Helper loaded: form_helper
INFO - 2018-05-14 13:35:32 --> Helper loaded: date_helper
INFO - 2018-05-14 13:35:32 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:35:32 --> Form Validation Class Initialized
INFO - 2018-05-14 13:35:32 --> Model Class Initialized
INFO - 2018-05-14 13:35:32 --> Controller Class Initialized
INFO - 2018-05-14 13:35:32 --> File loaded: C:\xampp\htdocs\mcms\application\views\test.php
INFO - 2018-05-14 13:35:32 --> Final output sent to browser
DEBUG - 2018-05-14 13:35:32 --> Total execution time: 0.6337
INFO - 2018-05-14 13:35:39 --> Config Class Initialized
INFO - 2018-05-14 13:35:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:35:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:35:40 --> Utf8 Class Initialized
INFO - 2018-05-14 13:35:40 --> URI Class Initialized
INFO - 2018-05-14 13:35:40 --> Router Class Initialized
INFO - 2018-05-14 13:35:40 --> Output Class Initialized
INFO - 2018-05-14 13:35:40 --> Security Class Initialized
DEBUG - 2018-05-14 13:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:35:40 --> Input Class Initialized
INFO - 2018-05-14 13:35:40 --> Language Class Initialized
INFO - 2018-05-14 13:35:40 --> Loader Class Initialized
INFO - 2018-05-14 13:35:40 --> Helper loaded: url_helper
INFO - 2018-05-14 13:35:40 --> Helper loaded: form_helper
INFO - 2018-05-14 13:35:40 --> Helper loaded: date_helper
INFO - 2018-05-14 13:35:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:35:40 --> Form Validation Class Initialized
INFO - 2018-05-14 13:35:40 --> Model Class Initialized
INFO - 2018-05-14 13:35:40 --> Controller Class Initialized
ERROR - 2018-05-14 13:35:40 --> Severity: Error --> Call to a member function add() on boolean C:\xampp\htdocs\mcms\application\controllers\Main.php 457
INFO - 2018-05-14 13:35:59 --> Config Class Initialized
INFO - 2018-05-14 13:35:59 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:35:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:35:59 --> Utf8 Class Initialized
INFO - 2018-05-14 13:35:59 --> URI Class Initialized
INFO - 2018-05-14 13:35:59 --> Router Class Initialized
INFO - 2018-05-14 13:35:59 --> Output Class Initialized
INFO - 2018-05-14 13:35:59 --> Security Class Initialized
DEBUG - 2018-05-14 13:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:35:59 --> Input Class Initialized
INFO - 2018-05-14 13:35:59 --> Language Class Initialized
INFO - 2018-05-14 13:35:59 --> Loader Class Initialized
INFO - 2018-05-14 13:35:59 --> Helper loaded: url_helper
INFO - 2018-05-14 13:35:59 --> Helper loaded: form_helper
INFO - 2018-05-14 13:35:59 --> Helper loaded: date_helper
INFO - 2018-05-14 13:35:59 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:35:59 --> Form Validation Class Initialized
INFO - 2018-05-14 13:35:59 --> Model Class Initialized
INFO - 2018-05-14 13:35:59 --> Controller Class Initialized
INFO - 2018-05-14 13:35:59 --> Final output sent to browser
DEBUG - 2018-05-14 13:35:59 --> Total execution time: 0.5014
INFO - 2018-05-14 13:39:22 --> Config Class Initialized
INFO - 2018-05-14 13:39:22 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:39:22 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:39:22 --> Utf8 Class Initialized
INFO - 2018-05-14 13:39:22 --> URI Class Initialized
INFO - 2018-05-14 13:39:22 --> Router Class Initialized
INFO - 2018-05-14 13:39:22 --> Output Class Initialized
INFO - 2018-05-14 13:39:22 --> Security Class Initialized
DEBUG - 2018-05-14 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:39:23 --> Input Class Initialized
INFO - 2018-05-14 13:39:23 --> Language Class Initialized
INFO - 2018-05-14 13:39:23 --> Loader Class Initialized
INFO - 2018-05-14 13:39:23 --> Helper loaded: url_helper
INFO - 2018-05-14 13:39:23 --> Helper loaded: form_helper
INFO - 2018-05-14 13:39:23 --> Helper loaded: date_helper
INFO - 2018-05-14 13:39:23 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:39:23 --> Form Validation Class Initialized
INFO - 2018-05-14 13:39:23 --> Model Class Initialized
INFO - 2018-05-14 13:39:23 --> Controller Class Initialized
INFO - 2018-05-14 13:39:23 --> Final output sent to browser
DEBUG - 2018-05-14 13:39:23 --> Total execution time: 0.5804
INFO - 2018-05-14 13:47:36 --> Config Class Initialized
INFO - 2018-05-14 13:47:36 --> Hooks Class Initialized
DEBUG - 2018-05-14 13:47:36 --> UTF-8 Support Enabled
INFO - 2018-05-14 13:47:36 --> Utf8 Class Initialized
INFO - 2018-05-14 13:47:36 --> URI Class Initialized
INFO - 2018-05-14 13:47:36 --> Router Class Initialized
INFO - 2018-05-14 13:47:36 --> Output Class Initialized
INFO - 2018-05-14 13:47:36 --> Security Class Initialized
DEBUG - 2018-05-14 13:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 13:47:36 --> Input Class Initialized
INFO - 2018-05-14 13:47:36 --> Language Class Initialized
INFO - 2018-05-14 13:47:36 --> Loader Class Initialized
INFO - 2018-05-14 13:47:36 --> Helper loaded: url_helper
INFO - 2018-05-14 13:47:36 --> Helper loaded: form_helper
INFO - 2018-05-14 13:47:36 --> Helper loaded: date_helper
INFO - 2018-05-14 13:47:36 --> Database Driver Class Initialized
DEBUG - 2018-05-14 13:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 13:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 13:47:36 --> Form Validation Class Initialized
INFO - 2018-05-14 13:47:36 --> Model Class Initialized
INFO - 2018-05-14 13:47:36 --> Controller Class Initialized
INFO - 2018-05-14 13:47:36 --> Final output sent to browser
DEBUG - 2018-05-14 13:47:36 --> Total execution time: 0.5563
INFO - 2018-05-14 16:40:31 --> Config Class Initialized
INFO - 2018-05-14 16:40:31 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:40:31 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:40:31 --> Utf8 Class Initialized
INFO - 2018-05-14 16:40:31 --> URI Class Initialized
INFO - 2018-05-14 16:40:31 --> Router Class Initialized
INFO - 2018-05-14 16:40:31 --> Output Class Initialized
INFO - 2018-05-14 16:40:31 --> Security Class Initialized
DEBUG - 2018-05-14 16:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:40:31 --> Input Class Initialized
INFO - 2018-05-14 16:40:31 --> Language Class Initialized
ERROR - 2018-05-14 16:40:31 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\mcms\application\controllers\Main.php 468
INFO - 2018-05-14 16:40:39 --> Config Class Initialized
INFO - 2018-05-14 16:40:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:40:39 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:40:39 --> Utf8 Class Initialized
INFO - 2018-05-14 16:40:39 --> URI Class Initialized
INFO - 2018-05-14 16:40:39 --> Router Class Initialized
INFO - 2018-05-14 16:40:39 --> Output Class Initialized
INFO - 2018-05-14 16:40:39 --> Security Class Initialized
DEBUG - 2018-05-14 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:40:39 --> Input Class Initialized
INFO - 2018-05-14 16:40:39 --> Language Class Initialized
INFO - 2018-05-14 16:40:39 --> Loader Class Initialized
INFO - 2018-05-14 16:40:39 --> Helper loaded: url_helper
INFO - 2018-05-14 16:40:39 --> Helper loaded: form_helper
INFO - 2018-05-14 16:40:39 --> Helper loaded: date_helper
INFO - 2018-05-14 16:40:39 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:40:39 --> Form Validation Class Initialized
INFO - 2018-05-14 16:40:39 --> Model Class Initialized
INFO - 2018-05-14 16:40:39 --> Controller Class Initialized
INFO - 2018-05-14 16:40:39 --> File loaded: C:\xampp\htdocs\mcms\application\views\test.php
INFO - 2018-05-14 16:40:39 --> Final output sent to browser
DEBUG - 2018-05-14 16:40:39 --> Total execution time: 0.4834
INFO - 2018-05-14 16:40:47 --> Config Class Initialized
INFO - 2018-05-14 16:40:47 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:40:47 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:40:47 --> Utf8 Class Initialized
INFO - 2018-05-14 16:40:47 --> URI Class Initialized
INFO - 2018-05-14 16:40:47 --> Router Class Initialized
INFO - 2018-05-14 16:40:47 --> Output Class Initialized
INFO - 2018-05-14 16:40:47 --> Security Class Initialized
DEBUG - 2018-05-14 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:40:47 --> Input Class Initialized
INFO - 2018-05-14 16:40:47 --> Language Class Initialized
INFO - 2018-05-14 16:40:47 --> Loader Class Initialized
INFO - 2018-05-14 16:40:47 --> Helper loaded: url_helper
INFO - 2018-05-14 16:40:47 --> Helper loaded: form_helper
INFO - 2018-05-14 16:40:47 --> Helper loaded: date_helper
INFO - 2018-05-14 16:40:47 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:40:47 --> Form Validation Class Initialized
INFO - 2018-05-14 16:40:47 --> Model Class Initialized
INFO - 2018-05-14 16:40:47 --> Controller Class Initialized
INFO - 2018-05-14 16:40:47 --> Final output sent to browser
DEBUG - 2018-05-14 16:40:47 --> Total execution time: 0.4931
INFO - 2018-05-14 16:44:22 --> Config Class Initialized
INFO - 2018-05-14 16:44:22 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:44:22 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:44:22 --> Utf8 Class Initialized
INFO - 2018-05-14 16:44:22 --> URI Class Initialized
INFO - 2018-05-14 16:44:22 --> Router Class Initialized
INFO - 2018-05-14 16:44:22 --> Output Class Initialized
INFO - 2018-05-14 16:44:22 --> Security Class Initialized
DEBUG - 2018-05-14 16:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:44:22 --> Input Class Initialized
INFO - 2018-05-14 16:44:22 --> Language Class Initialized
INFO - 2018-05-14 16:44:22 --> Loader Class Initialized
INFO - 2018-05-14 16:44:22 --> Helper loaded: url_helper
INFO - 2018-05-14 16:44:22 --> Helper loaded: form_helper
INFO - 2018-05-14 16:44:22 --> Helper loaded: date_helper
INFO - 2018-05-14 16:44:22 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:44:22 --> Form Validation Class Initialized
INFO - 2018-05-14 16:44:22 --> Model Class Initialized
INFO - 2018-05-14 16:44:22 --> Controller Class Initialized
INFO - 2018-05-14 16:44:22 --> Final output sent to browser
DEBUG - 2018-05-14 16:44:22 --> Total execution time: 0.5242
INFO - 2018-05-14 16:44:34 --> Config Class Initialized
INFO - 2018-05-14 16:44:34 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:44:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:44:34 --> Utf8 Class Initialized
INFO - 2018-05-14 16:44:34 --> URI Class Initialized
INFO - 2018-05-14 16:44:34 --> Router Class Initialized
INFO - 2018-05-14 16:44:34 --> Output Class Initialized
INFO - 2018-05-14 16:44:34 --> Security Class Initialized
DEBUG - 2018-05-14 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:44:34 --> Input Class Initialized
INFO - 2018-05-14 16:44:34 --> Language Class Initialized
ERROR - 2018-05-14 16:44:34 --> Severity: Parsing Error --> syntax error, unexpected '$w' (T_VARIABLE), expecting ')' C:\xampp\htdocs\mcms\application\controllers\Main.php 468
INFO - 2018-05-14 16:45:31 --> Config Class Initialized
INFO - 2018-05-14 16:45:31 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:45:31 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:45:31 --> Utf8 Class Initialized
INFO - 2018-05-14 16:45:31 --> URI Class Initialized
INFO - 2018-05-14 16:45:31 --> Router Class Initialized
INFO - 2018-05-14 16:45:31 --> Output Class Initialized
INFO - 2018-05-14 16:45:31 --> Security Class Initialized
DEBUG - 2018-05-14 16:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:45:31 --> Input Class Initialized
INFO - 2018-05-14 16:45:31 --> Language Class Initialized
ERROR - 2018-05-14 16:45:31 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\mcms\application\controllers\Main.php 468
INFO - 2018-05-14 16:45:37 --> Config Class Initialized
INFO - 2018-05-14 16:45:37 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:45:37 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:45:37 --> Utf8 Class Initialized
INFO - 2018-05-14 16:45:37 --> URI Class Initialized
INFO - 2018-05-14 16:45:37 --> Router Class Initialized
INFO - 2018-05-14 16:45:37 --> Output Class Initialized
INFO - 2018-05-14 16:45:37 --> Security Class Initialized
DEBUG - 2018-05-14 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:45:37 --> Input Class Initialized
INFO - 2018-05-14 16:45:37 --> Language Class Initialized
INFO - 2018-05-14 16:45:37 --> Loader Class Initialized
INFO - 2018-05-14 16:45:37 --> Helper loaded: url_helper
INFO - 2018-05-14 16:45:37 --> Helper loaded: form_helper
INFO - 2018-05-14 16:45:37 --> Helper loaded: date_helper
INFO - 2018-05-14 16:45:37 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:45:37 --> Form Validation Class Initialized
INFO - 2018-05-14 16:45:37 --> Model Class Initialized
INFO - 2018-05-14 16:45:37 --> Controller Class Initialized
INFO - 2018-05-14 16:45:37 --> Final output sent to browser
DEBUG - 2018-05-14 16:45:37 --> Total execution time: 0.4828
INFO - 2018-05-14 16:47:17 --> Config Class Initialized
INFO - 2018-05-14 16:47:17 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:47:17 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:47:17 --> Utf8 Class Initialized
INFO - 2018-05-14 16:47:17 --> URI Class Initialized
INFO - 2018-05-14 16:47:17 --> Router Class Initialized
INFO - 2018-05-14 16:47:17 --> Output Class Initialized
INFO - 2018-05-14 16:47:17 --> Security Class Initialized
DEBUG - 2018-05-14 16:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:47:17 --> Input Class Initialized
INFO - 2018-05-14 16:47:17 --> Language Class Initialized
INFO - 2018-05-14 16:47:17 --> Loader Class Initialized
INFO - 2018-05-14 16:47:17 --> Helper loaded: url_helper
INFO - 2018-05-14 16:47:17 --> Helper loaded: form_helper
INFO - 2018-05-14 16:47:17 --> Helper loaded: date_helper
INFO - 2018-05-14 16:47:17 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:47:17 --> Form Validation Class Initialized
INFO - 2018-05-14 16:47:17 --> Model Class Initialized
INFO - 2018-05-14 16:47:18 --> Controller Class Initialized
INFO - 2018-05-14 16:47:18 --> Final output sent to browser
DEBUG - 2018-05-14 16:47:18 --> Total execution time: 0.6459
INFO - 2018-05-14 16:51:25 --> Config Class Initialized
INFO - 2018-05-14 16:51:26 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:26 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:26 --> URI Class Initialized
DEBUG - 2018-05-14 16:51:26 --> No URI present. Default controller set.
INFO - 2018-05-14 16:51:26 --> Router Class Initialized
INFO - 2018-05-14 16:51:26 --> Output Class Initialized
INFO - 2018-05-14 16:51:26 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:26 --> Input Class Initialized
INFO - 2018-05-14 16:51:26 --> Language Class Initialized
INFO - 2018-05-14 16:51:26 --> Loader Class Initialized
INFO - 2018-05-14 16:51:26 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:26 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:26 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:26 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:26 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:26 --> Model Class Initialized
INFO - 2018-05-14 16:51:26 --> Controller Class Initialized
INFO - 2018-05-14 16:51:26 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 16:51:26 --> Final output sent to browser
INFO - 2018-05-14 16:51:26 --> Config Class Initialized
DEBUG - 2018-05-14 16:51:26 --> Total execution time: 0.6469
INFO - 2018-05-14 16:51:26 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:26 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:26 --> URI Class Initialized
DEBUG - 2018-05-14 16:51:26 --> No URI present. Default controller set.
INFO - 2018-05-14 16:51:26 --> Router Class Initialized
INFO - 2018-05-14 16:51:26 --> Output Class Initialized
INFO - 2018-05-14 16:51:26 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:26 --> Input Class Initialized
INFO - 2018-05-14 16:51:26 --> Language Class Initialized
INFO - 2018-05-14 16:51:26 --> Loader Class Initialized
INFO - 2018-05-14 16:51:26 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:26 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:27 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:27 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:27 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:27 --> Model Class Initialized
INFO - 2018-05-14 16:51:27 --> Controller Class Initialized
INFO - 2018-05-14 16:51:27 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 16:51:27 --> Final output sent to browser
DEBUG - 2018-05-14 16:51:27 --> Total execution time: 0.7155
INFO - 2018-05-14 16:51:30 --> Config Class Initialized
INFO - 2018-05-14 16:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:31 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:31 --> URI Class Initialized
INFO - 2018-05-14 16:51:31 --> Router Class Initialized
INFO - 2018-05-14 16:51:31 --> Output Class Initialized
INFO - 2018-05-14 16:51:31 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:31 --> Input Class Initialized
INFO - 2018-05-14 16:51:31 --> Language Class Initialized
INFO - 2018-05-14 16:51:31 --> Loader Class Initialized
INFO - 2018-05-14 16:51:31 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:31 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:31 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:31 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:31 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:31 --> Model Class Initialized
INFO - 2018-05-14 16:51:31 --> Controller Class Initialized
INFO - 2018-05-14 16:51:31 --> File loaded: C:\xampp\htdocs\mcms\application\views\form.php
INFO - 2018-05-14 16:51:31 --> Final output sent to browser
DEBUG - 2018-05-14 16:51:31 --> Total execution time: 0.5818
INFO - 2018-05-14 16:51:36 --> Config Class Initialized
INFO - 2018-05-14 16:51:36 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:36 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:36 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:36 --> URI Class Initialized
INFO - 2018-05-14 16:51:36 --> Router Class Initialized
INFO - 2018-05-14 16:51:36 --> Output Class Initialized
INFO - 2018-05-14 16:51:36 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:36 --> Input Class Initialized
INFO - 2018-05-14 16:51:36 --> Language Class Initialized
INFO - 2018-05-14 16:51:36 --> Loader Class Initialized
INFO - 2018-05-14 16:51:36 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:36 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:36 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:36 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:36 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:36 --> Model Class Initialized
INFO - 2018-05-14 16:51:36 --> Controller Class Initialized
INFO - 2018-05-14 16:51:36 --> Config Class Initialized
INFO - 2018-05-14 16:51:36 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:36 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:36 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:36 --> URI Class Initialized
INFO - 2018-05-14 16:51:36 --> Router Class Initialized
INFO - 2018-05-14 16:51:36 --> Output Class Initialized
INFO - 2018-05-14 16:51:36 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:36 --> Input Class Initialized
INFO - 2018-05-14 16:51:36 --> Language Class Initialized
INFO - 2018-05-14 16:51:37 --> Loader Class Initialized
INFO - 2018-05-14 16:51:37 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:37 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:37 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:37 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:37 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:37 --> Model Class Initialized
INFO - 2018-05-14 16:51:37 --> Controller Class Initialized
INFO - 2018-05-14 16:51:37 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 16:51:37 --> Final output sent to browser
INFO - 2018-05-14 16:51:37 --> Config Class Initialized
DEBUG - 2018-05-14 16:51:37 --> Total execution time: 0.5476
INFO - 2018-05-14 16:51:37 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:37 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:37 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:37 --> URI Class Initialized
INFO - 2018-05-14 16:51:37 --> Router Class Initialized
INFO - 2018-05-14 16:51:37 --> Output Class Initialized
INFO - 2018-05-14 16:51:37 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:37 --> Input Class Initialized
INFO - 2018-05-14 16:51:37 --> Language Class Initialized
ERROR - 2018-05-14 16:51:37 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 16:51:41 --> Config Class Initialized
INFO - 2018-05-14 16:51:41 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:41 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:41 --> URI Class Initialized
INFO - 2018-05-14 16:51:41 --> Router Class Initialized
INFO - 2018-05-14 16:51:41 --> Output Class Initialized
INFO - 2018-05-14 16:51:41 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:41 --> Input Class Initialized
INFO - 2018-05-14 16:51:41 --> Language Class Initialized
INFO - 2018-05-14 16:51:41 --> Loader Class Initialized
INFO - 2018-05-14 16:51:41 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:41 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:41 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:41 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:41 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:41 --> Model Class Initialized
INFO - 2018-05-14 16:51:41 --> Controller Class Initialized
INFO - 2018-05-14 16:51:41 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 16:51:41 --> Final output sent to browser
INFO - 2018-05-14 16:51:41 --> Config Class Initialized
DEBUG - 2018-05-14 16:51:41 --> Total execution time: 0.5337
INFO - 2018-05-14 16:51:42 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:42 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:42 --> URI Class Initialized
INFO - 2018-05-14 16:51:42 --> Router Class Initialized
INFO - 2018-05-14 16:51:42 --> Output Class Initialized
INFO - 2018-05-14 16:51:42 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:42 --> Input Class Initialized
INFO - 2018-05-14 16:51:42 --> Language Class Initialized
ERROR - 2018-05-14 16:51:42 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 16:51:42 --> Config Class Initialized
INFO - 2018-05-14 16:51:42 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:51:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:51:42 --> Utf8 Class Initialized
INFO - 2018-05-14 16:51:42 --> URI Class Initialized
INFO - 2018-05-14 16:51:42 --> Router Class Initialized
INFO - 2018-05-14 16:51:42 --> Output Class Initialized
INFO - 2018-05-14 16:51:42 --> Security Class Initialized
DEBUG - 2018-05-14 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:51:42 --> Input Class Initialized
INFO - 2018-05-14 16:51:42 --> Language Class Initialized
INFO - 2018-05-14 16:51:42 --> Loader Class Initialized
INFO - 2018-05-14 16:51:42 --> Helper loaded: url_helper
INFO - 2018-05-14 16:51:42 --> Helper loaded: form_helper
INFO - 2018-05-14 16:51:42 --> Helper loaded: date_helper
INFO - 2018-05-14 16:51:42 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:51:42 --> Form Validation Class Initialized
INFO - 2018-05-14 16:51:42 --> Model Class Initialized
INFO - 2018-05-14 16:51:42 --> Controller Class Initialized
INFO - 2018-05-14 16:52:43 --> Config Class Initialized
INFO - 2018-05-14 16:52:43 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:52:43 --> Utf8 Class Initialized
INFO - 2018-05-14 16:52:43 --> URI Class Initialized
INFO - 2018-05-14 16:52:43 --> Router Class Initialized
INFO - 2018-05-14 16:52:43 --> Output Class Initialized
INFO - 2018-05-14 16:52:43 --> Security Class Initialized
DEBUG - 2018-05-14 16:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:52:43 --> Input Class Initialized
INFO - 2018-05-14 16:52:43 --> Language Class Initialized
INFO - 2018-05-14 16:52:43 --> Loader Class Initialized
INFO - 2018-05-14 16:52:43 --> Helper loaded: url_helper
INFO - 2018-05-14 16:52:43 --> Helper loaded: form_helper
INFO - 2018-05-14 16:52:43 --> Helper loaded: date_helper
INFO - 2018-05-14 16:52:44 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:52:44 --> Form Validation Class Initialized
INFO - 2018-05-14 16:52:44 --> Model Class Initialized
INFO - 2018-05-14 16:52:44 --> Controller Class Initialized
INFO - 2018-05-14 16:52:44 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 16:52:44 --> Final output sent to browser
DEBUG - 2018-05-14 16:52:44 --> Total execution time: 0.5894
INFO - 2018-05-14 16:52:44 --> Config Class Initialized
INFO - 2018-05-14 16:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:52:44 --> Utf8 Class Initialized
INFO - 2018-05-14 16:52:44 --> URI Class Initialized
INFO - 2018-05-14 16:52:44 --> Router Class Initialized
INFO - 2018-05-14 16:52:44 --> Output Class Initialized
INFO - 2018-05-14 16:52:44 --> Security Class Initialized
DEBUG - 2018-05-14 16:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:52:44 --> Input Class Initialized
INFO - 2018-05-14 16:52:44 --> Language Class Initialized
ERROR - 2018-05-14 16:52:44 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 16:52:44 --> Config Class Initialized
INFO - 2018-05-14 16:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:52:45 --> Utf8 Class Initialized
INFO - 2018-05-14 16:52:45 --> URI Class Initialized
INFO - 2018-05-14 16:52:45 --> Router Class Initialized
INFO - 2018-05-14 16:52:45 --> Output Class Initialized
INFO - 2018-05-14 16:52:45 --> Security Class Initialized
DEBUG - 2018-05-14 16:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:52:45 --> Input Class Initialized
INFO - 2018-05-14 16:52:45 --> Language Class Initialized
INFO - 2018-05-14 16:52:45 --> Loader Class Initialized
INFO - 2018-05-14 16:52:45 --> Helper loaded: url_helper
INFO - 2018-05-14 16:52:45 --> Helper loaded: form_helper
INFO - 2018-05-14 16:52:45 --> Helper loaded: date_helper
INFO - 2018-05-14 16:52:45 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:52:45 --> Form Validation Class Initialized
INFO - 2018-05-14 16:52:45 --> Model Class Initialized
INFO - 2018-05-14 16:52:45 --> Controller Class Initialized
INFO - 2018-05-14 16:54:28 --> Config Class Initialized
INFO - 2018-05-14 16:54:28 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:54:28 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:54:28 --> Utf8 Class Initialized
INFO - 2018-05-14 16:54:28 --> URI Class Initialized
INFO - 2018-05-14 16:54:28 --> Router Class Initialized
INFO - 2018-05-14 16:54:28 --> Output Class Initialized
INFO - 2018-05-14 16:54:28 --> Security Class Initialized
DEBUG - 2018-05-14 16:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:54:28 --> Input Class Initialized
INFO - 2018-05-14 16:54:28 --> Language Class Initialized
INFO - 2018-05-14 16:54:28 --> Loader Class Initialized
INFO - 2018-05-14 16:54:28 --> Helper loaded: url_helper
INFO - 2018-05-14 16:54:28 --> Helper loaded: form_helper
INFO - 2018-05-14 16:54:28 --> Helper loaded: date_helper
INFO - 2018-05-14 16:54:28 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:54:28 --> Form Validation Class Initialized
INFO - 2018-05-14 16:54:28 --> Model Class Initialized
INFO - 2018-05-14 16:54:28 --> Controller Class Initialized
INFO - 2018-05-14 16:54:29 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 16:54:29 --> Final output sent to browser
DEBUG - 2018-05-14 16:54:29 --> Total execution time: 0.7528
INFO - 2018-05-14 16:54:29 --> Config Class Initialized
INFO - 2018-05-14 16:54:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:54:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:54:29 --> Utf8 Class Initialized
INFO - 2018-05-14 16:54:29 --> URI Class Initialized
INFO - 2018-05-14 16:54:29 --> Router Class Initialized
INFO - 2018-05-14 16:54:29 --> Output Class Initialized
INFO - 2018-05-14 16:54:29 --> Security Class Initialized
DEBUG - 2018-05-14 16:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:54:29 --> Input Class Initialized
INFO - 2018-05-14 16:54:29 --> Language Class Initialized
ERROR - 2018-05-14 16:54:29 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 16:54:29 --> Config Class Initialized
INFO - 2018-05-14 16:54:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 16:54:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 16:54:29 --> Utf8 Class Initialized
INFO - 2018-05-14 16:54:29 --> URI Class Initialized
INFO - 2018-05-14 16:54:29 --> Router Class Initialized
INFO - 2018-05-14 16:54:29 --> Output Class Initialized
INFO - 2018-05-14 16:54:29 --> Security Class Initialized
DEBUG - 2018-05-14 16:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 16:54:29 --> Input Class Initialized
INFO - 2018-05-14 16:54:29 --> Language Class Initialized
INFO - 2018-05-14 16:54:29 --> Loader Class Initialized
INFO - 2018-05-14 16:54:30 --> Helper loaded: url_helper
INFO - 2018-05-14 16:54:30 --> Helper loaded: form_helper
INFO - 2018-05-14 16:54:30 --> Helper loaded: date_helper
INFO - 2018-05-14 16:54:30 --> Database Driver Class Initialized
DEBUG - 2018-05-14 16:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 16:54:30 --> Form Validation Class Initialized
INFO - 2018-05-14 16:54:30 --> Model Class Initialized
INFO - 2018-05-14 16:54:30 --> Controller Class Initialized
INFO - 2018-05-14 17:08:39 --> Config Class Initialized
INFO - 2018-05-14 17:08:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:08:39 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:08:39 --> Utf8 Class Initialized
INFO - 2018-05-14 17:08:39 --> URI Class Initialized
INFO - 2018-05-14 17:08:39 --> Router Class Initialized
INFO - 2018-05-14 17:08:39 --> Output Class Initialized
INFO - 2018-05-14 17:08:39 --> Security Class Initialized
DEBUG - 2018-05-14 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:08:39 --> Input Class Initialized
INFO - 2018-05-14 17:08:39 --> Language Class Initialized
INFO - 2018-05-14 17:08:39 --> Loader Class Initialized
INFO - 2018-05-14 17:08:39 --> Helper loaded: url_helper
INFO - 2018-05-14 17:08:39 --> Helper loaded: form_helper
INFO - 2018-05-14 17:08:39 --> Helper loaded: date_helper
INFO - 2018-05-14 17:08:39 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:08:39 --> Form Validation Class Initialized
INFO - 2018-05-14 17:08:39 --> Model Class Initialized
INFO - 2018-05-14 17:08:39 --> Controller Class Initialized
INFO - 2018-05-14 17:08:39 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 17:08:39 --> Final output sent to browser
DEBUG - 2018-05-14 17:08:39 --> Total execution time: 0.7278
INFO - 2018-05-14 17:08:39 --> Config Class Initialized
INFO - 2018-05-14 17:08:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:08:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:08:40 --> Utf8 Class Initialized
INFO - 2018-05-14 17:08:40 --> URI Class Initialized
INFO - 2018-05-14 17:08:40 --> Router Class Initialized
INFO - 2018-05-14 17:08:40 --> Output Class Initialized
INFO - 2018-05-14 17:08:40 --> Security Class Initialized
DEBUG - 2018-05-14 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:08:40 --> Input Class Initialized
INFO - 2018-05-14 17:08:40 --> Language Class Initialized
ERROR - 2018-05-14 17:08:40 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 17:08:40 --> Config Class Initialized
INFO - 2018-05-14 17:08:40 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:08:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:08:40 --> Utf8 Class Initialized
INFO - 2018-05-14 17:08:40 --> URI Class Initialized
INFO - 2018-05-14 17:08:40 --> Router Class Initialized
INFO - 2018-05-14 17:08:40 --> Output Class Initialized
INFO - 2018-05-14 17:08:40 --> Security Class Initialized
DEBUG - 2018-05-14 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:08:40 --> Input Class Initialized
INFO - 2018-05-14 17:08:40 --> Language Class Initialized
INFO - 2018-05-14 17:08:40 --> Loader Class Initialized
INFO - 2018-05-14 17:08:40 --> Helper loaded: url_helper
INFO - 2018-05-14 17:08:40 --> Helper loaded: form_helper
INFO - 2018-05-14 17:08:40 --> Helper loaded: date_helper
INFO - 2018-05-14 17:08:40 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:08:40 --> Form Validation Class Initialized
INFO - 2018-05-14 17:08:40 --> Model Class Initialized
INFO - 2018-05-14 17:08:41 --> Controller Class Initialized
INFO - 2018-05-14 17:09:02 --> Config Class Initialized
INFO - 2018-05-14 17:09:02 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:09:02 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:09:02 --> Utf8 Class Initialized
INFO - 2018-05-14 17:09:02 --> URI Class Initialized
INFO - 2018-05-14 17:09:02 --> Router Class Initialized
INFO - 2018-05-14 17:09:02 --> Output Class Initialized
INFO - 2018-05-14 17:09:02 --> Security Class Initialized
DEBUG - 2018-05-14 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:09:02 --> Input Class Initialized
INFO - 2018-05-14 17:09:03 --> Language Class Initialized
INFO - 2018-05-14 17:09:03 --> Loader Class Initialized
INFO - 2018-05-14 17:09:03 --> Helper loaded: url_helper
INFO - 2018-05-14 17:09:03 --> Helper loaded: form_helper
INFO - 2018-05-14 17:09:03 --> Helper loaded: date_helper
INFO - 2018-05-14 17:09:03 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:09:03 --> Form Validation Class Initialized
INFO - 2018-05-14 17:09:03 --> Model Class Initialized
INFO - 2018-05-14 17:09:03 --> Controller Class Initialized
INFO - 2018-05-14 17:09:03 --> Config Class Initialized
INFO - 2018-05-14 17:09:03 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:09:03 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:09:03 --> Utf8 Class Initialized
INFO - 2018-05-14 17:09:03 --> URI Class Initialized
INFO - 2018-05-14 17:09:03 --> Router Class Initialized
INFO - 2018-05-14 17:09:03 --> Output Class Initialized
INFO - 2018-05-14 17:09:03 --> Security Class Initialized
DEBUG - 2018-05-14 17:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:09:03 --> Input Class Initialized
INFO - 2018-05-14 17:09:03 --> Language Class Initialized
INFO - 2018-05-14 17:09:03 --> Loader Class Initialized
INFO - 2018-05-14 17:09:03 --> Helper loaded: url_helper
INFO - 2018-05-14 17:09:03 --> Helper loaded: form_helper
INFO - 2018-05-14 17:09:03 --> Helper loaded: date_helper
INFO - 2018-05-14 17:09:03 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:09:03 --> Form Validation Class Initialized
INFO - 2018-05-14 17:09:03 --> Model Class Initialized
INFO - 2018-05-14 17:09:03 --> Controller Class Initialized
INFO - 2018-05-14 17:09:04 --> File loaded: C:\xampp\htdocs\mcms\application\views\patient_profile.php
INFO - 2018-05-14 17:09:04 --> Final output sent to browser
INFO - 2018-05-14 17:09:04 --> Config Class Initialized
DEBUG - 2018-05-14 17:09:04 --> Total execution time: 0.5388
INFO - 2018-05-14 17:09:04 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:09:04 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:09:04 --> Utf8 Class Initialized
INFO - 2018-05-14 17:09:04 --> URI Class Initialized
INFO - 2018-05-14 17:09:04 --> Router Class Initialized
INFO - 2018-05-14 17:09:04 --> Output Class Initialized
INFO - 2018-05-14 17:09:04 --> Security Class Initialized
DEBUG - 2018-05-14 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:09:04 --> Input Class Initialized
INFO - 2018-05-14 17:09:04 --> Language Class Initialized
ERROR - 2018-05-14 17:09:04 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 17:09:08 --> Config Class Initialized
INFO - 2018-05-14 17:09:08 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:09:08 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:09:08 --> Utf8 Class Initialized
INFO - 2018-05-14 17:09:08 --> URI Class Initialized
INFO - 2018-05-14 17:09:08 --> Router Class Initialized
INFO - 2018-05-14 17:09:08 --> Output Class Initialized
INFO - 2018-05-14 17:09:08 --> Security Class Initialized
DEBUG - 2018-05-14 17:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:09:08 --> Input Class Initialized
INFO - 2018-05-14 17:09:08 --> Language Class Initialized
INFO - 2018-05-14 17:09:08 --> Loader Class Initialized
INFO - 2018-05-14 17:09:08 --> Helper loaded: url_helper
INFO - 2018-05-14 17:09:08 --> Helper loaded: form_helper
INFO - 2018-05-14 17:09:08 --> Helper loaded: date_helper
INFO - 2018-05-14 17:09:08 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:09:08 --> Form Validation Class Initialized
INFO - 2018-05-14 17:09:08 --> Model Class Initialized
INFO - 2018-05-14 17:09:08 --> Controller Class Initialized
INFO - 2018-05-14 17:09:08 --> File loaded: C:\xampp\htdocs\mcms\application\views\appt.php
INFO - 2018-05-14 17:09:08 --> Final output sent to browser
INFO - 2018-05-14 17:09:09 --> Config Class Initialized
DEBUG - 2018-05-14 17:09:09 --> Total execution time: 0.7728
INFO - 2018-05-14 17:09:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:09:09 --> Utf8 Class Initialized
INFO - 2018-05-14 17:09:09 --> URI Class Initialized
INFO - 2018-05-14 17:09:09 --> Router Class Initialized
INFO - 2018-05-14 17:09:09 --> Output Class Initialized
INFO - 2018-05-14 17:09:09 --> Security Class Initialized
DEBUG - 2018-05-14 17:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:09:09 --> Input Class Initialized
INFO - 2018-05-14 17:09:09 --> Language Class Initialized
ERROR - 2018-05-14 17:09:09 --> 404 Page Not Found: Main/css
INFO - 2018-05-14 17:09:09 --> Config Class Initialized
INFO - 2018-05-14 17:09:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:09:09 --> Utf8 Class Initialized
INFO - 2018-05-14 17:09:09 --> URI Class Initialized
INFO - 2018-05-14 17:09:09 --> Router Class Initialized
INFO - 2018-05-14 17:09:09 --> Output Class Initialized
INFO - 2018-05-14 17:09:09 --> Security Class Initialized
DEBUG - 2018-05-14 17:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:09:09 --> Input Class Initialized
INFO - 2018-05-14 17:09:09 --> Language Class Initialized
INFO - 2018-05-14 17:09:09 --> Loader Class Initialized
INFO - 2018-05-14 17:09:09 --> Helper loaded: url_helper
INFO - 2018-05-14 17:09:09 --> Helper loaded: form_helper
INFO - 2018-05-14 17:09:09 --> Helper loaded: date_helper
INFO - 2018-05-14 17:09:09 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:09:10 --> Form Validation Class Initialized
INFO - 2018-05-14 17:09:10 --> Model Class Initialized
INFO - 2018-05-14 17:09:10 --> Controller Class Initialized
INFO - 2018-05-14 17:10:33 --> Config Class Initialized
INFO - 2018-05-14 17:10:33 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:33 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:33 --> URI Class Initialized
INFO - 2018-05-14 17:10:33 --> Router Class Initialized
INFO - 2018-05-14 17:10:34 --> Output Class Initialized
INFO - 2018-05-14 17:10:34 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:34 --> Input Class Initialized
INFO - 2018-05-14 17:10:34 --> Language Class Initialized
INFO - 2018-05-14 17:10:34 --> Loader Class Initialized
INFO - 2018-05-14 17:10:34 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:34 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:34 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:34 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:34 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:34 --> Model Class Initialized
INFO - 2018-05-14 17:10:34 --> Controller Class Initialized
INFO - 2018-05-14 17:10:34 --> Config Class Initialized
INFO - 2018-05-14 17:10:34 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:34 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:34 --> URI Class Initialized
INFO - 2018-05-14 17:10:34 --> Router Class Initialized
INFO - 2018-05-14 17:10:34 --> Output Class Initialized
INFO - 2018-05-14 17:10:34 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:34 --> Input Class Initialized
INFO - 2018-05-14 17:10:34 --> Language Class Initialized
INFO - 2018-05-14 17:10:34 --> Loader Class Initialized
INFO - 2018-05-14 17:10:34 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:34 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:34 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:34 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:35 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:35 --> Model Class Initialized
INFO - 2018-05-14 17:10:35 --> Controller Class Initialized
INFO - 2018-05-14 17:10:35 --> File loaded: C:\xampp\htdocs\mcms\application\views\index.php
INFO - 2018-05-14 17:10:35 --> Final output sent to browser
DEBUG - 2018-05-14 17:10:35 --> Total execution time: 0.6738
INFO - 2018-05-14 17:10:36 --> Config Class Initialized
INFO - 2018-05-14 17:10:36 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:36 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:36 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:36 --> URI Class Initialized
INFO - 2018-05-14 17:10:36 --> Router Class Initialized
INFO - 2018-05-14 17:10:36 --> Output Class Initialized
INFO - 2018-05-14 17:10:36 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:36 --> Input Class Initialized
INFO - 2018-05-14 17:10:36 --> Language Class Initialized
INFO - 2018-05-14 17:10:37 --> Loader Class Initialized
INFO - 2018-05-14 17:10:37 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:37 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:37 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:37 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:37 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:37 --> Model Class Initialized
INFO - 2018-05-14 17:10:37 --> Controller Class Initialized
INFO - 2018-05-14 17:10:37 --> File loaded: C:\xampp\htdocs\mcms\application\views\login.php
INFO - 2018-05-14 17:10:37 --> Final output sent to browser
DEBUG - 2018-05-14 17:10:37 --> Total execution time: 0.6112
INFO - 2018-05-14 17:10:40 --> Config Class Initialized
INFO - 2018-05-14 17:10:40 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:40 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:40 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:40 --> URI Class Initialized
INFO - 2018-05-14 17:10:40 --> Router Class Initialized
INFO - 2018-05-14 17:10:41 --> Output Class Initialized
INFO - 2018-05-14 17:10:41 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:41 --> Input Class Initialized
INFO - 2018-05-14 17:10:41 --> Language Class Initialized
INFO - 2018-05-14 17:10:41 --> Loader Class Initialized
INFO - 2018-05-14 17:10:41 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:41 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:41 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:41 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:41 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:41 --> Model Class Initialized
INFO - 2018-05-14 17:10:41 --> Controller Class Initialized
DEBUG - 2018-05-14 17:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-14 17:10:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-14 17:10:41 --> Config Class Initialized
INFO - 2018-05-14 17:10:41 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:41 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:41 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:41 --> URI Class Initialized
INFO - 2018-05-14 17:10:41 --> Router Class Initialized
INFO - 2018-05-14 17:10:41 --> Output Class Initialized
INFO - 2018-05-14 17:10:41 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:41 --> Input Class Initialized
INFO - 2018-05-14 17:10:41 --> Language Class Initialized
INFO - 2018-05-14 17:10:41 --> Loader Class Initialized
INFO - 2018-05-14 17:10:41 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:41 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:41 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:41 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:41 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:41 --> Model Class Initialized
INFO - 2018-05-14 17:10:41 --> Controller Class Initialized
INFO - 2018-05-14 17:10:42 --> Model Class Initialized
INFO - 2018-05-14 17:10:42 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 17:10:42 --> Final output sent to browser
DEBUG - 2018-05-14 17:10:42 --> Total execution time: 0.6146
INFO - 2018-05-14 17:10:42 --> Config Class Initialized
INFO - 2018-05-14 17:10:42 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:42 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:42 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:42 --> URI Class Initialized
INFO - 2018-05-14 17:10:42 --> Router Class Initialized
INFO - 2018-05-14 17:10:42 --> Output Class Initialized
INFO - 2018-05-14 17:10:42 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:42 --> Input Class Initialized
INFO - 2018-05-14 17:10:42 --> Language Class Initialized
INFO - 2018-05-14 17:10:42 --> Loader Class Initialized
INFO - 2018-05-14 17:10:42 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:42 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:42 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:43 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:43 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:43 --> Model Class Initialized
INFO - 2018-05-14 17:10:43 --> Controller Class Initialized
INFO - 2018-05-14 17:10:50 --> Config Class Initialized
INFO - 2018-05-14 17:10:50 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:50 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:50 --> URI Class Initialized
INFO - 2018-05-14 17:10:50 --> Router Class Initialized
INFO - 2018-05-14 17:10:50 --> Output Class Initialized
INFO - 2018-05-14 17:10:50 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:50 --> Input Class Initialized
INFO - 2018-05-14 17:10:50 --> Language Class Initialized
INFO - 2018-05-14 17:10:50 --> Loader Class Initialized
INFO - 2018-05-14 17:10:50 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:50 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:50 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:50 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:50 --> Model Class Initialized
INFO - 2018-05-14 17:10:50 --> Controller Class Initialized
INFO - 2018-05-14 17:10:52 --> Config Class Initialized
INFO - 2018-05-14 17:10:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:52 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:52 --> URI Class Initialized
INFO - 2018-05-14 17:10:52 --> Router Class Initialized
INFO - 2018-05-14 17:10:52 --> Output Class Initialized
INFO - 2018-05-14 17:10:53 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:53 --> Input Class Initialized
INFO - 2018-05-14 17:10:53 --> Language Class Initialized
INFO - 2018-05-14 17:10:53 --> Loader Class Initialized
INFO - 2018-05-14 17:10:53 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:53 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:53 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:53 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:53 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:53 --> Model Class Initialized
INFO - 2018-05-14 17:10:53 --> Controller Class Initialized
INFO - 2018-05-14 17:10:53 --> Model Class Initialized
INFO - 2018-05-14 17:10:53 --> File loaded: C:\xampp\htdocs\mcms\application\views\dashboard.php
INFO - 2018-05-14 17:10:53 --> Final output sent to browser
DEBUG - 2018-05-14 17:10:53 --> Total execution time: 0.6092
INFO - 2018-05-14 17:10:53 --> Config Class Initialized
INFO - 2018-05-14 17:10:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:53 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:53 --> URI Class Initialized
INFO - 2018-05-14 17:10:53 --> Router Class Initialized
INFO - 2018-05-14 17:10:53 --> Output Class Initialized
INFO - 2018-05-14 17:10:53 --> Security Class Initialized
DEBUG - 2018-05-14 17:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:10:54 --> Input Class Initialized
INFO - 2018-05-14 17:10:54 --> Language Class Initialized
INFO - 2018-05-14 17:10:54 --> Loader Class Initialized
INFO - 2018-05-14 17:10:54 --> Helper loaded: url_helper
INFO - 2018-05-14 17:10:54 --> Helper loaded: form_helper
INFO - 2018-05-14 17:10:54 --> Helper loaded: date_helper
INFO - 2018-05-14 17:10:54 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:10:54 --> Form Validation Class Initialized
INFO - 2018-05-14 17:10:54 --> Model Class Initialized
INFO - 2018-05-14 17:10:54 --> Controller Class Initialized
INFO - 2018-05-14 17:10:59 --> Config Class Initialized
INFO - 2018-05-14 17:10:59 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:10:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:10:59 --> Utf8 Class Initialized
INFO - 2018-05-14 17:10:59 --> URI Class Initialized
INFO - 2018-05-14 17:11:00 --> Router Class Initialized
INFO - 2018-05-14 17:11:00 --> Output Class Initialized
INFO - 2018-05-14 17:11:00 --> Security Class Initialized
DEBUG - 2018-05-14 17:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:11:00 --> Input Class Initialized
INFO - 2018-05-14 17:11:00 --> Language Class Initialized
INFO - 2018-05-14 17:11:00 --> Loader Class Initialized
INFO - 2018-05-14 17:11:00 --> Helper loaded: url_helper
INFO - 2018-05-14 17:11:00 --> Helper loaded: form_helper
INFO - 2018-05-14 17:11:00 --> Helper loaded: date_helper
INFO - 2018-05-14 17:11:00 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:11:00 --> Form Validation Class Initialized
INFO - 2018-05-14 17:11:00 --> Model Class Initialized
INFO - 2018-05-14 17:11:00 --> Controller Class Initialized
INFO - 2018-05-14 17:11:00 --> Model Class Initialized
INFO - 2018-05-14 17:11:00 --> File loaded: C:\xampp\htdocs\mcms\application\views\prms/case_list.php
INFO - 2018-05-14 17:11:00 --> Final output sent to browser
DEBUG - 2018-05-14 17:11:00 --> Total execution time: 0.9690
INFO - 2018-05-14 17:11:03 --> Config Class Initialized
INFO - 2018-05-14 17:11:03 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:11:03 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:11:03 --> Utf8 Class Initialized
INFO - 2018-05-14 17:11:03 --> URI Class Initialized
INFO - 2018-05-14 17:11:03 --> Router Class Initialized
INFO - 2018-05-14 17:11:03 --> Output Class Initialized
INFO - 2018-05-14 17:11:03 --> Security Class Initialized
DEBUG - 2018-05-14 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:11:03 --> Input Class Initialized
INFO - 2018-05-14 17:11:03 --> Language Class Initialized
INFO - 2018-05-14 17:11:03 --> Loader Class Initialized
INFO - 2018-05-14 17:11:03 --> Helper loaded: url_helper
INFO - 2018-05-14 17:11:03 --> Helper loaded: form_helper
INFO - 2018-05-14 17:11:03 --> Helper loaded: date_helper
INFO - 2018-05-14 17:11:03 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:11:04 --> Form Validation Class Initialized
INFO - 2018-05-14 17:11:04 --> Model Class Initialized
INFO - 2018-05-14 17:11:04 --> Controller Class Initialized
INFO - 2018-05-14 17:11:04 --> Model Class Initialized
ERROR - 2018-05-14 17:11:04 --> Query error: Table 'mcms.statement_of_account' doesn't exist - Invalid query: SELECT *
FROM `statement_of_account`
WHERE `case_id` = '1'
INFO - 2018-05-14 17:11:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-14 17:13:55 --> Config Class Initialized
INFO - 2018-05-14 17:13:56 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:13:56 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:13:56 --> Utf8 Class Initialized
INFO - 2018-05-14 17:13:56 --> URI Class Initialized
INFO - 2018-05-14 17:13:56 --> Router Class Initialized
INFO - 2018-05-14 17:13:56 --> Output Class Initialized
INFO - 2018-05-14 17:13:56 --> Security Class Initialized
DEBUG - 2018-05-14 17:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:13:56 --> Input Class Initialized
INFO - 2018-05-14 17:13:56 --> Language Class Initialized
INFO - 2018-05-14 17:13:56 --> Loader Class Initialized
INFO - 2018-05-14 17:13:56 --> Helper loaded: url_helper
INFO - 2018-05-14 17:13:56 --> Helper loaded: form_helper
INFO - 2018-05-14 17:13:56 --> Helper loaded: date_helper
INFO - 2018-05-14 17:13:56 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:13:56 --> Form Validation Class Initialized
INFO - 2018-05-14 17:13:56 --> Model Class Initialized
INFO - 2018-05-14 17:13:56 --> Controller Class Initialized
INFO - 2018-05-14 17:13:56 --> Model Class Initialized
ERROR - 2018-05-14 17:13:56 --> Query error: Table 'mcms.statement_of_account' doesn't exist - Invalid query: SELECT *
FROM `statement_of_account`
WHERE `case_id` = '1'
INFO - 2018-05-14 17:13:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-14 17:14:13 --> Config Class Initialized
INFO - 2018-05-14 17:14:13 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:14:13 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:14:13 --> Utf8 Class Initialized
INFO - 2018-05-14 17:14:13 --> URI Class Initialized
INFO - 2018-05-14 17:14:13 --> Router Class Initialized
INFO - 2018-05-14 17:14:13 --> Output Class Initialized
INFO - 2018-05-14 17:14:13 --> Security Class Initialized
DEBUG - 2018-05-14 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:14:13 --> Input Class Initialized
INFO - 2018-05-14 17:14:13 --> Language Class Initialized
INFO - 2018-05-14 17:14:13 --> Loader Class Initialized
INFO - 2018-05-14 17:14:13 --> Helper loaded: url_helper
INFO - 2018-05-14 17:14:13 --> Helper loaded: form_helper
INFO - 2018-05-14 17:14:13 --> Helper loaded: date_helper
INFO - 2018-05-14 17:14:13 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:14:13 --> Form Validation Class Initialized
INFO - 2018-05-14 17:14:13 --> Model Class Initialized
INFO - 2018-05-14 17:14:13 --> Controller Class Initialized
INFO - 2018-05-14 17:14:13 --> Model Class Initialized
INFO - 2018-05-14 17:14:14 --> File loaded: C:\xampp\htdocs\mcms\application\views\prms/case_timeline.php
INFO - 2018-05-14 17:14:14 --> Final output sent to browser
DEBUG - 2018-05-14 17:14:14 --> Total execution time: 0.9389
INFO - 2018-05-14 17:14:18 --> Config Class Initialized
INFO - 2018-05-14 17:14:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:14:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:14:18 --> Utf8 Class Initialized
INFO - 2018-05-14 17:14:19 --> URI Class Initialized
INFO - 2018-05-14 17:14:19 --> Router Class Initialized
INFO - 2018-05-14 17:14:19 --> Output Class Initialized
INFO - 2018-05-14 17:14:19 --> Security Class Initialized
DEBUG - 2018-05-14 17:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:14:19 --> Input Class Initialized
INFO - 2018-05-14 17:14:19 --> Language Class Initialized
INFO - 2018-05-14 17:14:19 --> Loader Class Initialized
INFO - 2018-05-14 17:14:19 --> Helper loaded: url_helper
INFO - 2018-05-14 17:14:19 --> Helper loaded: form_helper
INFO - 2018-05-14 17:14:19 --> Helper loaded: date_helper
INFO - 2018-05-14 17:14:19 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:14:19 --> Form Validation Class Initialized
INFO - 2018-05-14 17:14:19 --> Model Class Initialized
INFO - 2018-05-14 17:14:19 --> Controller Class Initialized
INFO - 2018-05-14 17:14:19 --> Model Class Initialized
ERROR - 2018-05-14 17:14:21 --> Severity: Notice --> Undefined variable: html C:\xampp\htdocs\mcms\application\views\report\reportpe.php 88
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined variable: w C:\xampp\htdocs\mcms\application\views\report\reportpe.php 89
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined variable: h C:\xampp\htdocs\mcms\application\views\report\reportpe.php 89
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined variable: x C:\xampp\htdocs\mcms\application\views\report\reportpe.php 89
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined variable: y C:\xampp\htdocs\mcms\application\views\report\reportpe.php 89
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined property: stdClass::$Patient_ID C:\xampp\htdocs\mcms\application\views\report\reportpe.php 110
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startcolumn C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19450
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startx C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19451
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19454
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startcolumn C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19450
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startx C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19451
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19454
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:14:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:14:22 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:14:23 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
ERROR - 2018-05-14 17:14:23 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:14:23 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:14:23 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:14:23 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
INFO - 2018-05-14 17:14:23 --> File loaded: C:\xampp\htdocs\mcms\application\views\report/reportpe.php
INFO - 2018-05-14 17:14:23 --> Final output sent to browser
DEBUG - 2018-05-14 17:14:23 --> Total execution time: 4.4044
INFO - 2018-05-14 17:14:31 --> Config Class Initialized
INFO - 2018-05-14 17:14:31 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:14:31 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:14:31 --> Utf8 Class Initialized
INFO - 2018-05-14 17:14:31 --> URI Class Initialized
INFO - 2018-05-14 17:14:31 --> Router Class Initialized
INFO - 2018-05-14 17:14:31 --> Output Class Initialized
INFO - 2018-05-14 17:14:31 --> Security Class Initialized
DEBUG - 2018-05-14 17:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:14:31 --> Input Class Initialized
INFO - 2018-05-14 17:14:31 --> Language Class Initialized
INFO - 2018-05-14 17:14:31 --> Loader Class Initialized
INFO - 2018-05-14 17:14:31 --> Helper loaded: url_helper
INFO - 2018-05-14 17:14:32 --> Helper loaded: form_helper
INFO - 2018-05-14 17:14:32 --> Helper loaded: date_helper
INFO - 2018-05-14 17:14:32 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:14:32 --> Form Validation Class Initialized
INFO - 2018-05-14 17:14:32 --> Model Class Initialized
INFO - 2018-05-14 17:14:32 --> Controller Class Initialized
INFO - 2018-05-14 17:14:32 --> Model Class Initialized
INFO - 2018-05-14 17:14:32 --> File loaded: C:\xampp\htdocs\mcms\application\views\prms/case_timeline.php
INFO - 2018-05-14 17:14:32 --> Final output sent to browser
DEBUG - 2018-05-14 17:14:32 --> Total execution time: 0.8429
INFO - 2018-05-14 17:23:12 --> Config Class Initialized
INFO - 2018-05-14 17:23:12 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:23:12 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:23:12 --> Utf8 Class Initialized
INFO - 2018-05-14 17:23:12 --> URI Class Initialized
INFO - 2018-05-14 17:23:12 --> Router Class Initialized
INFO - 2018-05-14 17:23:12 --> Output Class Initialized
INFO - 2018-05-14 17:23:12 --> Security Class Initialized
DEBUG - 2018-05-14 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:23:12 --> Input Class Initialized
INFO - 2018-05-14 17:23:12 --> Language Class Initialized
INFO - 2018-05-14 17:23:12 --> Loader Class Initialized
INFO - 2018-05-14 17:23:12 --> Helper loaded: url_helper
INFO - 2018-05-14 17:23:12 --> Helper loaded: form_helper
INFO - 2018-05-14 17:23:12 --> Helper loaded: date_helper
INFO - 2018-05-14 17:23:12 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:23:12 --> Form Validation Class Initialized
INFO - 2018-05-14 17:23:12 --> Model Class Initialized
INFO - 2018-05-14 17:23:12 --> Controller Class Initialized
INFO - 2018-05-14 17:23:12 --> Model Class Initialized
DEBUG - 2018-05-14 17:23:13 --> Pdf class already loaded. Second attempt ignored.
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:23:13 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined variable: oh_living_children C:\xampp\htdocs\mcms\application\views\report\reportsum.php 285
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined variable: oh_age_of_gestation_weeks C:\xampp\htdocs\mcms\application\views\report\reportsum.php 297
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startcolumn C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19450
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startx C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19451
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19454
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startcolumn C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19450
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startx C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19451
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19454
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19457
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: startpage C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19458
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
ERROR - 2018-05-14 17:23:14 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 16498
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19478
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19507
ERROR - 2018-05-14 17:23:15 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19510
ERROR - 2018-05-14 17:23:16 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\mcms\application\libraries\tcpdf\tcpdf.php 19720
INFO - 2018-05-14 17:23:16 --> File loaded: C:\xampp\htdocs\mcms\application\views\report/reportsum.php
INFO - 2018-05-14 17:23:16 --> Final output sent to browser
DEBUG - 2018-05-14 17:23:16 --> Total execution time: 4.1137
INFO - 2018-05-14 17:23:27 --> Config Class Initialized
INFO - 2018-05-14 17:23:27 --> Hooks Class Initialized
DEBUG - 2018-05-14 17:23:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 17:23:27 --> Utf8 Class Initialized
INFO - 2018-05-14 17:23:27 --> URI Class Initialized
INFO - 2018-05-14 17:23:27 --> Router Class Initialized
INFO - 2018-05-14 17:23:27 --> Output Class Initialized
INFO - 2018-05-14 17:23:28 --> Security Class Initialized
DEBUG - 2018-05-14 17:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 17:23:28 --> Input Class Initialized
INFO - 2018-05-14 17:23:28 --> Language Class Initialized
INFO - 2018-05-14 17:23:28 --> Loader Class Initialized
INFO - 2018-05-14 17:23:28 --> Helper loaded: url_helper
INFO - 2018-05-14 17:23:28 --> Helper loaded: form_helper
INFO - 2018-05-14 17:23:28 --> Helper loaded: date_helper
INFO - 2018-05-14 17:23:28 --> Database Driver Class Initialized
DEBUG - 2018-05-14 17:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 17:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 17:23:28 --> Form Validation Class Initialized
INFO - 2018-05-14 17:23:28 --> Model Class Initialized
INFO - 2018-05-14 17:23:28 --> Controller Class Initialized
INFO - 2018-05-14 17:23:28 --> Model Class Initialized
INFO - 2018-05-14 17:23:28 --> File loaded: C:\xampp\htdocs\mcms\application\views\prms/case_timeline.php
INFO - 2018-05-14 17:23:28 --> Final output sent to browser
DEBUG - 2018-05-14 17:23:28 --> Total execution time: 0.7767
